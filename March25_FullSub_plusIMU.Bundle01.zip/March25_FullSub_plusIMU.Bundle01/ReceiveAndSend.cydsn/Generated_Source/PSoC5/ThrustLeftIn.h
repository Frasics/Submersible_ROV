/*******************************************************************************
* File Name: ThrustLeftIn.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ThrustLeftIn_H) /* Pins ThrustLeftIn_H */
#define CY_PINS_ThrustLeftIn_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ThrustLeftIn_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ThrustLeftIn__PORT == 15 && ((ThrustLeftIn__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    ThrustLeftIn_Write(uint8 value);
void    ThrustLeftIn_SetDriveMode(uint8 mode);
uint8   ThrustLeftIn_ReadDataReg(void);
uint8   ThrustLeftIn_Read(void);
void    ThrustLeftIn_SetInterruptMode(uint16 position, uint16 mode);
uint8   ThrustLeftIn_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the ThrustLeftIn_SetDriveMode() function.
     *  @{
     */
        #define ThrustLeftIn_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define ThrustLeftIn_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define ThrustLeftIn_DM_RES_UP          PIN_DM_RES_UP
        #define ThrustLeftIn_DM_RES_DWN         PIN_DM_RES_DWN
        #define ThrustLeftIn_DM_OD_LO           PIN_DM_OD_LO
        #define ThrustLeftIn_DM_OD_HI           PIN_DM_OD_HI
        #define ThrustLeftIn_DM_STRONG          PIN_DM_STRONG
        #define ThrustLeftIn_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define ThrustLeftIn_MASK               ThrustLeftIn__MASK
#define ThrustLeftIn_SHIFT              ThrustLeftIn__SHIFT
#define ThrustLeftIn_WIDTH              1u

/* Interrupt constants */
#if defined(ThrustLeftIn__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in ThrustLeftIn_SetInterruptMode() function.
     *  @{
     */
        #define ThrustLeftIn_INTR_NONE      (uint16)(0x0000u)
        #define ThrustLeftIn_INTR_RISING    (uint16)(0x0001u)
        #define ThrustLeftIn_INTR_FALLING   (uint16)(0x0002u)
        #define ThrustLeftIn_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define ThrustLeftIn_INTR_MASK      (0x01u) 
#endif /* (ThrustLeftIn__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ThrustLeftIn_PS                     (* (reg8 *) ThrustLeftIn__PS)
/* Data Register */
#define ThrustLeftIn_DR                     (* (reg8 *) ThrustLeftIn__DR)
/* Port Number */
#define ThrustLeftIn_PRT_NUM                (* (reg8 *) ThrustLeftIn__PRT) 
/* Connect to Analog Globals */                                                  
#define ThrustLeftIn_AG                     (* (reg8 *) ThrustLeftIn__AG)                       
/* Analog MUX bux enable */
#define ThrustLeftIn_AMUX                   (* (reg8 *) ThrustLeftIn__AMUX) 
/* Bidirectional Enable */                                                        
#define ThrustLeftIn_BIE                    (* (reg8 *) ThrustLeftIn__BIE)
/* Bit-mask for Aliased Register Access */
#define ThrustLeftIn_BIT_MASK               (* (reg8 *) ThrustLeftIn__BIT_MASK)
/* Bypass Enable */
#define ThrustLeftIn_BYP                    (* (reg8 *) ThrustLeftIn__BYP)
/* Port wide control signals */                                                   
#define ThrustLeftIn_CTL                    (* (reg8 *) ThrustLeftIn__CTL)
/* Drive Modes */
#define ThrustLeftIn_DM0                    (* (reg8 *) ThrustLeftIn__DM0) 
#define ThrustLeftIn_DM1                    (* (reg8 *) ThrustLeftIn__DM1)
#define ThrustLeftIn_DM2                    (* (reg8 *) ThrustLeftIn__DM2) 
/* Input Buffer Disable Override */
#define ThrustLeftIn_INP_DIS                (* (reg8 *) ThrustLeftIn__INP_DIS)
/* LCD Common or Segment Drive */
#define ThrustLeftIn_LCD_COM_SEG            (* (reg8 *) ThrustLeftIn__LCD_COM_SEG)
/* Enable Segment LCD */
#define ThrustLeftIn_LCD_EN                 (* (reg8 *) ThrustLeftIn__LCD_EN)
/* Slew Rate Control */
#define ThrustLeftIn_SLW                    (* (reg8 *) ThrustLeftIn__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ThrustLeftIn_PRTDSI__CAPS_SEL       (* (reg8 *) ThrustLeftIn__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ThrustLeftIn_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ThrustLeftIn__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ThrustLeftIn_PRTDSI__OE_SEL0        (* (reg8 *) ThrustLeftIn__PRTDSI__OE_SEL0) 
#define ThrustLeftIn_PRTDSI__OE_SEL1        (* (reg8 *) ThrustLeftIn__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ThrustLeftIn_PRTDSI__OUT_SEL0       (* (reg8 *) ThrustLeftIn__PRTDSI__OUT_SEL0) 
#define ThrustLeftIn_PRTDSI__OUT_SEL1       (* (reg8 *) ThrustLeftIn__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ThrustLeftIn_PRTDSI__SYNC_OUT       (* (reg8 *) ThrustLeftIn__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(ThrustLeftIn__SIO_CFG)
    #define ThrustLeftIn_SIO_HYST_EN        (* (reg8 *) ThrustLeftIn__SIO_HYST_EN)
    #define ThrustLeftIn_SIO_REG_HIFREQ     (* (reg8 *) ThrustLeftIn__SIO_REG_HIFREQ)
    #define ThrustLeftIn_SIO_CFG            (* (reg8 *) ThrustLeftIn__SIO_CFG)
    #define ThrustLeftIn_SIO_DIFF           (* (reg8 *) ThrustLeftIn__SIO_DIFF)
#endif /* (ThrustLeftIn__SIO_CFG) */

/* Interrupt Registers */
#if defined(ThrustLeftIn__INTSTAT)
    #define ThrustLeftIn_INTSTAT            (* (reg8 *) ThrustLeftIn__INTSTAT)
    #define ThrustLeftIn_SNAP               (* (reg8 *) ThrustLeftIn__SNAP)
    
	#define ThrustLeftIn_0_INTTYPE_REG 		(* (reg8 *) ThrustLeftIn__0__INTTYPE)
#endif /* (ThrustLeftIn__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ThrustLeftIn_H */


/* [] END OF FILE */
