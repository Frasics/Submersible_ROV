/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include "gripper.h"

void grip()
{
    volatile uint16 pos = 0;
    if (gripClosed_Read() != 0 && gripOpen_Read()==0)//pressing gripper Open
    {
        pos = 4000;// place holder pwm signal
    }
    else if (gripClosed_Read() == 0 && gripOpen_Read()!=0)
    {
        pos = 2000;// once again a place holder
    }
    PWM_G_WriteCompare(pos); // open     
}