/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"


uint16 Result = 0;
int CapSense_DisplayState();

int main(void)
{
	CyGlobalIntEnable;    /* Enable global interrupts */
    
    PWM_Start();
    Clock_Start();
    
    LCD_Start();
    
    CapSense_Start(); 
    CapSense_InitializeAllBaselines();	
	
    ADC_Start();
    ADC_StartConvert();
    
    while(1u)
    {			
        if(CapSense_IsBusy() == 0)
		{
	        CapSense_UpdateEnabledBaselines();
	    	CapSense_ScanEnabledWidgets();
		}
		CapSense_DisplayState();        
    }
}

int CapSense_DisplayState()
{
    uint16 value;
    uint16 temp;
    
    for(int i=0; i<=7; i++)
        {
            ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
            temp = ADC_CountsTo_mVolts(ADC_GetResult16());
            Result=Result+ temp;
        } 
    value = Result/8;
    Result=0;
        
        
    /* BUTTON0 */
	if (CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN) &! CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN)) 
	{   
        LED1_Write(1u);
        LED2_Write(0u);
        
        //////////////////////////////
        //         up              //
        /////////////////////////////
        Dir_Write(1);
        PWM_WriteCompare(255);          
      /*      if(value < 1328)//at max up postion
            {
                PWM_WriteCompare1(0);
                PWM_WriteCompare2(0);
            }*/           
            
    }
    
    
	/* BUTTON1 */
	else if (CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN) &! CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN))
	{     
        LED1_Write(0u);
        LED2_Write(1u);
        
        //////////////////////////////
        //         DOWN            //
        ///////////////////////////// 
        if (value < 3100) //at max down position
        {
            Dir_Write(0);
            PWM_WriteCompare(255);
        }
        else
        {
            PWM_WriteCompare(0); 
            Dir_Write(1);
        } 
	}
    
    
	else
	{
		LED1_Write(0u);
        LED2_Write(0u);
        PWM_WriteCompare(0);
	}
    
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintNumber(value);
    CyDelay(100); //for LCD print
    return Dir_Read();   
}


/* [] END OF FILE */
