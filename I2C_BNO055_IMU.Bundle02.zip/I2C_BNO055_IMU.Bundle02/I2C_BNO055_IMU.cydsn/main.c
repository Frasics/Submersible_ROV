#include "project.h"
#include "BNO055.h"
#include <stdio.h>

const int READDELAY = 100; //was 1000
const int counter = 3000;

// function declarations
void write8(uint8 Reg, uint32 value);
uint8 read8(uint8 Reg);
uint16 read16(uint8 Reg);
//void readMultiByte(uint8 Reg, uint8 NumberOfValues, uint8 *dest);

int main(void)
{   
    uint8 data = 0;
    //int16 Q = 0; //not used
    int16 X = 0; //data to use with diving planes
    //int16 Y = 0; //data not used
    int16 Z = 0; //data to use with thrusters
    
    int16 compare = 0;
    int16 setpoint = 0;
    int16 error = 0;
    int16 output = 0;
    
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    I2C_Start(); //Start I2C component
    CyDelay(READDELAY);
    Clock_Start();
    PWM_Start();
    
    //PWM_WriteCompare(3000); //for testing, set servo to center position
    
    data = read8(BNO055_CHIP_ID_ADDR); //read chip id
    CyDelay(READDELAY);
    data = read8(BNO055_ACCEL_REV_ID_ADDR);  //read accelerometer id
    CyDelay(READDELAY);
    data = read8(BNO055_MAG_REV_ID_ADDR); //read magnetometer id
    CyDelay(READDELAY);
    data = read8(BNO055_GYRO_REV_ID_ADDR); //read gyroscope id
    CyDelay(READDELAY);
    data = read8(BNO055_SW_REV_ID_LSB_ADDR); //software revision id LSB
    CyDelay(READDELAY);
    data = read8(BNO055_SW_REV_ID_MSB_ADDR); //software revision id MSB 
    CyDelay(READDELAY);
    data = read8(BNO055_BL_REV_ID_ADDR) ; //bootloader revision id
    CyDelay(READDELAY);
    write8(BNO055_OPR_MODE_ADDR, POWER_MODE_NORMAL); //set power mode to normal
    CyDelay(READDELAY);
    //Set units
    uint8_t unitsel = (1 << 7) | // Orientation = Android
                    (0 << 4) | // Temperature = Celsius
                    (0 << 2) | // Euler = Degrees
                    (0 << 1) | // Gyro = Degrees
                    (0 << 0);  // Accelerometer = m/s^2
    write8(BNO055_UNIT_SEL_ADDR , unitsel);
    CyDelay(READDELAY);
    write8(BNO055_SYS_TRIGGER_ADDR, 0x00); //stopping any future resets
    CyDelay(READDELAY);
    write8(BNO055_OPR_MODE_ADDR , OPERATION_MODE_IMUPLUS); //set imu operation mode
    CyDelay(READDELAY);
    uint8 status = read8(BNO055_SYS_STAT_ADDR); //status, should be 5
    CyDelay(READDELAY);
    status = read8(BNO055_CALIB_STAT_ADDR); //calibration status
    uint8 systatus = (status & 0b11000000) >> 6;
    uint8 gyrstatus = (status & 0b00110000) >> 4;
    uint8 accstatus = (status & 0b00001100) >> 2;
    uint8 magstatus = (status & 0b00000011);
    CyDelay(READDELAY);
    
    setpoint = read16(BNO055_QUATERNION_DATA_X_LSB_ADDR);
    
    for(;;)
    {
        X = read16(BNO055_QUATERNION_DATA_X_LSB_ADDR);
           
        if (Button_Read() == 0) { //if being controlled by handheld
            setpoint = Z;
            error = 0;
        } else if (Button_Read() == 1) { //if not being controlled by handheld
            error = setpoint - Z;
            output = (error / 5.8) + 3000;
            PWM_WriteCompare(output);
        }                     
    }
}

void write8(uint8 Reg, uint32 value ){
    uint8 status = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    status = I2C_MasterWriteByte(Reg );
    //Write byte to the data register specified by value
    status = I2C_MasterWriteByte(value & 0xFF);
    status = I2C_MasterSendStop();
}

uint8 read8(uint8 Reg){
    volatile uint8 status = 0;
    uint8 data = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    //Mask the command bit and the Register to read/Write from
    status = I2C_MasterWriteByte(Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //Send NAK to indicate end of data to be read
    data = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    
    return data;
}

uint16 read16(uint8 Reg){
    uint8 status = 0;
    uint16 data = 0;
    uint8 dataL = 0;
    uint8 dataH = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    //Mask the command bit with Comand Increment Mode and the Register to read/Write from
    status = I2C_MasterWriteByte( Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //Send ACK to acknowlege data received
    dataL = I2C_MasterReadByte(I2C_ACK_DATA);
    //Send NAK to indicate end of data to be read
    dataH = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    //Combine 2 uint8 values (High byte and Low byte) into a uint16 value
    data = (uint16) dataH;
    data = data << 8;
    data |= dataL;
    
    return data;
}
