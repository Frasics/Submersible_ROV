/*******************************************************************************
* File Name: DepthSensor.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DepthSensor_H) /* Pins DepthSensor_H */
#define CY_PINS_DepthSensor_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DepthSensor_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 DepthSensor__PORT == 15 && ((DepthSensor__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    DepthSensor_Write(uint8 value);
void    DepthSensor_SetDriveMode(uint8 mode);
uint8   DepthSensor_ReadDataReg(void);
uint8   DepthSensor_Read(void);
void    DepthSensor_SetInterruptMode(uint16 position, uint16 mode);
uint8   DepthSensor_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the DepthSensor_SetDriveMode() function.
     *  @{
     */
        #define DepthSensor_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define DepthSensor_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define DepthSensor_DM_RES_UP          PIN_DM_RES_UP
        #define DepthSensor_DM_RES_DWN         PIN_DM_RES_DWN
        #define DepthSensor_DM_OD_LO           PIN_DM_OD_LO
        #define DepthSensor_DM_OD_HI           PIN_DM_OD_HI
        #define DepthSensor_DM_STRONG          PIN_DM_STRONG
        #define DepthSensor_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define DepthSensor_MASK               DepthSensor__MASK
#define DepthSensor_SHIFT              DepthSensor__SHIFT
#define DepthSensor_WIDTH              1u

/* Interrupt constants */
#if defined(DepthSensor__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DepthSensor_SetInterruptMode() function.
     *  @{
     */
        #define DepthSensor_INTR_NONE      (uint16)(0x0000u)
        #define DepthSensor_INTR_RISING    (uint16)(0x0001u)
        #define DepthSensor_INTR_FALLING   (uint16)(0x0002u)
        #define DepthSensor_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define DepthSensor_INTR_MASK      (0x01u) 
#endif /* (DepthSensor__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DepthSensor_PS                     (* (reg8 *) DepthSensor__PS)
/* Data Register */
#define DepthSensor_DR                     (* (reg8 *) DepthSensor__DR)
/* Port Number */
#define DepthSensor_PRT_NUM                (* (reg8 *) DepthSensor__PRT) 
/* Connect to Analog Globals */                                                  
#define DepthSensor_AG                     (* (reg8 *) DepthSensor__AG)                       
/* Analog MUX bux enable */
#define DepthSensor_AMUX                   (* (reg8 *) DepthSensor__AMUX) 
/* Bidirectional Enable */                                                        
#define DepthSensor_BIE                    (* (reg8 *) DepthSensor__BIE)
/* Bit-mask for Aliased Register Access */
#define DepthSensor_BIT_MASK               (* (reg8 *) DepthSensor__BIT_MASK)
/* Bypass Enable */
#define DepthSensor_BYP                    (* (reg8 *) DepthSensor__BYP)
/* Port wide control signals */                                                   
#define DepthSensor_CTL                    (* (reg8 *) DepthSensor__CTL)
/* Drive Modes */
#define DepthSensor_DM0                    (* (reg8 *) DepthSensor__DM0) 
#define DepthSensor_DM1                    (* (reg8 *) DepthSensor__DM1)
#define DepthSensor_DM2                    (* (reg8 *) DepthSensor__DM2) 
/* Input Buffer Disable Override */
#define DepthSensor_INP_DIS                (* (reg8 *) DepthSensor__INP_DIS)
/* LCD Common or Segment Drive */
#define DepthSensor_LCD_COM_SEG            (* (reg8 *) DepthSensor__LCD_COM_SEG)
/* Enable Segment LCD */
#define DepthSensor_LCD_EN                 (* (reg8 *) DepthSensor__LCD_EN)
/* Slew Rate Control */
#define DepthSensor_SLW                    (* (reg8 *) DepthSensor__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DepthSensor_PRTDSI__CAPS_SEL       (* (reg8 *) DepthSensor__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DepthSensor_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DepthSensor__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DepthSensor_PRTDSI__OE_SEL0        (* (reg8 *) DepthSensor__PRTDSI__OE_SEL0) 
#define DepthSensor_PRTDSI__OE_SEL1        (* (reg8 *) DepthSensor__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DepthSensor_PRTDSI__OUT_SEL0       (* (reg8 *) DepthSensor__PRTDSI__OUT_SEL0) 
#define DepthSensor_PRTDSI__OUT_SEL1       (* (reg8 *) DepthSensor__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DepthSensor_PRTDSI__SYNC_OUT       (* (reg8 *) DepthSensor__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(DepthSensor__SIO_CFG)
    #define DepthSensor_SIO_HYST_EN        (* (reg8 *) DepthSensor__SIO_HYST_EN)
    #define DepthSensor_SIO_REG_HIFREQ     (* (reg8 *) DepthSensor__SIO_REG_HIFREQ)
    #define DepthSensor_SIO_CFG            (* (reg8 *) DepthSensor__SIO_CFG)
    #define DepthSensor_SIO_DIFF           (* (reg8 *) DepthSensor__SIO_DIFF)
#endif /* (DepthSensor__SIO_CFG) */

/* Interrupt Registers */
#if defined(DepthSensor__INTSTAT)
    #define DepthSensor_INTSTAT            (* (reg8 *) DepthSensor__INTSTAT)
    #define DepthSensor_SNAP               (* (reg8 *) DepthSensor__SNAP)
    
	#define DepthSensor_0_INTTYPE_REG 		(* (reg8 *) DepthSensor__0__INTTYPE)
#endif /* (DepthSensor__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_DepthSensor_H */


/* [] END OF FILE */
