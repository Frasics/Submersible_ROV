/*******************************************************************************
* File Name: gripperFb.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_gripperFb_H) /* Pins gripperFb_H */
#define CY_PINS_gripperFb_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "gripperFb_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 gripperFb__PORT == 15 && ((gripperFb__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    gripperFb_Write(uint8 value);
void    gripperFb_SetDriveMode(uint8 mode);
uint8   gripperFb_ReadDataReg(void);
uint8   gripperFb_Read(void);
void    gripperFb_SetInterruptMode(uint16 position, uint16 mode);
uint8   gripperFb_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the gripperFb_SetDriveMode() function.
     *  @{
     */
        #define gripperFb_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define gripperFb_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define gripperFb_DM_RES_UP          PIN_DM_RES_UP
        #define gripperFb_DM_RES_DWN         PIN_DM_RES_DWN
        #define gripperFb_DM_OD_LO           PIN_DM_OD_LO
        #define gripperFb_DM_OD_HI           PIN_DM_OD_HI
        #define gripperFb_DM_STRONG          PIN_DM_STRONG
        #define gripperFb_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define gripperFb_MASK               gripperFb__MASK
#define gripperFb_SHIFT              gripperFb__SHIFT
#define gripperFb_WIDTH              1u

/* Interrupt constants */
#if defined(gripperFb__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in gripperFb_SetInterruptMode() function.
     *  @{
     */
        #define gripperFb_INTR_NONE      (uint16)(0x0000u)
        #define gripperFb_INTR_RISING    (uint16)(0x0001u)
        #define gripperFb_INTR_FALLING   (uint16)(0x0002u)
        #define gripperFb_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define gripperFb_INTR_MASK      (0x01u) 
#endif /* (gripperFb__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define gripperFb_PS                     (* (reg8 *) gripperFb__PS)
/* Data Register */
#define gripperFb_DR                     (* (reg8 *) gripperFb__DR)
/* Port Number */
#define gripperFb_PRT_NUM                (* (reg8 *) gripperFb__PRT) 
/* Connect to Analog Globals */                                                  
#define gripperFb_AG                     (* (reg8 *) gripperFb__AG)                       
/* Analog MUX bux enable */
#define gripperFb_AMUX                   (* (reg8 *) gripperFb__AMUX) 
/* Bidirectional Enable */                                                        
#define gripperFb_BIE                    (* (reg8 *) gripperFb__BIE)
/* Bit-mask for Aliased Register Access */
#define gripperFb_BIT_MASK               (* (reg8 *) gripperFb__BIT_MASK)
/* Bypass Enable */
#define gripperFb_BYP                    (* (reg8 *) gripperFb__BYP)
/* Port wide control signals */                                                   
#define gripperFb_CTL                    (* (reg8 *) gripperFb__CTL)
/* Drive Modes */
#define gripperFb_DM0                    (* (reg8 *) gripperFb__DM0) 
#define gripperFb_DM1                    (* (reg8 *) gripperFb__DM1)
#define gripperFb_DM2                    (* (reg8 *) gripperFb__DM2) 
/* Input Buffer Disable Override */
#define gripperFb_INP_DIS                (* (reg8 *) gripperFb__INP_DIS)
/* LCD Common or Segment Drive */
#define gripperFb_LCD_COM_SEG            (* (reg8 *) gripperFb__LCD_COM_SEG)
/* Enable Segment LCD */
#define gripperFb_LCD_EN                 (* (reg8 *) gripperFb__LCD_EN)
/* Slew Rate Control */
#define gripperFb_SLW                    (* (reg8 *) gripperFb__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define gripperFb_PRTDSI__CAPS_SEL       (* (reg8 *) gripperFb__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define gripperFb_PRTDSI__DBL_SYNC_IN    (* (reg8 *) gripperFb__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define gripperFb_PRTDSI__OE_SEL0        (* (reg8 *) gripperFb__PRTDSI__OE_SEL0) 
#define gripperFb_PRTDSI__OE_SEL1        (* (reg8 *) gripperFb__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define gripperFb_PRTDSI__OUT_SEL0       (* (reg8 *) gripperFb__PRTDSI__OUT_SEL0) 
#define gripperFb_PRTDSI__OUT_SEL1       (* (reg8 *) gripperFb__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define gripperFb_PRTDSI__SYNC_OUT       (* (reg8 *) gripperFb__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(gripperFb__SIO_CFG)
    #define gripperFb_SIO_HYST_EN        (* (reg8 *) gripperFb__SIO_HYST_EN)
    #define gripperFb_SIO_REG_HIFREQ     (* (reg8 *) gripperFb__SIO_REG_HIFREQ)
    #define gripperFb_SIO_CFG            (* (reg8 *) gripperFb__SIO_CFG)
    #define gripperFb_SIO_DIFF           (* (reg8 *) gripperFb__SIO_DIFF)
#endif /* (gripperFb__SIO_CFG) */

/* Interrupt Registers */
#if defined(gripperFb__INTSTAT)
    #define gripperFb_INTSTAT            (* (reg8 *) gripperFb__INTSTAT)
    #define gripperFb_SNAP               (* (reg8 *) gripperFb__SNAP)
    
	#define gripperFb_0_INTTYPE_REG 		(* (reg8 *) gripperFb__0__INTTYPE)
#endif /* (gripperFb__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_gripperFb_H */


/* [] END OF FILE */
