/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include "gripper.h"

uint16 grip(uint16 gripPosI)
{
    uint16 gripPos = gripPosI;
    uint16 Result = 0;
    uint16 value;
    uint16 temp;
    
    if(gripClosed_Read()==0 && gripOpen_Read()!=0) //close
    {
        LCD_Position(0,0);
      //  LCD_PrintString("grab");
        CyDelay(10);
        if(gripPos<4000)
        {
            
            for(int i=0; i<=7; i++)
            {
                ADC_Grip_IsEndConversion(ADC_Grip_WAIT_FOR_RESULT);   //ADC_Grip 
                temp = ADC_Grip_CountsTo_mVolts(ADC_Grip_GetResult16());
                Result=Result+ temp;
            } 
            value = Result/8;
            if(value < /*ADC voltage value just before spike*/)
            {
                gripPos+=2;
            }
            else
            {
                gripPos = gripPos;
            }
        }
        else
        {
            gripPos=4000;
        }
    }
    else if (gripOpen_Read()==0 && gripClosed_Read()!=0) // open
    {
        LCD_Position(0,0);
      //  LCD_PrintString("rlse");
        if(gripPos>2400)
        {
            gripPos-=2;
        }
        else
        {
            gripPos=2400;
        }
    }
    else if (gripOpen_Read() !=0 && gripClosed_Read()!=0)
    {
       LCD_Position(0,0);
       //CyDelay(100);
     //  LCD_PrintString("grip");
    }
PWM_G_WriteCompare(gripPos);
return gripPos;
}
