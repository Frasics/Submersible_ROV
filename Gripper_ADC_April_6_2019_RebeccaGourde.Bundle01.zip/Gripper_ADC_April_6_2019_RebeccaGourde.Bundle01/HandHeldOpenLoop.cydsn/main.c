/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include "math.h"
#include "ballast.h"
#include "thrust.h"
#include "DivingPlanes.h"
#include "gripper.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //thrust intiations
    ADC_X_Start();
    ADC_Y_Start();
    ADC_X_StartConvert();
    ADC_Y_StartConvert();
    PWM_T_Start();
    //end of thruster initialization
    
    //start peripherals
    LCD_Start();
    clk_Start();
    //endof peripherals
    
    //Beginning of Diving Planes Initialization
    PWM_D_Start();
    //end of diving planes initializations
  
    //beginning of gripper initialization
    PWM_G_Start();
    ADC_Grip_Start();
    ADC_Grip_StartConvert();
    //end of gripper initialization
    uint16 gripPosI =0;
    for(;;)
    {
        LCD_Position(0,0);
        ballast();
      //  LCD_PrintNumber(ballast());
       // uint16 test = DiveUp_Read();
       // LCD_PrintNumber(test);
        gripPosI = grip(gripPosI);
        
        divingPlanes();
        thrust();//ADC_X,ADC_Y, y, speedMag1,speedMag2);
       //CyDelay(10);
    }
}
