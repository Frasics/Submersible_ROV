/*******************************************************************************
* File Name: BallastDown.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BallastDown_H) /* Pins BallastDown_H */
#define CY_PINS_BallastDown_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BallastDown_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BallastDown__PORT == 15 && ((BallastDown__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BallastDown_Write(uint8 value);
void    BallastDown_SetDriveMode(uint8 mode);
uint8   BallastDown_ReadDataReg(void);
uint8   BallastDown_Read(void);
void    BallastDown_SetInterruptMode(uint16 position, uint16 mode);
uint8   BallastDown_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BallastDown_SetDriveMode() function.
     *  @{
     */
        #define BallastDown_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BallastDown_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BallastDown_DM_RES_UP          PIN_DM_RES_UP
        #define BallastDown_DM_RES_DWN         PIN_DM_RES_DWN
        #define BallastDown_DM_OD_LO           PIN_DM_OD_LO
        #define BallastDown_DM_OD_HI           PIN_DM_OD_HI
        #define BallastDown_DM_STRONG          PIN_DM_STRONG
        #define BallastDown_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BallastDown_MASK               BallastDown__MASK
#define BallastDown_SHIFT              BallastDown__SHIFT
#define BallastDown_WIDTH              1u

/* Interrupt constants */
#if defined(BallastDown__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BallastDown_SetInterruptMode() function.
     *  @{
     */
        #define BallastDown_INTR_NONE      (uint16)(0x0000u)
        #define BallastDown_INTR_RISING    (uint16)(0x0001u)
        #define BallastDown_INTR_FALLING   (uint16)(0x0002u)
        #define BallastDown_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BallastDown_INTR_MASK      (0x01u) 
#endif /* (BallastDown__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BallastDown_PS                     (* (reg8 *) BallastDown__PS)
/* Data Register */
#define BallastDown_DR                     (* (reg8 *) BallastDown__DR)
/* Port Number */
#define BallastDown_PRT_NUM                (* (reg8 *) BallastDown__PRT) 
/* Connect to Analog Globals */                                                  
#define BallastDown_AG                     (* (reg8 *) BallastDown__AG)                       
/* Analog MUX bux enable */
#define BallastDown_AMUX                   (* (reg8 *) BallastDown__AMUX) 
/* Bidirectional Enable */                                                        
#define BallastDown_BIE                    (* (reg8 *) BallastDown__BIE)
/* Bit-mask for Aliased Register Access */
#define BallastDown_BIT_MASK               (* (reg8 *) BallastDown__BIT_MASK)
/* Bypass Enable */
#define BallastDown_BYP                    (* (reg8 *) BallastDown__BYP)
/* Port wide control signals */                                                   
#define BallastDown_CTL                    (* (reg8 *) BallastDown__CTL)
/* Drive Modes */
#define BallastDown_DM0                    (* (reg8 *) BallastDown__DM0) 
#define BallastDown_DM1                    (* (reg8 *) BallastDown__DM1)
#define BallastDown_DM2                    (* (reg8 *) BallastDown__DM2) 
/* Input Buffer Disable Override */
#define BallastDown_INP_DIS                (* (reg8 *) BallastDown__INP_DIS)
/* LCD Common or Segment Drive */
#define BallastDown_LCD_COM_SEG            (* (reg8 *) BallastDown__LCD_COM_SEG)
/* Enable Segment LCD */
#define BallastDown_LCD_EN                 (* (reg8 *) BallastDown__LCD_EN)
/* Slew Rate Control */
#define BallastDown_SLW                    (* (reg8 *) BallastDown__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BallastDown_PRTDSI__CAPS_SEL       (* (reg8 *) BallastDown__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BallastDown_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BallastDown__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BallastDown_PRTDSI__OE_SEL0        (* (reg8 *) BallastDown__PRTDSI__OE_SEL0) 
#define BallastDown_PRTDSI__OE_SEL1        (* (reg8 *) BallastDown__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BallastDown_PRTDSI__OUT_SEL0       (* (reg8 *) BallastDown__PRTDSI__OUT_SEL0) 
#define BallastDown_PRTDSI__OUT_SEL1       (* (reg8 *) BallastDown__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BallastDown_PRTDSI__SYNC_OUT       (* (reg8 *) BallastDown__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BallastDown__SIO_CFG)
    #define BallastDown_SIO_HYST_EN        (* (reg8 *) BallastDown__SIO_HYST_EN)
    #define BallastDown_SIO_REG_HIFREQ     (* (reg8 *) BallastDown__SIO_REG_HIFREQ)
    #define BallastDown_SIO_CFG            (* (reg8 *) BallastDown__SIO_CFG)
    #define BallastDown_SIO_DIFF           (* (reg8 *) BallastDown__SIO_DIFF)
#endif /* (BallastDown__SIO_CFG) */

/* Interrupt Registers */
#if defined(BallastDown__INTSTAT)
    #define BallastDown_INTSTAT            (* (reg8 *) BallastDown__INTSTAT)
    #define BallastDown_SNAP               (* (reg8 *) BallastDown__SNAP)
    
	#define BallastDown_0_INTTYPE_REG 		(* (reg8 *) BallastDown__0__INTTYPE)
#endif /* (BallastDown__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BallastDown_H */


/* [] END OF FILE */
