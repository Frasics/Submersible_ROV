/*******************************************************************************
* File Name: Cap_AMuxCH0.h
* Version 3.50
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module CapSense_CSD_AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_AMUX_Cap_AMuxCH0_H)
#define CY_CAPSENSE_CSD_AMUX_Cap_AMuxCH0_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void Cap_AMuxCH0_Start(void);
void Cap_AMuxCH0_Init(void);
void Cap_AMuxCH0_Stop(void);
void Cap_AMuxCH0_Select(uint8 channel) CYREENTRANT;
void Cap_AMuxCH0_FastSelect(uint8 channel) CYREENTRANT;
void Cap_AMuxCH0_DisconnectAll(void) CYREENTRANT;
/* The Connect and Disconnect functions are declared elsewhere */
/* void Cap_AMuxCH0_Connect(uint8 channel); */
/* void Cap_AMuxCH0_Disconnect(uint8 channel); */


/***************************************
*     Initial Parameter Constants
***************************************/

#define Cap_AMuxCH0_CHANNELS  (2u + 2u +1u+ 0u)
#define Cap_AMuxCH0_MUXTYPE   (1u)


/***************************************
*             API Constants
***************************************/

#define Cap_AMuxCH0_NULL_CHANNEL   (0xFFu)
#define Cap_AMuxCH0_MUX_SINGLE     (1u)
#define Cap_AMuxCH0_MUX_DIFF       (2u)


/***************************************
*        Conditional Functions
***************************************/

#if (Cap_AMuxCH0_MUXTYPE == Cap_AMuxCH0_MUX_SINGLE)
#define Cap_AMuxCH0_Connect(channel) Cap_AMuxCH0_Set(channel)
#define Cap_AMuxCH0_Disconnect(channel) Cap_AMuxCH0_Unset(channel)
#else
    void Cap_AMuxCH0_Connect(uint8 channel) CYREENTRANT;
    void Cap_AMuxCH0_Disconnect(uint8 channel) CYREENTRANT;
#endif  /* End (Cap_AMuxCH0_MUXTYPE == Cap_AMuxCH0_MUX_SINGLE) */

#endif /* CY_CAPSENSE_CSD_AMUX_Cap_AMuxCH0_H */


/* [] END OF FILE */
