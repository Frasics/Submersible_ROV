
#include "project.h"
#include "DivingPlanes.h"

uint16 pos = 0;

void divingPlanes()
{
    if(DiveUp_Read() == 0 && DiveDown_Read()!=0) // go down
    {
        LCD_Position(0,6);
     //   LCD_PrintString("down");
        if(pos<4000)
        {
            pos+=10;
        }
        else
        {
            pos=4000;
        }
    }
    else if (DiveUp_Read()!=0 && DiveDown_Read() == 0) // go up
    {
        LCD_Position(0,6);
     //   LCD_PrintString("up  ");
        if(pos>2000)
        {
            pos-=10;
        }
        else
        {
            pos=2000;
        }
    }
    else
    {
        LCD_Position(0,6);
     //   LCD_PrintString("flat");
        pos=3000;
    }
    PWM_D_WriteCompare(pos);
}