/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include "OBG.h"
/*
uint16 pos = 4000;

void OBG(){
    if(c_Read()== 0 && o_Read()!=0) //open
    {
        LCD_Position(0,6);
        LCD_PrintString("open ");
        if(pos<4000)
        {
            pos+=2;
        }
        else
        {
            pos=4000;
        }
    }
    else if (o_Read()==0 && c_Read() != 0) // close
    {
        LCD_Position(0,6);
        LCD_PrintString("close  ");
        if(pos>2400)
        {
            pos-=2;
        }
        else
        {
            pos=2400;
        }
    }
    else
    {
        LCD_Position(0,6);
        LCD_PrintString("none  ");
    }
PWM_G_WriteCompare(pos);
}


void gripShutoff()
{
}
*/