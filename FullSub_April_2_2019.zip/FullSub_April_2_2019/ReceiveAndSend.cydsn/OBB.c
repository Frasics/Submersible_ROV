/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "OBB.h"
#include "Pressure.h"

void obb()//uint8 BallastOnIn,uint8 BallastDirIn) //On Board Ballast
{
    uint16 IR = 0;
    uint16 temp = 0;
    uint16 Result = 0;
    BallastDirOut_Write(BallastDirIn_Read());
    volatile uint8 BallastOnIn = BallastOnIn_Read();
    
    //Gets IR info
    for(uint8 i=0; i<=7; i++)
        {
            ADC_Seq_IsEndConversion(ADC_Seq_WAIT_FOR_RESULT);
            temp = ADC_Seq_CountsTo_mVolts(ADC_Seq_GetResult16(0));
            Result=Result + temp;
        } 
    IR = Result/8;
    Result = 0;
    
     // DOWN  Actuator goes out
    if((BallastOnIn != 0) & (BallastDirIn_Read() == 0))
    {
        // BallastDirOut_Write(1);
        if (IR > 2200) //Feedback w/ IR
        {
            PWM_Ballast_WriteCompare(255);
        }
        else // stop the actuator
        {
            PWM_Ballast_WriteCompare(0);
        }
    }
    
    //causes it to rise. Actuator goes in
    else if ((BallastOnIn != 0) & (BallastDirIn_Read() != 0))
    {
        PWM_Ballast_WriteCompare(255);
       // BallastDirOut_Write(0);
    }
    // no more movement
    else
    {
        PWM_Ballast_WriteCompare(0);
      //  BallastDirOut_Write(0);
    }
}

//PID Ballast Controller
/*
void holdDepth() //takes in sensor data from the Pressure sensor and uses that to hold a certain pressure
{
    volatile float curDepth = getDepth();
    
    unsigned long lastTime;
    double output = 0, setpoint = 0;
    double errSum = 0, lastErr = 0;
    double kp = 10;
    double ki = 4;
    double kd = 3;
    
    
    //calculating how long its been since last run
    unsigned long now = millis();
    double timeChange = (double)(now -lastTime);
    
    double error = setpoint - curDepth;
    errSum+=(error*timeChange);
    double dErr = (error-lastErr)/timeChange;
    
    //compute PID output
    output = kp*error +ki*errSum +kd*dErr;
    lastErr = error;
    lastTime = now;
    
    if (curDepth < getDepth()) // if it starts to rise
    {
        BallastOnIn_Write(1);
        BallastDirOut_Write(0); //sets direction down
    }
    else if(curDepth > getDepth()) //if it begins to sink
    {
        BallastOnIn_Write(1);
        BallastDirOut_Write(1); // sets direction up
    }
    CyDelay(output);
    //  turn off ballast again
        BallastOnIn_Write(0);
        BallastDirOut_Write(0);
    
}
*/