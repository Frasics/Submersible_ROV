/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
#include "project.h"

#ifndef _OBG_h_included
    #define _OBG_h_included
    //void obb(uint8 BllastOnIn, uint8 BallastDirIn);
   
#endif

/* [] END OF FILE */
