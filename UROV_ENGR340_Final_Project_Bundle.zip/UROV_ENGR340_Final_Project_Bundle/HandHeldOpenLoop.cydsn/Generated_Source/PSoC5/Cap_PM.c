/*******************************************************************************
* File Name: Cap_PM.c
* Version 3.50
*
* Description:
*  This file provides Sleep APIs for CapSense CSD Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Cap.h"

Cap_BACKUP_STRUCT Cap_backup =
{   
    0x00u, /* enableState; */
    
};


/*******************************************************************************
* Function Name: Cap_SaveConfig
********************************************************************************
*
* Summary:
*  Saves customer configuration of CapSense none-retention registers. Resets 
*  all sensors to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Function Cap_SaveConfig disconnects all sensors from the
*  Analog MUX Bus and puts them into inactive state. Call this function
*  during the active scan can cause unpredictable component behavior.
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  Cap_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
* Reentrant:
*  Yes.
*
*******************************************************************************/
void Cap_SaveConfig(void) 
{    

    /* Set CONTROL_REG */
    Cap_backup.ctrlReg = Cap_CONTROL_REG;

    /* Clear all sensors */
    Cap_ClearSensors();
    
    /* The pins disable is customer concern: Cmod and Rb */
}


/*******************************************************************************
* Function Name: Cap_Sleep
********************************************************************************
*
* Summary:
*  Disables Active mode power template bits for number of component used within 
*  CapSense. Calls Cap_SaveConfig() function to save customer 
*  configuration of CapSense none-retention registers and resets all sensors 
*  to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Function Cap_Sleep disconnects all sensors from the
*  Analog MUX Bus and puts them into inactive state. Call this function
*  during the active scan can cause unpredictable component behavior.
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  Cap_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
* Reentrant:
*  No
*
*******************************************************************************/
void Cap_Sleep(void) 
{
    /* Check and save enable state */
    if(Cap_IS_CAPSENSE_ENABLE(Cap_CONTROL_REG))
    {
        Cap_backup.enableState = 1u;
        Cap_Stop();
    }
    else
    {
        Cap_backup.enableState = 0u;
    }
    
    Cap_SaveConfig();
}


/*******************************************************************************
* Function Name: Cap_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores CapSense configuration and non-retention register values.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Must be called only after Cap_SaveConfig() routine. Otherwise 
*  the component configuration will be overwritten with its initial setting.
*  This finction modifies the CONTROL_REG register. 
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  Cap_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
*******************************************************************************/
void Cap_RestoreConfig(void) 
{       
    /* Set PRS */
    #if (Cap_PRS_OPTIONS == Cap_PRS_8BITS)        
        /* Write FIFO with seed */
        Cap_SEED_COPY_REG = Cap_MEASURE_FULL_RANGE_LOW;               /* F0 register */
    
    #elif (Cap_PRS_OPTIONS == Cap_PRS_16BITS)
        /* Write FIFO with seed */
        CY_SET_REG16(Cap_SEED_COPY_PTR, Cap_MEASURE_FULL_RANGE);      /* F0 register */
                
    #elif (Cap_PRS_OPTIONS == Cap_PRS_16BITS_4X)
        
        /* Write FIFO with seed */
        Cap_SEED_COPY_A__F1_REG = Cap_MEASURE_FULL_RANGE_LOW;         /* F0 register */
        Cap_SEED_COPY_A__F0_REG =Cap_MEASURE_FULL_RANGE_LOW;          /* F1 register */
        
    #else
        /* Do nothing = config without PRS */
    #endif  /* (Cap_PRS_OPTIONS == Cap_PRS_8BITS) */
    
    /* Set the Measure */
    #if (Cap_IMPLEMENTATION_CH0 == Cap_MEASURE_IMPLEMENTATION_FF)
        /* Window PWM  - FF Timer register are retention */
        /* Raw Counter - FF Timer register are retention */
    #else
        
        /* Window PWM */
        Cap_PWM_CH0_PERIOD_LO_REG    = Cap_MEASURE_FULL_RANGE_LOW;        /* F0 register */
        
        /* Raw Counter */
        Cap_RAW_CH0_PERIOD_HI_REG    = Cap_MEASURE_FULL_RANGE_LOW;        /* F1 register */
        Cap_RAW_CH0_PERIOD_LO_REG    = Cap_MEASURE_FULL_RANGE_LOW;        /* F0 register */
    
    #endif  /* (Cap_IMPLEMENTATION_CH0 == Cap_MEASURE_IMPLEMENTATION_FF) */ 
    
    #if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
        #if (Cap_IMPLEMENTATION_CH1 == Cap_MEASURE_IMPLEMENTATION_FF)
            /* Window PWM  - FF Timer register are retention */
            /* Raw Counter - FF Timer register are retention */
        #else
            
            /* Window PWM */
            Cap_PWM_CH1_PERIOD_LO_REG    = Cap_MEASURE_FULL_RANGE_LOW;       /* F0 register */
            
            /* Raw Counter */
            Cap_RAW_CH1_PERIOD_HI_REG    = Cap_MEASURE_FULL_RANGE_LOW;       /* F1 register */
            Cap_RAW_CH1_PERIOD_LO_REG    = Cap_MEASURE_FULL_RANGE_LOW;       /* F0 register */
            
        #endif  /* (Cap_IMPLEMENTATION_CH1 == Cap_MEASURE_IMPLEMENTATION_FF) */
    
    #endif  /* (Cap_DESIGN_TYPE == TWO_CHANNELS_DESIGN)*/

    /* Set CONTROL_REG */
    Cap_CONTROL_REG = Cap_backup.ctrlReg;

    /* Enable window generation */
    #if (Cap_DESIGN_TYPE == Cap_ONE_CHANNEL_DESIGN)
        Cap_CONTROL_REG |= Cap_CTRL_WINDOW_EN__CH0;
    #elif (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN) 
        Cap_CONTROL_REG |= (Cap_CTRL_WINDOW_EN__CH0 | Cap_CTRL_WINDOW_EN__CH1); 
    #endif  /* Cap_DESIGN_TYPE */
 
    /* The pins enable are customer concern: Cmod and Rb */
 }
 

/*******************************************************************************
* Function Name: Cap_Wakeup
********************************************************************************
*
* Summary:
*  Restores CapSense configuration and non-retention register values. 
*  Restores enabled state of component by setting Active mode power template 
*  bits for number of component used within CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Must be called only after Cap_SaveConfig() routine. Otherwise 
*  the component configuration will be overwritten with its initial setting.
*  This finction modifies the CONTROL_REG register. 
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  Cap_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
*******************************************************************************/
void Cap_Wakeup(void) 
{
    Cap_RestoreConfig();
    
    /* Restore CapSense Enable state */
    if (Cap_backup.enableState != 0u)
    {
        Cap_Enable();
    }
}


/* [] END OF FILE */
