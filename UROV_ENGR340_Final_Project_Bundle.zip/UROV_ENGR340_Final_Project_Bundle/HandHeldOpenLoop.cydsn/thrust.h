#include "project.h"
#include "math.h"

//NO LONGER IN USE. MOVED TO -059

//definitions for potentiometer thresholds
#define maxPot 4999 // max potentiometer value (5V)
#define Forwardthresh 3900 // threshold where thrusters go forwards
#define Backwardthresh 2380 // backwards threshold
#define Rightthresh 3900 // joystick to the left 
#define Leftthresh 2000 // joystick to the right

#ifndef _thrust_h_included
    #define _thrust_h_included
    void thrust();
#endif