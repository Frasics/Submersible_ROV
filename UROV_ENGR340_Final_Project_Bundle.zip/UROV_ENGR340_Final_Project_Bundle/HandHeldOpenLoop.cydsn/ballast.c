
#include "project.h"
#include "ballast.h"

void ballast()
{
    //reading logic button values
    uint8 bu = BallastUp_Read(); 
    uint8 bd = BallastDown_Read();
    
	if (bu!=1 && bd==1) //if up is pressed. This evacuates the ballast tank
	{   
        //signal LEDS for pilot
        LED1_Write(1u);
        LED2_Write(0u);
        //////////////////////////////
        //         up              //
        /////////////////////////////
        
        //these logic values are sent down to the UROV
        BallastDirOut_Write(1u); 
        BallastOnOut_Write(1u);          
      
    }

	else if (bu==1 && bd!=1) // if down is pressed. this is to fill the ballast
	{     
        //signal LEDS for pilot
        LED1_Write(0u);
        LED2_Write(1u);
        
        //////////////////////////////
        //         DOWN            //
        ///////////////////////////// 
        //these logic values are sent down to the UROV
        BallastOnOut_Write(1u); 
        BallastDirOut_Write(0u);
	}
	else
	{
        //No logic igh values are sent. Holds everything low, aids with signal crossover since everything is kept to "ground"
		LED1_Write(0u);
        LED2_Write(0u);
        BallastOnOut_Write(0u);
        BallastDirOut_Write(0u);
	}
}