/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include "math.h"
#include "ballast.h"
#include "DivingPlanes.h"
#include "gripper.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //start peripherals
    LCD_Start();
    clk_Start();
    //end of peripherals
    
    //Beginning of Diving Planes Initialization
    PWM_D_Start();
    //end of diving planes initializations
  
    //beginning of gripper initialization
    PWM_G_Start();
    //end of gripper initialization
    uint16 gripPosI =0;
    for(;;)
    {
        LCD_Position(0,0);
        ballast(); // send ballast signals down
        gripPosI = grip(gripPosI); //operate gripper
        divingPlanes(); //operate diving planes
    }
}
