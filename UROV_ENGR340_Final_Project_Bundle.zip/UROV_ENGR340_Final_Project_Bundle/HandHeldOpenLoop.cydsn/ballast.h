//normal header file declaring functions
#include "project.h"

#ifndef _ballast_h_included
    #define _ballast_h_included
    void ballast(); 
#endif

