//normal header file declaring functions
#include "project.h"
#ifndef _DivingPlanes_h_included
    #define _DivingPlanes_h_included
    void divingPlanes();
#endif
