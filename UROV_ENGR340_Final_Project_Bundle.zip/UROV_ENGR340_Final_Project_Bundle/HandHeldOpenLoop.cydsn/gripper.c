/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/

#include "project.h"
#include "gripper.h"

uint16 grip(uint16 gripPosI)
{
    uint16 gripPos = gripPosI;
    if(gripClosed_Read()==0 && gripOpen_Read()!=0) //close
    {
        LCD_Position(0,0);
        LCD_PrintString("grab");
        CyDelay(10); //for readibility
        if(gripPos<4000) //if pos is less than max
        {
            gripPos+=2; //increment slowly
        }
        else // hold max
        {
            gripPos=4000;
        }
    }
    else if (gripOpen_Read()==0 && gripClosed_Read()!=0) // open
    {
        LCD_Position(0,0);
        LCD_PrintString("rlse");
        if(gripPos>2400) //if its greater than min
        {
            gripPos-=2; // increment slowly
        }
        else //hold min pos
        {
            gripPos=2400;
        }
    }
PWM_G_WriteCompare(gripPos);
return gripPos;
}