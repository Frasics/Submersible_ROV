#include "project.h"
#include "DivingPlanes.h"

uint16 pos = 0;

void divingPlanes()
{
    if(DiveUp_Read() == 0 && DiveDown_Read()!=0) // go down
    {
        LCD_Position(0,6);
        LCD_PrintString("down");
        
        if(pos<4000) // if its not at the limit
        {
            pos+=10; //to increment diving planes slower than they normally move
        }
        else //if it's at its max position
        {
            pos=4000;
        }
    }
    else if (DiveUp_Read()!=0 && DiveDown_Read() == 0) // go up
    {
        LCD_Position(0,6);
        LCD_PrintString("up  ");
        if(pos>2000) // if its not at its limit
        {
            pos-=10; //to increment diving planes slower than they norma;ly move
        }
        else //if its at its limit hold the position
        {
            pos=2000;
        }
    }
    else
    {
        LCD_Position(0,6);
        LCD_PrintString("flat");
        pos=3000; //return to neutral position. This should be replaced with the stabilization but we never got to it
    }
    PWM_D_WriteCompare(pos);
}