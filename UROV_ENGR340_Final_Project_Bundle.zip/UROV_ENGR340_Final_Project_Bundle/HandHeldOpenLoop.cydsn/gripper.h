//normal header file declaring functions
#include "project.h"

#ifndef _gripper_h_included
    #define _gripper_h_included
    uint16 grip(uint16 gripPosI);
#endif