/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes
 *
 * ========================================
*/
#include "project.h"
#include "bno055Functions.h"
#include <stdio.h> //for calculations

const int READDELAY = 100; //delay const
const int counter = 3000;

//variables for P control
int16 compare = 0;
int16 setpoint = 0;
int16 error = 0;
uint16 pos = 0;

uint8 data = 0; //required for reading/writing
int16 X = 0; //data to use with diving planes
int16 Z = 0; //data to use with thrusters

void initIMU() //function to initialize the IMU
{
    I2C_Start(); //Start I2C component
  
    //turn on front lights
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID
    data = read8(BNO055_CHIP_ID_ADDR);

    //LED's to blink each step
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID and display on LCD
    data = read8(BNO055_ACCEL_REV_ID_ADDR); 
   
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID and display on LCD
    data = read8(BNO055_MAG_REV_ID_ADDR); 
    
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID and display on LCD
    data = read8(BNO055_GYRO_REV_ID_ADDR); 
    
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID and display on LCD
    data = read8(BNO055_SW_REV_ID_LSB_ADDR); 
   
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID and display on LCD
    data = read8(BNO055_SW_REV_ID_MSB_ADDR); 
    
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Read device ID and display on LCD
    data = read8(BNO055_BL_REV_ID_ADDR); 
   
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Set to configure mode
   
    write8(BNO055_OPR_MODE_ADDR, POWER_MODE_NORMAL );
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Set units
    uint8_t unitsel = (1 << 7) | // Orientation = Android (disagrees with code, agrees with datasheet)
                    (0 << 4) | // Temperature = Celsius
                    (0 << 2) | // Euler = Degrees
                    (0 << 1) | // Gyro = Degrees
                    (0 << 0);  // Accelerometer = m/s^2
    write8(BNO055_UNIT_SEL_ADDR , unitsel);
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Stop future resets
    write8(BNO055_SYS_TRIGGER_ADDR, 0x00); //stopping any future resets
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Set to IMU mode
    write8(BNO055_OPR_MODE_ADDR , OPERATION_MODE_IMUPLUS );
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    //Check the status and blink 5 times if set to Sensor Fusion
    uint8 status = read8(BNO055_SYS_STAT_ADDR );
    if(status == 5) { //should be 5 if sensor fusion
        LED1_Write(1);
        LED2_Write(1);
        CyDelay(200);
        LED1_Write(0);
        LED2_Write(0);
        CyDelay(200);
        LED1_Write(1);
        LED2_Write(1);
        CyDelay(200);
        LED1_Write(0);
        LED2_Write(0);
        
    }
    else { //long blinks so we know it is not properly set
        LED1_Write(1);
        LED2_Write(1);
        CyDelay(READDELAY*3);
        LED1_Write(0);
        LED2_Write(0);
        CyDelay(READDELAY*3);
        LED1_Write(1);
        LED2_Write(1);
        CyDelay(READDELAY*3);
        LED1_Write(0);
        LED2_Write(0);
        CyDelay(READDELAY*3);
        LED1_Write(1);
        LED2_Write(1);
        CyDelay(READDELAY*3);
        LED1_Write(0);
        LED2_Write(0);
    }
    CyDelay(READDELAY);
    //Calibrate sensors
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(10000); 
    LED1_Write(0);
    LED2_Write(0);
    //Check calibration status
    status = read8(BNO055_CALIB_STAT_ADDR );
    uint8 systatus = (status & 0b11000000) >> 6;
    uint8 gyrstatus = (status & 0b00110000) >> 4;
    uint8 accstatus = (status & 0b00001100) >> 2;
    uint8 magstatus = (status & 0b00000011);
    LED1_Write(1);
    LED2_Write(1);
    CyDelay(READDELAY);
    LED1_Write(0);
    LED2_Write(0);
    CyDelay(READDELAY);
    LED1_Write(1);
    LED2_Write(1);
}

float readXQuat() //function for reading X quaternion
{
    X = read16(BNO055_QUATERNION_DATA_X_LSB_ADDR);
    return X;
}

float readZQuat() //function for reading Z quaternion
{
    Z = read16(BNO055_QUATERNION_DATA_X_LSB_ADDR);
    return Z;
}

void write8(uint8 Reg, uint32 value ) //function for writing to IMU
{
    uint8 status = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    status = I2C_MasterWriteByte(Reg );
    //Write byte to the data register specified by value
    status = I2C_MasterWriteByte(value & 0xFF);
    status = I2C_MasterSendStop();
}

uint8 read8(uint8 Reg) //function for reading int8 from IMU
{
    volatile uint8 status = 0;
    uint8 data = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    //Mask the command bit and the Register to read/Write from
    status = I2C_MasterWriteByte(Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //Send NAK to indicate end of data to be read
    data = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    
    return data;
}

uint16 read16(uint8 Reg) //function for reading int16 from IMU
{
    uint8 status = 0;
    uint16 data = 0;
    uint8 dataL = 0;
    uint8 dataH = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    //Mask the command bit with Comand Increment Mode and the Register to read/Write from
    status = I2C_MasterWriteByte( Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //Send ACK to acknowlege data received
    dataL = I2C_MasterReadByte(I2C_ACK_DATA);
    //Send NAK to indicate end of data to be read
    dataH = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    //Combine 2 uint8 values (High byte and Low byte) into a uint16 value
    data = (uint16) dataH;
    data = data << 8;
    data |= dataL; 
    return data;
}

void readMultiByte(uint8 Reg, uint8 NumberOfValues, uint8 *dest) //function for reading multiple bytes from IMU
{
    uint8 data[NumberOfValues];
    uint8 status = 0;
    int i =0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    status = I2C_MasterWriteByte(Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //receive NumberOfValue - 1 values and send ACK
    for (i=0 ; i< (NumberOfValues - 1); i++){
      data[i] = I2C_MasterReadByte(I2C_ACK_DATA);
    }
    //Receive last value and send NAK
    data[i+1] = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    for (i=0 ; i< (NumberOfValues); i++){
      dest[i] = data[i];
    }
}
