/*******************************************************************************
* File Name: ThrustRightOut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ThrustRightOut_H) /* Pins ThrustRightOut_H */
#define CY_PINS_ThrustRightOut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ThrustRightOut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ThrustRightOut__PORT == 15 && ((ThrustRightOut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    ThrustRightOut_Write(uint8 value);
void    ThrustRightOut_SetDriveMode(uint8 mode);
uint8   ThrustRightOut_ReadDataReg(void);
uint8   ThrustRightOut_Read(void);
void    ThrustRightOut_SetInterruptMode(uint16 position, uint16 mode);
uint8   ThrustRightOut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the ThrustRightOut_SetDriveMode() function.
     *  @{
     */
        #define ThrustRightOut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define ThrustRightOut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define ThrustRightOut_DM_RES_UP          PIN_DM_RES_UP
        #define ThrustRightOut_DM_RES_DWN         PIN_DM_RES_DWN
        #define ThrustRightOut_DM_OD_LO           PIN_DM_OD_LO
        #define ThrustRightOut_DM_OD_HI           PIN_DM_OD_HI
        #define ThrustRightOut_DM_STRONG          PIN_DM_STRONG
        #define ThrustRightOut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define ThrustRightOut_MASK               ThrustRightOut__MASK
#define ThrustRightOut_SHIFT              ThrustRightOut__SHIFT
#define ThrustRightOut_WIDTH              1u

/* Interrupt constants */
#if defined(ThrustRightOut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in ThrustRightOut_SetInterruptMode() function.
     *  @{
     */
        #define ThrustRightOut_INTR_NONE      (uint16)(0x0000u)
        #define ThrustRightOut_INTR_RISING    (uint16)(0x0001u)
        #define ThrustRightOut_INTR_FALLING   (uint16)(0x0002u)
        #define ThrustRightOut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define ThrustRightOut_INTR_MASK      (0x01u) 
#endif /* (ThrustRightOut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ThrustRightOut_PS                     (* (reg8 *) ThrustRightOut__PS)
/* Data Register */
#define ThrustRightOut_DR                     (* (reg8 *) ThrustRightOut__DR)
/* Port Number */
#define ThrustRightOut_PRT_NUM                (* (reg8 *) ThrustRightOut__PRT) 
/* Connect to Analog Globals */                                                  
#define ThrustRightOut_AG                     (* (reg8 *) ThrustRightOut__AG)                       
/* Analog MUX bux enable */
#define ThrustRightOut_AMUX                   (* (reg8 *) ThrustRightOut__AMUX) 
/* Bidirectional Enable */                                                        
#define ThrustRightOut_BIE                    (* (reg8 *) ThrustRightOut__BIE)
/* Bit-mask for Aliased Register Access */
#define ThrustRightOut_BIT_MASK               (* (reg8 *) ThrustRightOut__BIT_MASK)
/* Bypass Enable */
#define ThrustRightOut_BYP                    (* (reg8 *) ThrustRightOut__BYP)
/* Port wide control signals */                                                   
#define ThrustRightOut_CTL                    (* (reg8 *) ThrustRightOut__CTL)
/* Drive Modes */
#define ThrustRightOut_DM0                    (* (reg8 *) ThrustRightOut__DM0) 
#define ThrustRightOut_DM1                    (* (reg8 *) ThrustRightOut__DM1)
#define ThrustRightOut_DM2                    (* (reg8 *) ThrustRightOut__DM2) 
/* Input Buffer Disable Override */
#define ThrustRightOut_INP_DIS                (* (reg8 *) ThrustRightOut__INP_DIS)
/* LCD Common or Segment Drive */
#define ThrustRightOut_LCD_COM_SEG            (* (reg8 *) ThrustRightOut__LCD_COM_SEG)
/* Enable Segment LCD */
#define ThrustRightOut_LCD_EN                 (* (reg8 *) ThrustRightOut__LCD_EN)
/* Slew Rate Control */
#define ThrustRightOut_SLW                    (* (reg8 *) ThrustRightOut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ThrustRightOut_PRTDSI__CAPS_SEL       (* (reg8 *) ThrustRightOut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ThrustRightOut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ThrustRightOut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ThrustRightOut_PRTDSI__OE_SEL0        (* (reg8 *) ThrustRightOut__PRTDSI__OE_SEL0) 
#define ThrustRightOut_PRTDSI__OE_SEL1        (* (reg8 *) ThrustRightOut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ThrustRightOut_PRTDSI__OUT_SEL0       (* (reg8 *) ThrustRightOut__PRTDSI__OUT_SEL0) 
#define ThrustRightOut_PRTDSI__OUT_SEL1       (* (reg8 *) ThrustRightOut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ThrustRightOut_PRTDSI__SYNC_OUT       (* (reg8 *) ThrustRightOut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(ThrustRightOut__SIO_CFG)
    #define ThrustRightOut_SIO_HYST_EN        (* (reg8 *) ThrustRightOut__SIO_HYST_EN)
    #define ThrustRightOut_SIO_REG_HIFREQ     (* (reg8 *) ThrustRightOut__SIO_REG_HIFREQ)
    #define ThrustRightOut_SIO_CFG            (* (reg8 *) ThrustRightOut__SIO_CFG)
    #define ThrustRightOut_SIO_DIFF           (* (reg8 *) ThrustRightOut__SIO_DIFF)
#endif /* (ThrustRightOut__SIO_CFG) */

/* Interrupt Registers */
#if defined(ThrustRightOut__INTSTAT)
    #define ThrustRightOut_INTSTAT            (* (reg8 *) ThrustRightOut__INTSTAT)
    #define ThrustRightOut_SNAP               (* (reg8 *) ThrustRightOut__SNAP)
    
	#define ThrustRightOut_0_INTTYPE_REG 		(* (reg8 *) ThrustRightOut__0__INTTYPE)
#endif /* (ThrustRightOut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ThrustRightOut_H */


/* [] END OF FILE */
