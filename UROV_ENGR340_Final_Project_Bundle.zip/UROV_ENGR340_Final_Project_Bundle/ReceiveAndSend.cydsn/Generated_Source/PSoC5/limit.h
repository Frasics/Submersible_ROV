/*******************************************************************************
* File Name: limit.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_limit_H) /* Pins limit_H */
#define CY_PINS_limit_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "limit_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 limit__PORT == 15 && ((limit__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    limit_Write(uint8 value);
void    limit_SetDriveMode(uint8 mode);
uint8   limit_ReadDataReg(void);
uint8   limit_Read(void);
void    limit_SetInterruptMode(uint16 position, uint16 mode);
uint8   limit_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the limit_SetDriveMode() function.
     *  @{
     */
        #define limit_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define limit_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define limit_DM_RES_UP          PIN_DM_RES_UP
        #define limit_DM_RES_DWN         PIN_DM_RES_DWN
        #define limit_DM_OD_LO           PIN_DM_OD_LO
        #define limit_DM_OD_HI           PIN_DM_OD_HI
        #define limit_DM_STRONG          PIN_DM_STRONG
        #define limit_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define limit_MASK               limit__MASK
#define limit_SHIFT              limit__SHIFT
#define limit_WIDTH              1u

/* Interrupt constants */
#if defined(limit__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in limit_SetInterruptMode() function.
     *  @{
     */
        #define limit_INTR_NONE      (uint16)(0x0000u)
        #define limit_INTR_RISING    (uint16)(0x0001u)
        #define limit_INTR_FALLING   (uint16)(0x0002u)
        #define limit_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define limit_INTR_MASK      (0x01u) 
#endif /* (limit__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define limit_PS                     (* (reg8 *) limit__PS)
/* Data Register */
#define limit_DR                     (* (reg8 *) limit__DR)
/* Port Number */
#define limit_PRT_NUM                (* (reg8 *) limit__PRT) 
/* Connect to Analog Globals */                                                  
#define limit_AG                     (* (reg8 *) limit__AG)                       
/* Analog MUX bux enable */
#define limit_AMUX                   (* (reg8 *) limit__AMUX) 
/* Bidirectional Enable */                                                        
#define limit_BIE                    (* (reg8 *) limit__BIE)
/* Bit-mask for Aliased Register Access */
#define limit_BIT_MASK               (* (reg8 *) limit__BIT_MASK)
/* Bypass Enable */
#define limit_BYP                    (* (reg8 *) limit__BYP)
/* Port wide control signals */                                                   
#define limit_CTL                    (* (reg8 *) limit__CTL)
/* Drive Modes */
#define limit_DM0                    (* (reg8 *) limit__DM0) 
#define limit_DM1                    (* (reg8 *) limit__DM1)
#define limit_DM2                    (* (reg8 *) limit__DM2) 
/* Input Buffer Disable Override */
#define limit_INP_DIS                (* (reg8 *) limit__INP_DIS)
/* LCD Common or Segment Drive */
#define limit_LCD_COM_SEG            (* (reg8 *) limit__LCD_COM_SEG)
/* Enable Segment LCD */
#define limit_LCD_EN                 (* (reg8 *) limit__LCD_EN)
/* Slew Rate Control */
#define limit_SLW                    (* (reg8 *) limit__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define limit_PRTDSI__CAPS_SEL       (* (reg8 *) limit__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define limit_PRTDSI__DBL_SYNC_IN    (* (reg8 *) limit__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define limit_PRTDSI__OE_SEL0        (* (reg8 *) limit__PRTDSI__OE_SEL0) 
#define limit_PRTDSI__OE_SEL1        (* (reg8 *) limit__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define limit_PRTDSI__OUT_SEL0       (* (reg8 *) limit__PRTDSI__OUT_SEL0) 
#define limit_PRTDSI__OUT_SEL1       (* (reg8 *) limit__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define limit_PRTDSI__SYNC_OUT       (* (reg8 *) limit__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(limit__SIO_CFG)
    #define limit_SIO_HYST_EN        (* (reg8 *) limit__SIO_HYST_EN)
    #define limit_SIO_REG_HIFREQ     (* (reg8 *) limit__SIO_REG_HIFREQ)
    #define limit_SIO_CFG            (* (reg8 *) limit__SIO_CFG)
    #define limit_SIO_DIFF           (* (reg8 *) limit__SIO_DIFF)
#endif /* (limit__SIO_CFG) */

/* Interrupt Registers */
#if defined(limit__INTSTAT)
    #define limit_INTSTAT            (* (reg8 *) limit__INTSTAT)
    #define limit_SNAP               (* (reg8 *) limit__SNAP)
    
	#define limit_0_INTTYPE_REG 		(* (reg8 *) limit__0__INTTYPE)
#endif /* (limit__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_limit_H */


/* [] END OF FILE */
