/*******************************************************************************
* File Name: ADC_Joystick_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2012-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "ADC_Joystick.h"
#include "ADC_Joystick_SAR.h"
#if(ADC_Joystick_CLOCK_SOURCE == ADC_Joystick_CLOCK_INTERNAL)
    #include "ADC_Joystick_IntClock.h"
#endif   /* ADC_Joystick_CLOCK_SOURCE == ADC_Joystick_CLOCK_INTERNAL */


/*******************************************************************************
* Function Name: ADC_Joystick_Sleep
********************************************************************************
*
* Summary:
*  Stops the ADC operation and saves the configuration registers and component
*  enable state. Should be called just prior to entering sleep
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void ADC_Joystick_Sleep(void)
{
    ADC_Joystick_SAR_Stop();
    ADC_Joystick_SAR_Sleep();
    ADC_Joystick_Disable();

    #if(ADC_Joystick_CLOCK_SOURCE == ADC_Joystick_CLOCK_INTERNAL)
        ADC_Joystick_IntClock_Stop();
    #endif   /* ADC_Joystick_CLOCK_SOURCE == ADC_Joystick_CLOCK_INTERNAL */
}


/*******************************************************************************
* Function Name: ADC_Joystick_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component enable state and configuration registers. This should
*  be called just after awaking from sleep mode
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void ADC_Joystick_Wakeup(void)
{
    ADC_Joystick_SAR_Wakeup();
    ADC_Joystick_SAR_Enable();

    #if(ADC_Joystick_CLOCK_SOURCE == ADC_Joystick_CLOCK_INTERNAL)
        ADC_Joystick_IntClock_Start();
    #endif   /* ADC_Joystick_CLOCK_SOURCE == ADC_Joystick_CLOCK_INTERNAL */

    /* The block is ready to use 10 us after the SAR enable signal is set high. */
    CyDelayUs(10u);
    
    ADC_Joystick_Enable();

    #if(ADC_Joystick_SAMPLE_MODE == ADC_Joystick_SAMPLE_MODE_FREE_RUNNING)
        ADC_Joystick_SAR_StartConvert();
    #endif /* (ADC_Joystick_SAMPLE_MODE == ADC_Joystick_SAMPLE_MODE_FREE_RUNNING) */

    (void) CY_GET_REG8(ADC_Joystick_STATUS_PTR);
}


/*******************************************************************************
* Function Name: ADC_Joystick_SaveConfig
********************************************************************************
*
* Summary:
*  Save the current configuration of ADC non-retention registers
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void ADC_Joystick_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: ADC_Joystick_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the configuration of ADC non-retention registers
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void ADC_Joystick_RestoreConfig(void)
{

}


/* [] END OF FILE */
