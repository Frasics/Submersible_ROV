/*******************************************************************************
* File Name: millis_PM.c  
* Version 3.0
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "millis.h"

static millis_backupStruct millis_backup;


/*******************************************************************************
* Function Name: millis_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  millis_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void millis_SaveConfig(void) 
{
    #if (!millis_UsingFixedFunction)

        millis_backup.CounterUdb = millis_ReadCounter();

        #if(!millis_ControlRegRemoved)
            millis_backup.CounterControlRegister = millis_ReadControlRegister();
        #endif /* (!millis_ControlRegRemoved) */

    #endif /* (!millis_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: millis_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  millis_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void millis_RestoreConfig(void) 
{      
    #if (!millis_UsingFixedFunction)

       millis_WriteCounter(millis_backup.CounterUdb);

        #if(!millis_ControlRegRemoved)
            millis_WriteControlRegister(millis_backup.CounterControlRegister);
        #endif /* (!millis_ControlRegRemoved) */

    #endif /* (!millis_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: millis_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  millis_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void millis_Sleep(void) 
{
    #if(!millis_ControlRegRemoved)
        /* Save Counter's enable state */
        if(millis_CTRL_ENABLE == (millis_CONTROL & millis_CTRL_ENABLE))
        {
            /* Counter is enabled */
            millis_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            millis_backup.CounterEnableState = 0u;
        }
    #else
        millis_backup.CounterEnableState = 1u;
        if(millis_backup.CounterEnableState != 0u)
        {
            millis_backup.CounterEnableState = 0u;
        }
    #endif /* (!millis_ControlRegRemoved) */
    
    millis_Stop();
    millis_SaveConfig();
}


/*******************************************************************************
* Function Name: millis_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  millis_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void millis_Wakeup(void) 
{
    millis_RestoreConfig();
    #if(!millis_ControlRegRemoved)
        if(millis_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            millis_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!millis_ControlRegRemoved) */
    
}


/* [] END OF FILE */
