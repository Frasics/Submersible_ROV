/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
//normal header file declaring functions
//WAS NEVER IMPLEMENTED
#include "project.h"

#ifndef _OBG_h_included
    #define _OBG_h_included
    uint16 OBG(uint16 gripPosI);
   
#endif

/* [] END OF FILE */
