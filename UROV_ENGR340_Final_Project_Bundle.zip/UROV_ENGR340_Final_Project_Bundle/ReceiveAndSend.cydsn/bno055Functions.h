/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/

//normal header file declaring functions
#include "project.h"
#include "BNO055.h"

#ifndef _bno055Functions_include
    #define _bno055Functions_include
    void initIMU();
    void readQuats();
    void write8(uint8 Reg, uint32 value);
    uint8 read8(uint8 Reg);
    uint16 read16(uint8 Reg);
    void readMultiByte(uint8 Reg, uint8 NumberOfValues, uint8 *dest);
    float readXQuat();
    float readYQuat();
    float readZQuat();
    uint16 balanceDP(float X);
#endif