/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes
 *
 * ========================================
*/

//WAS NEVER IMPLEMENTED

#include "project.h"
#include "OBG.h"

uint16 gripPos = 4000;
/*
uint16 OBG(uint16 gripPosI){
 
    uint16 gripPos = gripPosI;
    uint16 Result = 0;
    uint16 value;
    uint16 temp;
    
    if(gripClosed_Read()==0 && gripOpen_Read()!=0) //close
    {
        CyDelay(10);
        if(gripPos<4000)
        {
            
            for(int i=0; i<=7; i++)
            {
                ADC_Seq_IsEndConversion(ADC_Seq_WAIT_FOR_RESULT);   //ADC_Grip 
                temp = ADC_Seq_CountsTo_mVolts(ADC_Seq_GetResult16(1));
                Result=Result+ temp;
            } 
            value = Result/8;
            if(value < 2000)//ADC voltage value just before spike
            {
                gripPos+=2;
            }
            else
            {
                gripPos = gripPos;
            }
        }
        else
        {
            gripPos=4000;
        }
    }
    else if (gripOpen_Read()==0 && gripClosed_Read()!=0) // open
    {
        if(gripPos>2400)
        {
            gripPos-=2;
        }
        else
        {
            gripPos=2400;
        }
    }
PWM_G_WriteCompare(gripPos);
return gripPos;
}*/