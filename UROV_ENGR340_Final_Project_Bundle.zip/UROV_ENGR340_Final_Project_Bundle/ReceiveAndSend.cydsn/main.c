/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
#include "project.h"
#include "OBB.h"
#include "Pressure.h"
#include "OBT.h"
#include "OBG.h"
#include "bno055Functions.h"
#include "OBD.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    //initialize ADC for Pressure Sensor, limit switch, and gripper feedback
    ADC_Seq_Start();
    ADC_Seq_StartConvert();

    //starting Ballast,thrusters, and clock
    Clock_Start();
    PWM_T_Start();
    PWM_Ballast_Start();
    ADC_Joystick_Start();
    ADC_Joystick_StartConvert();
    
    //for blue LED on light
    uint16 tog = 0;
    
    //initialize IMU
    //initIMU();
    LED1_Write(1);
    LED2_Write(1);
    
    //initiating the IMU, never had it tested with the full submarine
    //initIMU();
    
    //inital value for grip position NEVER TESTED
    //uint16 gripPosI =0;

    for(;;)
    {

        OBT(); //program that operates the thrusters
        OBD(); //program that operates the diving planes
        obb(); //program that operates the ballast tank

        //gripPosI = grip(gripPosI) NEVER TESTED
        
        //Just  a flashing LED to indicate that the -059 is on
        if (tog <= (65535/8))
        {
            LED_Write(1);
            tog++;
        }
        else if ((tog > (65535/8)) && (tog<65535/4))
        {
            LED_Write(0);
            tog++;
        }
        else
        {
           tog = 0;
        }
    }
}