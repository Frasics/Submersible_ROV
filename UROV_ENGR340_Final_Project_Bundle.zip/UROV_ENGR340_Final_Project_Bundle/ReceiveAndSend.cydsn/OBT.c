/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Xinhao Xie
 *
 * ========================================
*/
#include "project.h"
#include "OBT.h"
 
void OBT()
{
    uint32 ADC_X = ADC_Joystick_CountsTo_mVolts(ADC_Joystick_GetResult16(0));//read Forwards Back Pot
    uint32 ADC_Y = ADC_Joystick_CountsTo_mVolts(ADC_Joystick_GetResult16(1));//read Left Right Pot
    uint8 DIR = 0; //set forwards to start

    if (ADC_X > Forwardthresh) //if tilted forwards
	{   
   	    DIR = 0; //Forward direction to Relays
    	if (ADC_Y < Leftthresh)
    	{   	 
        //Left & forwards
        PWM_T_WriteCompare1(2500);
        PWM_T_WriteCompare2(2000);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //Right & forwards
        PWM_T_WriteCompare1(2000);
        PWM_T_WriteCompare2(2500);
    	}
    	else
    	{
        //Straight forwards
        // thrusters at the same PWM
        //different thresholds for modular speed control
        if (ADC_X > 4000 && ADC_X <4400)
            {
                PWM_T_WriteCompare1(2500);
        	    PWM_T_WriteCompare2(2500);
            }
        else if (ADC_X > 4400 && ADC_X < 4700) 
            {
                PWM_T_WriteCompare1(3000);
        	    PWM_T_WriteCompare2(3000);
            }
            else if (ADC_X > 4700)
            {
                PWM_T_WriteCompare1(3500);
        	    PWM_T_WriteCompare2(3500);
            }
        }
	}
	else if (ADC_X < Backwardthresh) //if tilted backwards
	{
        DIR = 1; // backwards signal to relays
    	if (ADC_Y < Leftthresh)
    	{   	 
        //Left & backwards
        PWM_T_WriteCompare1(2500);
        PWM_T_WriteCompare2(2000);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //Right	& backwards
        PWM_T_WriteCompare1(2000);
        PWM_T_WriteCompare2(2500);
    	}
    	else 
    	{
            //straight backwards
            //different thresholds for modular speed control
            if (ADC_X <Backwardthresh && ADC_X>2000)
            {
                PWM_T_WriteCompare1(2500);
        	    PWM_T_WriteCompare2(2500);
            }
            else if (ADC_X <2000 && ADC_X>1000)
            {
                PWM_T_WriteCompare1(3000);
        	    PWM_T_WriteCompare2(3000);
            }
            else if (ADC_X <1000)
            {
                PWM_T_WriteCompare1(3500);
        	    PWM_T_WriteCompare2(3500);
            }
    	}
	}
	else if (ADC_X<Forwardthresh && ADC_X > Backwardthresh) //not forwards or backwards
	{
        DIR = 0;
    	//Neutral ie not forwards or backwards
    	if (ADC_Y < Leftthresh)
    	{   	 
        //Left on the spot
        PWM_T_WriteCompare1(2100);
        PWM_T_WriteCompare2(1800);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //Right	on the spot
        PWM_T_WriteCompare1(1800);
        PWM_T_WriteCompare2(2100);
    	}
    	else
    	{
        //Neutral neutral, not moving at all. Holding the PWMsat 1700 so the ESCs are primed and dont turn off
        PWM_T_WriteCompare1(1700);
    	PWM_T_WriteCompare2(1700);
    	}
	}
    DIR_Write(DIR);
}