/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
//normal header file declaring functions
#include "project.h"
#include "math.h"

#define freq 4000
 
#define Forwardthresh 4000 // threshold where thrusters go forwards
#define Backwardthresh 2380 // backwards threshold
#define Rightthresh 4000 // joystick to the left 
#define Leftthresh 2000 // joystick to the right

#ifndef _OBT_h_included
    #define _OBT_h_included
    void OBT();
    #endif 