#include "project.h"
#include <stdio.h>
/*
********************
Pressure sensor pins:
Black: Ground
Red: 5V input
Yellow: Analog output
********************
*/
float getDepth() //calculate depth from pressure
{
    float value = 0;
    volatile float P = 0;
    float temp = 0;
    float ResultP = 0;
    
    //to calculate an average for the pressure
    for(int i=0; i<=7; i++)
    {
        ADC_Seq_IsEndConversion(ADC_Seq_WAIT_FOR_RESULT);
        temp = ADC_Seq_CountsTo_mVolts(ADC_Seq_GetResult16(2));
        ResultP = ResultP + temp;
    } 
    value = (float)ResultP/(float)8;
 
     //Calculating pressure using equation given
    P = ((value/(float)5000.0-(float)0.1)/(float)0.75)*1000; //Vout = VCC x (0.75 x P + 0.1), P is Pressure in kPa
   
    //Calculating depth
    float depth = P/(1000.0*9.81);
    return depth;
}