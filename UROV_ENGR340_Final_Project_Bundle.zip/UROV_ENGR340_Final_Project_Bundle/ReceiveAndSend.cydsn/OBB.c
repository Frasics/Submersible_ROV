/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Rebecca Gourde
 *
 * ========================================
*/
#include "project.h"
#include "OBB.h"
#include "Pressure.h"

void obb() //On Board Ballast function
{
 
    uint8 limit = limit_Read(); //read limit switch
    BallastDirOut_Write(BallastDirIn_Read()); //pass through ballast Direction logic
    volatile uint8 BallastOnIn = BallastOnIn_Read();
   
     // DOWN  Actuator goes out
    if((BallastOnIn != 0) && (BallastDirIn_Read() == 0))
    {
        if (limit != 0 ) //Feedback w/ limit switch
        {
            PWM_Ballast_WriteCompare(255);
        }
        else // stop the actuator when it reaches limit
        {
            PWM_Ballast_WriteCompare(0);
        }
    }
    
    //causes it to rise. Actuator goes in
    else if ((BallastOnIn != 0) && (BallastDirIn_Read() != 0))
    {
        PWM_Ballast_WriteCompare(255);
  
    }
    
    // no more movement
    else
    {
        PWM_Ballast_WriteCompare(0);
    }
}

//PID Ballast Controller Never tested or implemented
/*
void holdDepth() //takes in sensor data from the Pressure sensor and uses that to hold a certain pressure
{
    volatile float curDepth = getDepth();
    
    unsigned long lastTime;
    double output = 0, setpoint = 0;
    double errSum = 0, lastErr = 0;
    double kp = 10;
    double ki = 4;
    double kd = 3;
    
    
    //calculating how long its been since last run
    unsigned long now = millis();
    double timeChange = (double)(now -lastTime);
    
    double error = setpoint - curDepth;
    errSum+=(error*timeChange);
    double dErr = (error-lastErr)/timeChange;
    
    //compute PID output
    output = kp*error +ki*errSum +kd*dErr;
    lastErr = error;
    lastTime = now;
    
    if (curDepth < getDepth()) // if it starts to rise
    {
        BallastOnIn_Write(1);
        BallastDirOut_Write(0); //sets direction down
    }
    else if(curDepth > getDepth()) //if it begins to sink
    {
        BallastOnIn_Write(1);
        BallastDirOut_Write(1); // sets direction up
    }
    CyDelay(output);
    //  turn off ballast again
        BallastOnIn_Write(0);
        BallastDirOut_Write(0);
}
*/