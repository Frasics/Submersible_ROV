/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes
 *
 * ========================================
*/

#include "project.h"
#include "OBG.h"
#include "bno055Functions.h"

//variables for P control
int16 setDP = 0;
int16 err = 0;
uint16 posDP = 0;
int16 dp_X = 0; //data to use with diving planes

void OBD()
{
    if(DiveUp_Read() == 0 && DiveDown_Read()!=0) // go down
    {
        if(posDP<4000) //if its less than max
        {
            posDP+=10; //increment pos
        }
        else // hold max
        {
            posDP=4000;
        }
        //for P control
        setDP= dp_X;
        err = 0;
    }
    else if (DiveUp_Read()!=0 && DiveDown_Read() == 0) // go up
    {
        if(posDP>2000) //if greater than min
        {
            posDP-=10; //decrement pos
        }
        else //hold min
        {
            posDP=2000;
        }
        //for P control
        setDP = dp_X;
        err = 0;
    }
    else //stabilize using P control from quaternion
    {
        dp_X = readXQuat(); //read quatvalue
        err = setDP - dp_X; //set error
        posDP = (err / 5.8) + 3000;//calc correction pos for servo
    }
    PWM_D_WriteCompare(posDP);
}