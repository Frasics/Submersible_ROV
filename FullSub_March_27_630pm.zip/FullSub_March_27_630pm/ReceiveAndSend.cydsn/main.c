/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
#include "project.h"
#include "OBB.h"
#include "Pressure.h"
#include "OBT.h"
#include "OBG.h"
#include "bno055Functions.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    //initialize IR sensor
    ADC_Seq_Start();
    ADC_Seq_StartConvert();
    
    //initializing pressure sensor
    ADC_P_Start();
    ADC_P_StartConvert();
    
    //starting Ballast,thrusters, and clock
    Clock_Start();
    PWM_T_Start();
    PWM_Ballast_Start();
    
    //Start counter
    millis_Start();
    
    //for blue LED on light
    uint16 tog = 0;
    
    //initialize IMU
    //initIMU();
    LED1_Write(1);
    LED2_Write(1);
    
    for(;;)
    {
        //Checking all the Signals from the handheld controller
        volatile uint8 BallastDirIn = BallastDirIn_Read();
        volatile uint8 BallastOnIn = BallastOnIn_Read();
        
        ThrustLeftIn_Read();
        ThrustRightIn_Read();
        DivingPlanesIn_Read();
        /*
        if( BallastOnIn == 0) // if no ballast inputs
        {
            holdDepth();
        }
        
        
        else //Acting on the Ballast Inputs
        {*/
            obb(BallastOnIn, BallastDirIn);
        //}
    
        
        //Just  a flashing LED to indicate that it is being powered
        if (tog <= (65535/8))
        {
            LED_Write(1);
            tog++;
        }
        else if ((tog > (65535/8)) && (tog<65535/4))
        {
            LED_Write(0);
            tog++;
        }
        else
        {
           tog = 0;
        }
    }
}