/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "OBT.h"
 
void OBT()
{
    uint32 ADC_X = ThrustLeftIn_Read();
    uint32 ADC_Y = ThrustRightIn_Read();
    uint8 DIR = 1;
	if (ADC_X > Forwardthresh)
	{   
   	    DIR = 1; //Forward direction to Relays
    	if (ADC_Y < Leftthresh)
    	{   	 
        	//Left and forwards
        //	PWM_T_WriteCompare1(2000); //left thruster at low thrust
        //	PWM_T_WriteCompare2(5000-ADC_Y); //right thruster is stronger
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        	//Right and forwards
        //	PWM_T_WriteCompare1(ADC_Y); //left thruster is stronger
        //	PWM_T_WriteCompare2(2000); //right thruster at low thrust
    	}
    	else
    	{
        //Straight forwards
        // thrusters at the same PWM
        //	PWM_T_WriteCompare1(ADC_X); 
        //	PWM_T_WriteCompare2(ADC_X);
    	}
	}
	else if (ADC_X < Backwardthresh)
	{
        DIR =0; // backwards signal to relays
    	if (ADC_Y < Leftthresh)
    	{
        //Left and backwards
        //	PWM_T_WriteCompare1(4000);
        //	PWM_T_WriteCompare2(2300);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //Right and backwards
        //	PWM_T_WriteCompare1(2300);
        //	PWM_T_WriteCompare2(4000);
    	}
    	else 
    	{
        //Straight backwards
        //	PWM_T_WriteCompare1(5000-ADC_X);
        //	PWM_T_WriteCompare2(5000-ADC_X);
    	}
	}
	else //not forwards or backwards
	{
    	//Neutral ie not forwards or backwards
    	if (ADC_Y < Leftthresh)
    	{   	 
        //Left on the spot
        //	PWM_T_WriteCompare1(2300);
        //	PWM_T_WriteCompare2(1700);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //Right	on the spot
        //	PWM_T_WriteCompare1(1700);
        //	PWM_T_WriteCompare2(2300);
    	}
    	else
    	{
        //Neutral neutral, not moving at all
        //	PWM_T_WriteCompare1(1700);
        //	PWM_T_WriteCompare2(1700);
    	}
	}
    DIR_Write(DIR);
}