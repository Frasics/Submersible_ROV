/*******************************************************************************
* File Name: BallastPWMIn.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BallastPWMIn_H) /* Pins BallastPWMIn_H */
#define CY_PINS_BallastPWMIn_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BallastPWMIn_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BallastPWMIn__PORT == 15 && ((BallastPWMIn__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BallastPWMIn_Write(uint8 value);
void    BallastPWMIn_SetDriveMode(uint8 mode);
uint8   BallastPWMIn_ReadDataReg(void);
uint8   BallastPWMIn_Read(void);
void    BallastPWMIn_SetInterruptMode(uint16 position, uint16 mode);
uint8   BallastPWMIn_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BallastPWMIn_SetDriveMode() function.
     *  @{
     */
        #define BallastPWMIn_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BallastPWMIn_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BallastPWMIn_DM_RES_UP          PIN_DM_RES_UP
        #define BallastPWMIn_DM_RES_DWN         PIN_DM_RES_DWN
        #define BallastPWMIn_DM_OD_LO           PIN_DM_OD_LO
        #define BallastPWMIn_DM_OD_HI           PIN_DM_OD_HI
        #define BallastPWMIn_DM_STRONG          PIN_DM_STRONG
        #define BallastPWMIn_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BallastPWMIn_MASK               BallastPWMIn__MASK
#define BallastPWMIn_SHIFT              BallastPWMIn__SHIFT
#define BallastPWMIn_WIDTH              1u

/* Interrupt constants */
#if defined(BallastPWMIn__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BallastPWMIn_SetInterruptMode() function.
     *  @{
     */
        #define BallastPWMIn_INTR_NONE      (uint16)(0x0000u)
        #define BallastPWMIn_INTR_RISING    (uint16)(0x0001u)
        #define BallastPWMIn_INTR_FALLING   (uint16)(0x0002u)
        #define BallastPWMIn_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BallastPWMIn_INTR_MASK      (0x01u) 
#endif /* (BallastPWMIn__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BallastPWMIn_PS                     (* (reg8 *) BallastPWMIn__PS)
/* Data Register */
#define BallastPWMIn_DR                     (* (reg8 *) BallastPWMIn__DR)
/* Port Number */
#define BallastPWMIn_PRT_NUM                (* (reg8 *) BallastPWMIn__PRT) 
/* Connect to Analog Globals */                                                  
#define BallastPWMIn_AG                     (* (reg8 *) BallastPWMIn__AG)                       
/* Analog MUX bux enable */
#define BallastPWMIn_AMUX                   (* (reg8 *) BallastPWMIn__AMUX) 
/* Bidirectional Enable */                                                        
#define BallastPWMIn_BIE                    (* (reg8 *) BallastPWMIn__BIE)
/* Bit-mask for Aliased Register Access */
#define BallastPWMIn_BIT_MASK               (* (reg8 *) BallastPWMIn__BIT_MASK)
/* Bypass Enable */
#define BallastPWMIn_BYP                    (* (reg8 *) BallastPWMIn__BYP)
/* Port wide control signals */                                                   
#define BallastPWMIn_CTL                    (* (reg8 *) BallastPWMIn__CTL)
/* Drive Modes */
#define BallastPWMIn_DM0                    (* (reg8 *) BallastPWMIn__DM0) 
#define BallastPWMIn_DM1                    (* (reg8 *) BallastPWMIn__DM1)
#define BallastPWMIn_DM2                    (* (reg8 *) BallastPWMIn__DM2) 
/* Input Buffer Disable Override */
#define BallastPWMIn_INP_DIS                (* (reg8 *) BallastPWMIn__INP_DIS)
/* LCD Common or Segment Drive */
#define BallastPWMIn_LCD_COM_SEG            (* (reg8 *) BallastPWMIn__LCD_COM_SEG)
/* Enable Segment LCD */
#define BallastPWMIn_LCD_EN                 (* (reg8 *) BallastPWMIn__LCD_EN)
/* Slew Rate Control */
#define BallastPWMIn_SLW                    (* (reg8 *) BallastPWMIn__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BallastPWMIn_PRTDSI__CAPS_SEL       (* (reg8 *) BallastPWMIn__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BallastPWMIn_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BallastPWMIn__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BallastPWMIn_PRTDSI__OE_SEL0        (* (reg8 *) BallastPWMIn__PRTDSI__OE_SEL0) 
#define BallastPWMIn_PRTDSI__OE_SEL1        (* (reg8 *) BallastPWMIn__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BallastPWMIn_PRTDSI__OUT_SEL0       (* (reg8 *) BallastPWMIn__PRTDSI__OUT_SEL0) 
#define BallastPWMIn_PRTDSI__OUT_SEL1       (* (reg8 *) BallastPWMIn__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BallastPWMIn_PRTDSI__SYNC_OUT       (* (reg8 *) BallastPWMIn__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BallastPWMIn__SIO_CFG)
    #define BallastPWMIn_SIO_HYST_EN        (* (reg8 *) BallastPWMIn__SIO_HYST_EN)
    #define BallastPWMIn_SIO_REG_HIFREQ     (* (reg8 *) BallastPWMIn__SIO_REG_HIFREQ)
    #define BallastPWMIn_SIO_CFG            (* (reg8 *) BallastPWMIn__SIO_CFG)
    #define BallastPWMIn_SIO_DIFF           (* (reg8 *) BallastPWMIn__SIO_DIFF)
#endif /* (BallastPWMIn__SIO_CFG) */

/* Interrupt Registers */
#if defined(BallastPWMIn__INTSTAT)
    #define BallastPWMIn_INTSTAT            (* (reg8 *) BallastPWMIn__INTSTAT)
    #define BallastPWMIn_SNAP               (* (reg8 *) BallastPWMIn__SNAP)
    
	#define BallastPWMIn_0_INTTYPE_REG 		(* (reg8 *) BallastPWMIn__0__INTTYPE)
#endif /* (BallastPWMIn__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BallastPWMIn_H */


/* [] END OF FILE */
