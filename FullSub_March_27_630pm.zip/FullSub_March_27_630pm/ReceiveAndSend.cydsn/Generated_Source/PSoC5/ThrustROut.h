/*******************************************************************************
* File Name: ThrustROut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ThrustROut_H) /* Pins ThrustROut_H */
#define CY_PINS_ThrustROut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ThrustROut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ThrustROut__PORT == 15 && ((ThrustROut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    ThrustROut_Write(uint8 value);
void    ThrustROut_SetDriveMode(uint8 mode);
uint8   ThrustROut_ReadDataReg(void);
uint8   ThrustROut_Read(void);
void    ThrustROut_SetInterruptMode(uint16 position, uint16 mode);
uint8   ThrustROut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the ThrustROut_SetDriveMode() function.
     *  @{
     */
        #define ThrustROut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define ThrustROut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define ThrustROut_DM_RES_UP          PIN_DM_RES_UP
        #define ThrustROut_DM_RES_DWN         PIN_DM_RES_DWN
        #define ThrustROut_DM_OD_LO           PIN_DM_OD_LO
        #define ThrustROut_DM_OD_HI           PIN_DM_OD_HI
        #define ThrustROut_DM_STRONG          PIN_DM_STRONG
        #define ThrustROut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define ThrustROut_MASK               ThrustROut__MASK
#define ThrustROut_SHIFT              ThrustROut__SHIFT
#define ThrustROut_WIDTH              1u

/* Interrupt constants */
#if defined(ThrustROut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in ThrustROut_SetInterruptMode() function.
     *  @{
     */
        #define ThrustROut_INTR_NONE      (uint16)(0x0000u)
        #define ThrustROut_INTR_RISING    (uint16)(0x0001u)
        #define ThrustROut_INTR_FALLING   (uint16)(0x0002u)
        #define ThrustROut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define ThrustROut_INTR_MASK      (0x01u) 
#endif /* (ThrustROut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ThrustROut_PS                     (* (reg8 *) ThrustROut__PS)
/* Data Register */
#define ThrustROut_DR                     (* (reg8 *) ThrustROut__DR)
/* Port Number */
#define ThrustROut_PRT_NUM                (* (reg8 *) ThrustROut__PRT) 
/* Connect to Analog Globals */                                                  
#define ThrustROut_AG                     (* (reg8 *) ThrustROut__AG)                       
/* Analog MUX bux enable */
#define ThrustROut_AMUX                   (* (reg8 *) ThrustROut__AMUX) 
/* Bidirectional Enable */                                                        
#define ThrustROut_BIE                    (* (reg8 *) ThrustROut__BIE)
/* Bit-mask for Aliased Register Access */
#define ThrustROut_BIT_MASK               (* (reg8 *) ThrustROut__BIT_MASK)
/* Bypass Enable */
#define ThrustROut_BYP                    (* (reg8 *) ThrustROut__BYP)
/* Port wide control signals */                                                   
#define ThrustROut_CTL                    (* (reg8 *) ThrustROut__CTL)
/* Drive Modes */
#define ThrustROut_DM0                    (* (reg8 *) ThrustROut__DM0) 
#define ThrustROut_DM1                    (* (reg8 *) ThrustROut__DM1)
#define ThrustROut_DM2                    (* (reg8 *) ThrustROut__DM2) 
/* Input Buffer Disable Override */
#define ThrustROut_INP_DIS                (* (reg8 *) ThrustROut__INP_DIS)
/* LCD Common or Segment Drive */
#define ThrustROut_LCD_COM_SEG            (* (reg8 *) ThrustROut__LCD_COM_SEG)
/* Enable Segment LCD */
#define ThrustROut_LCD_EN                 (* (reg8 *) ThrustROut__LCD_EN)
/* Slew Rate Control */
#define ThrustROut_SLW                    (* (reg8 *) ThrustROut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ThrustROut_PRTDSI__CAPS_SEL       (* (reg8 *) ThrustROut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ThrustROut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ThrustROut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ThrustROut_PRTDSI__OE_SEL0        (* (reg8 *) ThrustROut__PRTDSI__OE_SEL0) 
#define ThrustROut_PRTDSI__OE_SEL1        (* (reg8 *) ThrustROut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ThrustROut_PRTDSI__OUT_SEL0       (* (reg8 *) ThrustROut__PRTDSI__OUT_SEL0) 
#define ThrustROut_PRTDSI__OUT_SEL1       (* (reg8 *) ThrustROut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ThrustROut_PRTDSI__SYNC_OUT       (* (reg8 *) ThrustROut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(ThrustROut__SIO_CFG)
    #define ThrustROut_SIO_HYST_EN        (* (reg8 *) ThrustROut__SIO_HYST_EN)
    #define ThrustROut_SIO_REG_HIFREQ     (* (reg8 *) ThrustROut__SIO_REG_HIFREQ)
    #define ThrustROut_SIO_CFG            (* (reg8 *) ThrustROut__SIO_CFG)
    #define ThrustROut_SIO_DIFF           (* (reg8 *) ThrustROut__SIO_DIFF)
#endif /* (ThrustROut__SIO_CFG) */

/* Interrupt Registers */
#if defined(ThrustROut__INTSTAT)
    #define ThrustROut_INTSTAT            (* (reg8 *) ThrustROut__INTSTAT)
    #define ThrustROut_SNAP               (* (reg8 *) ThrustROut__SNAP)
    
	#define ThrustROut_0_INTTYPE_REG 		(* (reg8 *) ThrustROut__0__INTTYPE)
#endif /* (ThrustROut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ThrustROut_H */


/* [] END OF FILE */
