/*******************************************************************************
* File Name: BallastUp.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BallastUp_H) /* Pins BallastUp_H */
#define CY_PINS_BallastUp_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BallastUp_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BallastUp__PORT == 15 && ((BallastUp__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BallastUp_Write(uint8 value);
void    BallastUp_SetDriveMode(uint8 mode);
uint8   BallastUp_ReadDataReg(void);
uint8   BallastUp_Read(void);
void    BallastUp_SetInterruptMode(uint16 position, uint16 mode);
uint8   BallastUp_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BallastUp_SetDriveMode() function.
     *  @{
     */
        #define BallastUp_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BallastUp_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BallastUp_DM_RES_UP          PIN_DM_RES_UP
        #define BallastUp_DM_RES_DWN         PIN_DM_RES_DWN
        #define BallastUp_DM_OD_LO           PIN_DM_OD_LO
        #define BallastUp_DM_OD_HI           PIN_DM_OD_HI
        #define BallastUp_DM_STRONG          PIN_DM_STRONG
        #define BallastUp_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BallastUp_MASK               BallastUp__MASK
#define BallastUp_SHIFT              BallastUp__SHIFT
#define BallastUp_WIDTH              1u

/* Interrupt constants */
#if defined(BallastUp__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BallastUp_SetInterruptMode() function.
     *  @{
     */
        #define BallastUp_INTR_NONE      (uint16)(0x0000u)
        #define BallastUp_INTR_RISING    (uint16)(0x0001u)
        #define BallastUp_INTR_FALLING   (uint16)(0x0002u)
        #define BallastUp_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BallastUp_INTR_MASK      (0x01u) 
#endif /* (BallastUp__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BallastUp_PS                     (* (reg8 *) BallastUp__PS)
/* Data Register */
#define BallastUp_DR                     (* (reg8 *) BallastUp__DR)
/* Port Number */
#define BallastUp_PRT_NUM                (* (reg8 *) BallastUp__PRT) 
/* Connect to Analog Globals */                                                  
#define BallastUp_AG                     (* (reg8 *) BallastUp__AG)                       
/* Analog MUX bux enable */
#define BallastUp_AMUX                   (* (reg8 *) BallastUp__AMUX) 
/* Bidirectional Enable */                                                        
#define BallastUp_BIE                    (* (reg8 *) BallastUp__BIE)
/* Bit-mask for Aliased Register Access */
#define BallastUp_BIT_MASK               (* (reg8 *) BallastUp__BIT_MASK)
/* Bypass Enable */
#define BallastUp_BYP                    (* (reg8 *) BallastUp__BYP)
/* Port wide control signals */                                                   
#define BallastUp_CTL                    (* (reg8 *) BallastUp__CTL)
/* Drive Modes */
#define BallastUp_DM0                    (* (reg8 *) BallastUp__DM0) 
#define BallastUp_DM1                    (* (reg8 *) BallastUp__DM1)
#define BallastUp_DM2                    (* (reg8 *) BallastUp__DM2) 
/* Input Buffer Disable Override */
#define BallastUp_INP_DIS                (* (reg8 *) BallastUp__INP_DIS)
/* LCD Common or Segment Drive */
#define BallastUp_LCD_COM_SEG            (* (reg8 *) BallastUp__LCD_COM_SEG)
/* Enable Segment LCD */
#define BallastUp_LCD_EN                 (* (reg8 *) BallastUp__LCD_EN)
/* Slew Rate Control */
#define BallastUp_SLW                    (* (reg8 *) BallastUp__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BallastUp_PRTDSI__CAPS_SEL       (* (reg8 *) BallastUp__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BallastUp_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BallastUp__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BallastUp_PRTDSI__OE_SEL0        (* (reg8 *) BallastUp__PRTDSI__OE_SEL0) 
#define BallastUp_PRTDSI__OE_SEL1        (* (reg8 *) BallastUp__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BallastUp_PRTDSI__OUT_SEL0       (* (reg8 *) BallastUp__PRTDSI__OUT_SEL0) 
#define BallastUp_PRTDSI__OUT_SEL1       (* (reg8 *) BallastUp__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BallastUp_PRTDSI__SYNC_OUT       (* (reg8 *) BallastUp__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BallastUp__SIO_CFG)
    #define BallastUp_SIO_HYST_EN        (* (reg8 *) BallastUp__SIO_HYST_EN)
    #define BallastUp_SIO_REG_HIFREQ     (* (reg8 *) BallastUp__SIO_REG_HIFREQ)
    #define BallastUp_SIO_CFG            (* (reg8 *) BallastUp__SIO_CFG)
    #define BallastUp_SIO_DIFF           (* (reg8 *) BallastUp__SIO_DIFF)
#endif /* (BallastUp__SIO_CFG) */

/* Interrupt Registers */
#if defined(BallastUp__INTSTAT)
    #define BallastUp_INTSTAT            (* (reg8 *) BallastUp__INTSTAT)
    #define BallastUp_SNAP               (* (reg8 *) BallastUp__SNAP)
    
	#define BallastUp_0_INTTYPE_REG 		(* (reg8 *) BallastUp__0__INTTYPE)
#endif /* (BallastUp__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BallastUp_H */


/* [] END OF FILE */
