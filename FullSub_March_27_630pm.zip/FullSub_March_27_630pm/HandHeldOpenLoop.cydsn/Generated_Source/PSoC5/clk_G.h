/*******************************************************************************
* File Name: clk_G.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_clk_G_H)
#define CY_CLOCK_clk_G_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void clk_G_Start(void) ;
void clk_G_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void clk_G_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void clk_G_StandbyPower(uint8 state) ;
void clk_G_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 clk_G_GetDividerRegister(void) ;
void clk_G_SetModeRegister(uint8 modeBitMask) ;
void clk_G_ClearModeRegister(uint8 modeBitMask) ;
uint8 clk_G_GetModeRegister(void) ;
void clk_G_SetSourceRegister(uint8 clkSource) ;
uint8 clk_G_GetSourceRegister(void) ;
#if defined(clk_G__CFG3)
void clk_G_SetPhaseRegister(uint8 clkPhase) ;
uint8 clk_G_GetPhaseRegister(void) ;
#endif /* defined(clk_G__CFG3) */

#define clk_G_Enable()                       clk_G_Start()
#define clk_G_Disable()                      clk_G_Stop()
#define clk_G_SetDivider(clkDivider)         clk_G_SetDividerRegister(clkDivider, 1u)
#define clk_G_SetDividerValue(clkDivider)    clk_G_SetDividerRegister((clkDivider) - 1u, 1u)
#define clk_G_SetMode(clkMode)               clk_G_SetModeRegister(clkMode)
#define clk_G_SetSource(clkSource)           clk_G_SetSourceRegister(clkSource)
#if defined(clk_G__CFG3)
#define clk_G_SetPhase(clkPhase)             clk_G_SetPhaseRegister(clkPhase)
#define clk_G_SetPhaseValue(clkPhase)        clk_G_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(clk_G__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define clk_G_CLKEN              (* (reg8 *) clk_G__PM_ACT_CFG)
#define clk_G_CLKEN_PTR          ((reg8 *) clk_G__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define clk_G_CLKSTBY            (* (reg8 *) clk_G__PM_STBY_CFG)
#define clk_G_CLKSTBY_PTR        ((reg8 *) clk_G__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define clk_G_DIV_LSB            (* (reg8 *) clk_G__CFG0)
#define clk_G_DIV_LSB_PTR        ((reg8 *) clk_G__CFG0)
#define clk_G_DIV_PTR            ((reg16 *) clk_G__CFG0)

/* Clock MSB divider configuration register. */
#define clk_G_DIV_MSB            (* (reg8 *) clk_G__CFG1)
#define clk_G_DIV_MSB_PTR        ((reg8 *) clk_G__CFG1)

/* Mode and source configuration register */
#define clk_G_MOD_SRC            (* (reg8 *) clk_G__CFG2)
#define clk_G_MOD_SRC_PTR        ((reg8 *) clk_G__CFG2)

#if defined(clk_G__CFG3)
/* Analog clock phase configuration register */
#define clk_G_PHASE              (* (reg8 *) clk_G__CFG3)
#define clk_G_PHASE_PTR          ((reg8 *) clk_G__CFG3)
#endif /* defined(clk_G__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define clk_G_CLKEN_MASK         clk_G__PM_ACT_MSK
#define clk_G_CLKSTBY_MASK       clk_G__PM_STBY_MSK

/* CFG2 field masks */
#define clk_G_SRC_SEL_MSK        clk_G__CFG2_SRC_SEL_MASK
#define clk_G_MODE_MASK          (~(clk_G_SRC_SEL_MSK))

#if defined(clk_G__CFG3)
/* CFG3 phase mask */
#define clk_G_PHASE_MASK         clk_G__CFG3_PHASE_DLY_MASK
#endif /* defined(clk_G__CFG3) */

#endif /* CY_CLOCK_clk_G_H */


/* [] END OF FILE */
