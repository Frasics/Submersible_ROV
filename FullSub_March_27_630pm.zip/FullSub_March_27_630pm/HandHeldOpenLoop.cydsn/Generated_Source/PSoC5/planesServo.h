/*******************************************************************************
* File Name: planesServo.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_planesServo_H) /* Pins planesServo_H */
#define CY_PINS_planesServo_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "planesServo_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 planesServo__PORT == 15 && ((planesServo__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    planesServo_Write(uint8 value);
void    planesServo_SetDriveMode(uint8 mode);
uint8   planesServo_ReadDataReg(void);
uint8   planesServo_Read(void);
void    planesServo_SetInterruptMode(uint16 position, uint16 mode);
uint8   planesServo_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the planesServo_SetDriveMode() function.
     *  @{
     */
        #define planesServo_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define planesServo_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define planesServo_DM_RES_UP          PIN_DM_RES_UP
        #define planesServo_DM_RES_DWN         PIN_DM_RES_DWN
        #define planesServo_DM_OD_LO           PIN_DM_OD_LO
        #define planesServo_DM_OD_HI           PIN_DM_OD_HI
        #define planesServo_DM_STRONG          PIN_DM_STRONG
        #define planesServo_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define planesServo_MASK               planesServo__MASK
#define planesServo_SHIFT              planesServo__SHIFT
#define planesServo_WIDTH              1u

/* Interrupt constants */
#if defined(planesServo__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in planesServo_SetInterruptMode() function.
     *  @{
     */
        #define planesServo_INTR_NONE      (uint16)(0x0000u)
        #define planesServo_INTR_RISING    (uint16)(0x0001u)
        #define planesServo_INTR_FALLING   (uint16)(0x0002u)
        #define planesServo_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define planesServo_INTR_MASK      (0x01u) 
#endif /* (planesServo__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define planesServo_PS                     (* (reg8 *) planesServo__PS)
/* Data Register */
#define planesServo_DR                     (* (reg8 *) planesServo__DR)
/* Port Number */
#define planesServo_PRT_NUM                (* (reg8 *) planesServo__PRT) 
/* Connect to Analog Globals */                                                  
#define planesServo_AG                     (* (reg8 *) planesServo__AG)                       
/* Analog MUX bux enable */
#define planesServo_AMUX                   (* (reg8 *) planesServo__AMUX) 
/* Bidirectional Enable */                                                        
#define planesServo_BIE                    (* (reg8 *) planesServo__BIE)
/* Bit-mask for Aliased Register Access */
#define planesServo_BIT_MASK               (* (reg8 *) planesServo__BIT_MASK)
/* Bypass Enable */
#define planesServo_BYP                    (* (reg8 *) planesServo__BYP)
/* Port wide control signals */                                                   
#define planesServo_CTL                    (* (reg8 *) planesServo__CTL)
/* Drive Modes */
#define planesServo_DM0                    (* (reg8 *) planesServo__DM0) 
#define planesServo_DM1                    (* (reg8 *) planesServo__DM1)
#define planesServo_DM2                    (* (reg8 *) planesServo__DM2) 
/* Input Buffer Disable Override */
#define planesServo_INP_DIS                (* (reg8 *) planesServo__INP_DIS)
/* LCD Common or Segment Drive */
#define planesServo_LCD_COM_SEG            (* (reg8 *) planesServo__LCD_COM_SEG)
/* Enable Segment LCD */
#define planesServo_LCD_EN                 (* (reg8 *) planesServo__LCD_EN)
/* Slew Rate Control */
#define planesServo_SLW                    (* (reg8 *) planesServo__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define planesServo_PRTDSI__CAPS_SEL       (* (reg8 *) planesServo__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define planesServo_PRTDSI__DBL_SYNC_IN    (* (reg8 *) planesServo__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define planesServo_PRTDSI__OE_SEL0        (* (reg8 *) planesServo__PRTDSI__OE_SEL0) 
#define planesServo_PRTDSI__OE_SEL1        (* (reg8 *) planesServo__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define planesServo_PRTDSI__OUT_SEL0       (* (reg8 *) planesServo__PRTDSI__OUT_SEL0) 
#define planesServo_PRTDSI__OUT_SEL1       (* (reg8 *) planesServo__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define planesServo_PRTDSI__SYNC_OUT       (* (reg8 *) planesServo__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(planesServo__SIO_CFG)
    #define planesServo_SIO_HYST_EN        (* (reg8 *) planesServo__SIO_HYST_EN)
    #define planesServo_SIO_REG_HIFREQ     (* (reg8 *) planesServo__SIO_REG_HIFREQ)
    #define planesServo_SIO_CFG            (* (reg8 *) planesServo__SIO_CFG)
    #define planesServo_SIO_DIFF           (* (reg8 *) planesServo__SIO_DIFF)
#endif /* (planesServo__SIO_CFG) */

/* Interrupt Registers */
#if defined(planesServo__INTSTAT)
    #define planesServo_INTSTAT            (* (reg8 *) planesServo__INTSTAT)
    #define planesServo_SNAP               (* (reg8 *) planesServo__SNAP)
    
	#define planesServo_0_INTTYPE_REG 		(* (reg8 *) planesServo__0__INTTYPE)
#endif /* (planesServo__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_planesServo_H */


/* [] END OF FILE */
