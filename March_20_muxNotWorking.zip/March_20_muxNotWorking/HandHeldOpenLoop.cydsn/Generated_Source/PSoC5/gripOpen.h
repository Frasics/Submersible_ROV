/*******************************************************************************
* File Name: gripOpen.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_gripOpen_H) /* Pins gripOpen_H */
#define CY_PINS_gripOpen_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "gripOpen_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 gripOpen__PORT == 15 && ((gripOpen__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    gripOpen_Write(uint8 value);
void    gripOpen_SetDriveMode(uint8 mode);
uint8   gripOpen_ReadDataReg(void);
uint8   gripOpen_Read(void);
void    gripOpen_SetInterruptMode(uint16 position, uint16 mode);
uint8   gripOpen_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the gripOpen_SetDriveMode() function.
     *  @{
     */
        #define gripOpen_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define gripOpen_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define gripOpen_DM_RES_UP          PIN_DM_RES_UP
        #define gripOpen_DM_RES_DWN         PIN_DM_RES_DWN
        #define gripOpen_DM_OD_LO           PIN_DM_OD_LO
        #define gripOpen_DM_OD_HI           PIN_DM_OD_HI
        #define gripOpen_DM_STRONG          PIN_DM_STRONG
        #define gripOpen_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define gripOpen_MASK               gripOpen__MASK
#define gripOpen_SHIFT              gripOpen__SHIFT
#define gripOpen_WIDTH              1u

/* Interrupt constants */
#if defined(gripOpen__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in gripOpen_SetInterruptMode() function.
     *  @{
     */
        #define gripOpen_INTR_NONE      (uint16)(0x0000u)
        #define gripOpen_INTR_RISING    (uint16)(0x0001u)
        #define gripOpen_INTR_FALLING   (uint16)(0x0002u)
        #define gripOpen_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define gripOpen_INTR_MASK      (0x01u) 
#endif /* (gripOpen__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define gripOpen_PS                     (* (reg8 *) gripOpen__PS)
/* Data Register */
#define gripOpen_DR                     (* (reg8 *) gripOpen__DR)
/* Port Number */
#define gripOpen_PRT_NUM                (* (reg8 *) gripOpen__PRT) 
/* Connect to Analog Globals */                                                  
#define gripOpen_AG                     (* (reg8 *) gripOpen__AG)                       
/* Analog MUX bux enable */
#define gripOpen_AMUX                   (* (reg8 *) gripOpen__AMUX) 
/* Bidirectional Enable */                                                        
#define gripOpen_BIE                    (* (reg8 *) gripOpen__BIE)
/* Bit-mask for Aliased Register Access */
#define gripOpen_BIT_MASK               (* (reg8 *) gripOpen__BIT_MASK)
/* Bypass Enable */
#define gripOpen_BYP                    (* (reg8 *) gripOpen__BYP)
/* Port wide control signals */                                                   
#define gripOpen_CTL                    (* (reg8 *) gripOpen__CTL)
/* Drive Modes */
#define gripOpen_DM0                    (* (reg8 *) gripOpen__DM0) 
#define gripOpen_DM1                    (* (reg8 *) gripOpen__DM1)
#define gripOpen_DM2                    (* (reg8 *) gripOpen__DM2) 
/* Input Buffer Disable Override */
#define gripOpen_INP_DIS                (* (reg8 *) gripOpen__INP_DIS)
/* LCD Common or Segment Drive */
#define gripOpen_LCD_COM_SEG            (* (reg8 *) gripOpen__LCD_COM_SEG)
/* Enable Segment LCD */
#define gripOpen_LCD_EN                 (* (reg8 *) gripOpen__LCD_EN)
/* Slew Rate Control */
#define gripOpen_SLW                    (* (reg8 *) gripOpen__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define gripOpen_PRTDSI__CAPS_SEL       (* (reg8 *) gripOpen__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define gripOpen_PRTDSI__DBL_SYNC_IN    (* (reg8 *) gripOpen__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define gripOpen_PRTDSI__OE_SEL0        (* (reg8 *) gripOpen__PRTDSI__OE_SEL0) 
#define gripOpen_PRTDSI__OE_SEL1        (* (reg8 *) gripOpen__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define gripOpen_PRTDSI__OUT_SEL0       (* (reg8 *) gripOpen__PRTDSI__OUT_SEL0) 
#define gripOpen_PRTDSI__OUT_SEL1       (* (reg8 *) gripOpen__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define gripOpen_PRTDSI__SYNC_OUT       (* (reg8 *) gripOpen__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(gripOpen__SIO_CFG)
    #define gripOpen_SIO_HYST_EN        (* (reg8 *) gripOpen__SIO_HYST_EN)
    #define gripOpen_SIO_REG_HIFREQ     (* (reg8 *) gripOpen__SIO_REG_HIFREQ)
    #define gripOpen_SIO_CFG            (* (reg8 *) gripOpen__SIO_CFG)
    #define gripOpen_SIO_DIFF           (* (reg8 *) gripOpen__SIO_DIFF)
#endif /* (gripOpen__SIO_CFG) */

/* Interrupt Registers */
#if defined(gripOpen__INTSTAT)
    #define gripOpen_INTSTAT            (* (reg8 *) gripOpen__INTSTAT)
    #define gripOpen_SNAP               (* (reg8 *) gripOpen__SNAP)
    
	#define gripOpen_0_INTTYPE_REG 		(* (reg8 *) gripOpen__0__INTTYPE)
#endif /* (gripOpen__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_gripOpen_H */


/* [] END OF FILE */
