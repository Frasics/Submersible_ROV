/*******************************************************************************
* File Name: Cap_TunerHelper.c
* Version 3.50
*
* Description:
*  This file provides the source code of Tuner helper APIs for the CapSense CSD 
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Cap_TunerHelper.h"

#if (Cap_TUNER_API_GENERATE)
    volatile Cap_MAILBOXES Cap_mailboxesComm;
#endif  /* (Cap_TUNER_API_GENERATE) */


/*******************************************************************************
* Function Name: Cap_TunerStart
********************************************************************************
*
* Summary:
*  Initializes CapSense CSD component and EzI2C communication componenet to use
*  mailbox data structure for communication with Tuner GUI.
*  Start the scanning, after initialization complete.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Reentrant:
*  No
*
* Note:
*  All widgets are enabled by default except proximity widgets. Proximity widgets 
*  must be manually enabled as their long scan time is incompatible 
*  with the fast response required of other widget types. 
*
*******************************************************************************/
void Cap_TunerStart(void) 
{
    #if (Cap_TUNER_API_GENERATE)
        
        /* Init mbx and quick check */
        Cap_InitMailbox(&Cap_mailboxesComm.csdMailbox);
        Cap_mailboxesComm.numMailBoxes = Cap_DEFAULT_MAILBOXES_NUMBER;
        
        /* Start CapSense and baselines */
        Cap_Start();
        
        /* Initialize baselines */ 
        Cap_InitializeAllBaselines();
        Cap_InitializeAllBaselines();
        
        /* Start EzI2C, clears buf pointers */
        EZI2C_Start();
        
        /* Setup EzI2C buffers */
        EZI2C_SetBuffer1(sizeof(Cap_mailboxesComm), sizeof(Cap_mailboxesComm),
                                        (void *) &Cap_mailboxesComm);
        
        /* Starts scan all enabled sensors */
        Cap_ScanEnabledWidgets();
    
    #endif  /* (Cap_TUNER_API_GENERATE) */
}


/*******************************************************************************
* Function Name: Cap_TunerComm
********************************************************************************
*
* Summary:
*  This function is blocking. It waits till scaning loop is completed and apply
*  new parameters from Tuner GUI if available (manual tuning mode only). Updates
*  enabled baselines and state of widgets. Waits while Tuner GUI reports that 
*  content of mailbox could be modified. Then loads the report data into outbox 
*  and sets the busy flag. Starts new scanning loop.
*  
* Parameters:
*  None
*
* Return:
*  None
*
* Reentrant:
*  No
*
*******************************************************************************/
void Cap_TunerComm(void) 
{
    #if (Cap_TUNER_API_GENERATE)
        if (0u == Cap_IsBusy())
        {   
            /* Apply new settings */
            #if (Cap_TUNING_METHOD == Cap_MANUAL_TUNING)
                Cap_ReadMessage(&Cap_mailboxesComm.csdMailbox);
            #endif  /* (Cap_TUNING_METHOD == Cap_MANUAL_TUNING) */

            /* Update all baselines and process all widgets */
            Cap_UpdateEnabledBaselines();
            Cap_ProcessAllWidgets(&Cap_mailboxesComm.csdMailbox.outbox);
            Cap_PostMessage(&Cap_mailboxesComm.csdMailbox);

            /* Enable EZI2C interrupts, after scan complete */
            EZI2C_EnableInt();

            while((Cap_mailboxesComm.csdMailbox.type != Cap_TYPE_ID) || \
                  ((EZI2C_GetActivity() & EZI2C_STATUS_BUSY) != 0u)){}
            
            /* Disable EZI2C interrupts, while scanning */
            EZI2C_DisableInt();
            
            /* Start scan all sensors */
            Cap_ScanEnabledWidgets();
        }
    #endif /* (Cap_TUNER_API_GENERATE) */
}


#if (Cap_TUNER_API_GENERATE)
    /*******************************************************************************
    * Function Name: Cap_ProcessAllWidgets
    ********************************************************************************
    *
    * Summary:
    *  Call required functions to update all widgets state:
    *   - Cap_GetCentroidPos() - calls only if linear sliders 
    *     available.
    *   - Cap_GetRadialCentroidPos() - calls only if radial slider 
    *     available.
    *   - Cap_GetTouchCentroidPos() - calls only if touch pad slider 
    *     available.
    *   - Cap_CheckIsAnyWidgetActive();
    *  The results of opeartions are copied to OUTBOX.
    *   
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  Cap_OUTBOX outbox - structure which is used as ouput 
    *  buffer for report data to Tuner GUI.
    *  Update fields:
    *    - position[];
    *    - OnMask[];
    *
    * Reentrant:
    *  No
    *
    *******************************************************************************/
    void Cap_ProcessAllWidgets(volatile Cap_OUTBOX *outbox)
	                                        
    {
        uint8 i = 0u;
		#if (Cap_TOTAL_MATRIX_BUTTONS_COUNT)
        	volatile uint8 *mbPositionAddr;
		#endif /* (Cap_TOTAL_MATRIX_BUTTONS_COUNT) */

        #if (Cap_TOTAL_TOUCH_PADS_COUNT)
            uint16 pos[2];
        #endif  /* (Cap_TOTAL_TOUCH_PADS_COUNT) */
        
        #if ( (Cap_TOTAL_RADIAL_SLIDERS_COUNT) || (Cap_TOTAL_TOUCH_PADS_COUNT) || \
              (Cap_TOTAL_MATRIX_BUTTONS_COUNT) )
            uint8 widgetCnt;
        #endif  /* ((Cap_TOTAL_RADIAL_SLIDERS_COUNT) || (Cap_TOTAL_TOUCH_PADS_COUNT)) || 
                *   (Cap_TOTAL_MATRIX_BUTTONS_COUNT)
                */
        
        /* Calculate widget with centroids */
        #if (Cap_TOTAL_LINEAR_SLIDERS_COUNT)
            for(; i < Cap_TOTAL_LINEAR_SLIDERS_COUNT; i++)
            {
                outbox->position[i] = Cap_SWAP_ENDIAN16(Cap_GetCentroidPos(i));
            }
        #endif /* (Cap_TOTAL_LINEAR_SLIDERS_COUNT) */
        
        #if (Cap_TOTAL_RADIAL_SLIDERS_COUNT)
            widgetCnt = i;
            for(; i < (widgetCnt + Cap_TOTAL_RADIAL_SLIDERS_COUNT); i++)
            {
                outbox->position[i] = Cap_SWAP_ENDIAN16(Cap_GetRadialCentroidPos(i));
            }
        #endif /* (Cap_TOTAL_RADIAL_SLIDERS_COUNT) */
        
        #if (Cap_TOTAL_TOUCH_PADS_COUNT)
            widgetCnt = i;
            for(; i < (widgetCnt + (Cap_TOTAL_TOUCH_PADS_COUNT * 2u)); i = (i+2u))
            {
                if(Cap_GetTouchCentroidPos(i, pos) == 0u)
                {
                    outbox->position[i] = 0xFFFFu;
                    outbox->position[i+1u] = 0xFFFFu;
                }
                else
                {
                    outbox->position[i] = Cap_SWAP_ENDIAN16( (uint16) pos[0u]);
                    outbox->position[i+1u] = Cap_SWAP_ENDIAN16( (uint16) pos[1u]);
                }
            }
        #endif /* (Cap_TOTAL_TOUCH_PADS_COUNT) */

        #if (Cap_TOTAL_MATRIX_BUTTONS_COUNT)
            i += Cap_TOTAL_BUTTONS_COUNT;
            widgetCnt = 0u;
            for(; widgetCnt < (Cap_TOTAL_MATRIX_BUTTONS_COUNT * 2u); widgetCnt += 2u)
            {
                mbPositionAddr = &outbox->mbPosition[widgetCnt];
                if(Cap_GetMatrixButtonPos(i, ((uint8*) mbPositionAddr)) == 0u)
                {
                    outbox->mbPosition[widgetCnt] = 0xFFu;
                    outbox->mbPosition[widgetCnt+1u] = 0xFFu;
                }
                i += 2u;
            }
        #endif /* (Cap_TOTAL_MATRIX_BUTTONS_COUNT) */

        /* Update On/Off State */
        (void)Cap_CheckIsAnyWidgetActive();

        /* Copy OnMask */
        for(i = 0u; i < Cap_TOTAL_SENSOR_MASK_COUNT; i++)
        {
            outbox->onMask[i]  = Cap_sensorOnMask[i];
        }
    }
#endif /* (Cap_TUNER_API_GENERATE) */


/* [] END OF FILE */
