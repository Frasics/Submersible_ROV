/*******************************************************************************
* File Name: PWM_D_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PWM_D.h"

static PWM_D_backupStruct PWM_D_backup;


/*******************************************************************************
* Function Name: PWM_D_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_D_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void PWM_D_SaveConfig(void) 
{

    #if(!PWM_D_UsingFixedFunction)
        #if(!PWM_D_PWMModeIsCenterAligned)
            PWM_D_backup.PWMPeriod = PWM_D_ReadPeriod();
        #endif /* (!PWM_D_PWMModeIsCenterAligned) */
        PWM_D_backup.PWMUdb = PWM_D_ReadCounter();
        #if (PWM_D_UseStatus)
            PWM_D_backup.InterruptMaskValue = PWM_D_STATUS_MASK;
        #endif /* (PWM_D_UseStatus) */

        #if(PWM_D_DeadBandMode == PWM_D__B_PWM__DBM_256_CLOCKS || \
            PWM_D_DeadBandMode == PWM_D__B_PWM__DBM_2_4_CLOCKS)
            PWM_D_backup.PWMdeadBandValue = PWM_D_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(PWM_D_KillModeMinTime)
             PWM_D_backup.PWMKillCounterPeriod = PWM_D_ReadKillTime();
        #endif /* (PWM_D_KillModeMinTime) */

        #if(PWM_D_UseControl)
            PWM_D_backup.PWMControlRegister = PWM_D_ReadControlRegister();
        #endif /* (PWM_D_UseControl) */
    #endif  /* (!PWM_D_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_D_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_D_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_D_RestoreConfig(void) 
{
        #if(!PWM_D_UsingFixedFunction)
            #if(!PWM_D_PWMModeIsCenterAligned)
                PWM_D_WritePeriod(PWM_D_backup.PWMPeriod);
            #endif /* (!PWM_D_PWMModeIsCenterAligned) */

            PWM_D_WriteCounter(PWM_D_backup.PWMUdb);

            #if (PWM_D_UseStatus)
                PWM_D_STATUS_MASK = PWM_D_backup.InterruptMaskValue;
            #endif /* (PWM_D_UseStatus) */

            #if(PWM_D_DeadBandMode == PWM_D__B_PWM__DBM_256_CLOCKS || \
                PWM_D_DeadBandMode == PWM_D__B_PWM__DBM_2_4_CLOCKS)
                PWM_D_WriteDeadTime(PWM_D_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(PWM_D_KillModeMinTime)
                PWM_D_WriteKillTime(PWM_D_backup.PWMKillCounterPeriod);
            #endif /* (PWM_D_KillModeMinTime) */

            #if(PWM_D_UseControl)
                PWM_D_WriteControlRegister(PWM_D_backup.PWMControlRegister);
            #endif /* (PWM_D_UseControl) */
        #endif  /* (!PWM_D_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_D_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_D_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_D_Sleep(void) 
{
    #if(PWM_D_UseControl)
        if(PWM_D_CTRL_ENABLE == (PWM_D_CONTROL & PWM_D_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_D_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_D_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_D_UseControl) */

    /* Stop component */
    PWM_D_Stop();

    /* Save registers configuration */
    PWM_D_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_D_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_D_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_D_Wakeup(void) 
{
     /* Restore registers values */
    PWM_D_RestoreConfig();

    if(PWM_D_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_D_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
