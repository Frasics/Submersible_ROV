/*******************************************************************************
* File Name: clkT.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_clkT_H)
#define CY_CLOCK_clkT_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void clkT_Start(void) ;
void clkT_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void clkT_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void clkT_StandbyPower(uint8 state) ;
void clkT_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 clkT_GetDividerRegister(void) ;
void clkT_SetModeRegister(uint8 modeBitMask) ;
void clkT_ClearModeRegister(uint8 modeBitMask) ;
uint8 clkT_GetModeRegister(void) ;
void clkT_SetSourceRegister(uint8 clkSource) ;
uint8 clkT_GetSourceRegister(void) ;
#if defined(clkT__CFG3)
void clkT_SetPhaseRegister(uint8 clkPhase) ;
uint8 clkT_GetPhaseRegister(void) ;
#endif /* defined(clkT__CFG3) */

#define clkT_Enable()                       clkT_Start()
#define clkT_Disable()                      clkT_Stop()
#define clkT_SetDivider(clkDivider)         clkT_SetDividerRegister(clkDivider, 1u)
#define clkT_SetDividerValue(clkDivider)    clkT_SetDividerRegister((clkDivider) - 1u, 1u)
#define clkT_SetMode(clkMode)               clkT_SetModeRegister(clkMode)
#define clkT_SetSource(clkSource)           clkT_SetSourceRegister(clkSource)
#if defined(clkT__CFG3)
#define clkT_SetPhase(clkPhase)             clkT_SetPhaseRegister(clkPhase)
#define clkT_SetPhaseValue(clkPhase)        clkT_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(clkT__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define clkT_CLKEN              (* (reg8 *) clkT__PM_ACT_CFG)
#define clkT_CLKEN_PTR          ((reg8 *) clkT__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define clkT_CLKSTBY            (* (reg8 *) clkT__PM_STBY_CFG)
#define clkT_CLKSTBY_PTR        ((reg8 *) clkT__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define clkT_DIV_LSB            (* (reg8 *) clkT__CFG0)
#define clkT_DIV_LSB_PTR        ((reg8 *) clkT__CFG0)
#define clkT_DIV_PTR            ((reg16 *) clkT__CFG0)

/* Clock MSB divider configuration register. */
#define clkT_DIV_MSB            (* (reg8 *) clkT__CFG1)
#define clkT_DIV_MSB_PTR        ((reg8 *) clkT__CFG1)

/* Mode and source configuration register */
#define clkT_MOD_SRC            (* (reg8 *) clkT__CFG2)
#define clkT_MOD_SRC_PTR        ((reg8 *) clkT__CFG2)

#if defined(clkT__CFG3)
/* Analog clock phase configuration register */
#define clkT_PHASE              (* (reg8 *) clkT__CFG3)
#define clkT_PHASE_PTR          ((reg8 *) clkT__CFG3)
#endif /* defined(clkT__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define clkT_CLKEN_MASK         clkT__PM_ACT_MSK
#define clkT_CLKSTBY_MASK       clkT__PM_STBY_MSK

/* CFG2 field masks */
#define clkT_SRC_SEL_MSK        clkT__CFG2_SRC_SEL_MASK
#define clkT_MODE_MASK          (~(clkT_SRC_SEL_MSK))

#if defined(clkT__CFG3)
/* CFG3 phase mask */
#define clkT_PHASE_MASK         clkT__CFG3_PHASE_DLY_MASK
#endif /* defined(clkT__CFG3) */

#endif /* CY_CLOCK_clkT_H */


/* [] END OF FILE */
