/*******************************************************************************
* File Name: Dive.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Dive_H) /* Pins Dive_H */
#define CY_PINS_Dive_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Dive_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Dive__PORT == 15 && ((Dive__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Dive_Write(uint8 value);
void    Dive_SetDriveMode(uint8 mode);
uint8   Dive_ReadDataReg(void);
uint8   Dive_Read(void);
void    Dive_SetInterruptMode(uint16 position, uint16 mode);
uint8   Dive_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Dive_SetDriveMode() function.
     *  @{
     */
        #define Dive_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Dive_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Dive_DM_RES_UP          PIN_DM_RES_UP
        #define Dive_DM_RES_DWN         PIN_DM_RES_DWN
        #define Dive_DM_OD_LO           PIN_DM_OD_LO
        #define Dive_DM_OD_HI           PIN_DM_OD_HI
        #define Dive_DM_STRONG          PIN_DM_STRONG
        #define Dive_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Dive_MASK               Dive__MASK
#define Dive_SHIFT              Dive__SHIFT
#define Dive_WIDTH              1u

/* Interrupt constants */
#if defined(Dive__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Dive_SetInterruptMode() function.
     *  @{
     */
        #define Dive_INTR_NONE      (uint16)(0x0000u)
        #define Dive_INTR_RISING    (uint16)(0x0001u)
        #define Dive_INTR_FALLING   (uint16)(0x0002u)
        #define Dive_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Dive_INTR_MASK      (0x01u) 
#endif /* (Dive__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Dive_PS                     (* (reg8 *) Dive__PS)
/* Data Register */
#define Dive_DR                     (* (reg8 *) Dive__DR)
/* Port Number */
#define Dive_PRT_NUM                (* (reg8 *) Dive__PRT) 
/* Connect to Analog Globals */                                                  
#define Dive_AG                     (* (reg8 *) Dive__AG)                       
/* Analog MUX bux enable */
#define Dive_AMUX                   (* (reg8 *) Dive__AMUX) 
/* Bidirectional Enable */                                                        
#define Dive_BIE                    (* (reg8 *) Dive__BIE)
/* Bit-mask for Aliased Register Access */
#define Dive_BIT_MASK               (* (reg8 *) Dive__BIT_MASK)
/* Bypass Enable */
#define Dive_BYP                    (* (reg8 *) Dive__BYP)
/* Port wide control signals */                                                   
#define Dive_CTL                    (* (reg8 *) Dive__CTL)
/* Drive Modes */
#define Dive_DM0                    (* (reg8 *) Dive__DM0) 
#define Dive_DM1                    (* (reg8 *) Dive__DM1)
#define Dive_DM2                    (* (reg8 *) Dive__DM2) 
/* Input Buffer Disable Override */
#define Dive_INP_DIS                (* (reg8 *) Dive__INP_DIS)
/* LCD Common or Segment Drive */
#define Dive_LCD_COM_SEG            (* (reg8 *) Dive__LCD_COM_SEG)
/* Enable Segment LCD */
#define Dive_LCD_EN                 (* (reg8 *) Dive__LCD_EN)
/* Slew Rate Control */
#define Dive_SLW                    (* (reg8 *) Dive__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Dive_PRTDSI__CAPS_SEL       (* (reg8 *) Dive__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Dive_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Dive__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Dive_PRTDSI__OE_SEL0        (* (reg8 *) Dive__PRTDSI__OE_SEL0) 
#define Dive_PRTDSI__OE_SEL1        (* (reg8 *) Dive__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Dive_PRTDSI__OUT_SEL0       (* (reg8 *) Dive__PRTDSI__OUT_SEL0) 
#define Dive_PRTDSI__OUT_SEL1       (* (reg8 *) Dive__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Dive_PRTDSI__SYNC_OUT       (* (reg8 *) Dive__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Dive__SIO_CFG)
    #define Dive_SIO_HYST_EN        (* (reg8 *) Dive__SIO_HYST_EN)
    #define Dive_SIO_REG_HIFREQ     (* (reg8 *) Dive__SIO_REG_HIFREQ)
    #define Dive_SIO_CFG            (* (reg8 *) Dive__SIO_CFG)
    #define Dive_SIO_DIFF           (* (reg8 *) Dive__SIO_DIFF)
#endif /* (Dive__SIO_CFG) */

/* Interrupt Registers */
#if defined(Dive__INTSTAT)
    #define Dive_INTSTAT            (* (reg8 *) Dive__INTSTAT)
    #define Dive_SNAP               (* (reg8 *) Dive__SNAP)
    
	#define Dive_0_INTTYPE_REG 		(* (reg8 *) Dive__0__INTTYPE)
#endif /* (Dive__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Dive_H */


/* [] END OF FILE */
