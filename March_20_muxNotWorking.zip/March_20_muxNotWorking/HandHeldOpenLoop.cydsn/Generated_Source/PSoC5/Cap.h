/*******************************************************************************
* File Name: Cap.h
* Version 3.50
*
* Description:
*  This file provides constants and parameter values for the CapSense CSD
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semicondu)ctor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end u)ser license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_Cap_H)
#define CY_CAPSENSE_CSD_Cap_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cydevice_trm.h"
#include "CyLib.h"


#include "Cap_IntClock.h"

#include "Cap_AMuxCH0.h"
#include "Cap_CompCH0.h"
#include "Cap_IdacCH0.h"




/***************************************
*   Condition compilation parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component CapSense_CSD_v3_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


#define Cap_DESIGN_TYPE                (1u)

#define Cap_CONNECT_INACTIVE_SNS       (0u)
#define Cap_IS_COMPLEX_SCANSLOTS       (0u)

#define Cap_CLOCK_SOURCE               (0u)

#define Cap_CURRENT_SOURCE             (1u)
#define Cap_IDAC_RANGE_VALUE           (4u)

#define Cap_PRESCALER_OPTIONS          (1u)
#define Cap_MULTIPLE_PRESCALER_ENABLED (1u)

#define Cap_PRS_OPTIONS                (2u)
#define Cap_SCANSPEED_VALUE            (7u)

#define Cap_VREF_OPTIONS               (0u)

#define Cap_WATER_PROOF                (0u)

#define Cap_TUNING_METHOD              (2u)
#define Cap_TUNER_API_GENERATE         (0u)

#define Cap_IMPLEMENTATION_CH0         (1u)
#define Cap_IMPLEMENTATION_CH1         (1u)

#define Cap_GUARD_SENSOR               (0u)

/* Design types definitions */
#define Cap_ONE_CHANNEL_DESIGN         (1u)
#define Cap_TWO_CHANNELS_DESIGN        (2u)

/* Clock sources definitions */
#define Cap_INTERNAL_CLOCK             (0u)
#define Cap_EXTERNAL_CLOCK             (1u)

/* Current source definitions */
#define Cap_EXTERNAL_RB                (0u)
#define Cap_IDAC_SOURCE                (1u)
#define Cap_IDAC_SINK                  (2u)

/* Prescaler option definitions */
#define Cap_PRESCALER_NONE             (0u)
#define Cap_PRESCALER_UDB              (1u)
#define Cap_PRESCALER_FF               (2u)

/* Prs options definitions */
#define Cap_PRS_NONE                   (0u)
#define Cap_PRS_8BITS                  (1u)
#define Cap_PRS_16BITS                 (2u)
#define Cap_PRS_16BITS_4X              (3u)

/* Seed values */
#define Cap_PRS8_SEED_VALUE            (0xFFu)
#define Cap_PRS16_SEED_VALUE           (0xFFFFu)

/* Reference source types definitions */
#define Cap_VREF_REFERENCE_1_024V      (0u)
#define Cap_VREF_REFERENCE_1_2V        (1u)
#define Cap_VREF_VDAC                  (2u)

/* Connection of inactive sensors definitions */
#define Cap_CIS_GND                    (0u)
#define Cap_CIS_HIGHZ                  (1u)
#define Cap_CIS_SHIELD                 (2u)

/* Method of tunning */
#define Cap_NO_TUNING                  (0u)
#define Cap_MANUAL_TUNING              (1u)
#define Cap_AUTO_TUNING                (2u)

/* Measure Channel implementation */
#define Cap_MEASURE_IMPLEMENTATION_FF  (0u)
#define Cap_MEASURE_IMPLEMENTATION_UDB (1u)

/* Guard sensor definition */
#define Cap_GUARD_SENSOR_DISABLE       (0u)
#define Cap_GUARD_SENSOR_ENABLE        (1u)


/***************************************
*       Type defines
***************************************/

/* Structure to save registers before go to sleep */
typedef struct
{
    uint8 enableState;

    /* Set CONTROL_REG */
    uint8 ctrlReg;
} Cap_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

void Cap_Init(void) ;
void Cap_Enable(void) ;
void Cap_Start(void) ;
void Cap_Stop(void) ;
void Cap_SaveConfig(void) ;
void Cap_Sleep(void) ;
void Cap_RestoreConfig(void) ;
void Cap_Wakeup(void) ;
uint8 Cap_IsBusy(void) ;
void Cap_ScanSensor(uint8 sensor) ;
void Cap_ScanEnabledWidgets(void) ;
void Cap_SetScanSlotSettings(uint8 slot) CYREENTRANT;
uint16 Cap_ReadSensorRaw(uint8 sensor) ;
void Cap_ClearSensors(void) ;
void Cap_EnableSensor(uint8 sensor) CYREENTRANT;
void Cap_DisableSensor(uint8 sensor) CYREENTRANT;

void Cap_SetAnalogSwitchesSource(uint8 src) ;

#if (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB)
    void Cap_SetRBleed(uint8 rbeed) ;
#endif  /* (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB) */

/* Interrupt handler */
CY_ISR_PROTO(Cap_IsrCH0_ISR);
#if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
    CY_ISR_PROTO(Cap_IsrCH1_ISR);
#endif  /* (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN) */

#if (Cap_PRESCALER_OPTIONS)
    uint8 Cap_GetPrescaler(void) ;
#endif /* (Cap_PRESCALER_OPTIONS) */

/***************************************
*           API Constants
***************************************/

#define Cap_TOTAL_SENSOR_COUNT            (2u)
#define Cap_TOTAL_SCANSLOT_COUNT            (2u)
#define Cap_TOTAL_RB_NUMBER            (1u)
#define Cap_TOTAL_RB_NUMBER__CH0            (1u)

/* Define Sensors */
#define Cap_SENSOR_BUTTON0__BTN    (0u)
#define Cap_SENSOR_BUTTON1__BTN    (1u)
/* AMux Cmod, Comparator and Idac Channels definitions */
#define Cap_AMuxCH0_CMOD_CHANNEL          (2u)
#define Cap_AMuxCH0_CMP_VP_CHANNEL        (3u)
#define Cap_AMuxCH0_IDAC_CHANNEL          (4u)



/* Vdac value for Vref = Vdac */
#define Cap_VREF_VDAC_VALUE            (64u)

/* Scan Speed Type */
#define Cap_SCAN_SPEED_ULTRA_FAST      (0x01u)
#define Cap_SCAN_SPEED_FAST            (0x03u)
#define Cap_SCAN_SPEED_NORMAL          (0x07u)
#define Cap_SCAN_SPEED_SLOW            (0x0Fu)

/* PWM Resolution */
#define Cap_PWM_WINDOW_APPEND          (0xFEu)
#define Cap_PWM_RESOLUTION_8_BITS      (0x00u)
#define Cap_PWM_RESOLUTION_9_BITS      (0x01u)
#define Cap_PWM_RESOLUTION_10_BITS     (0x03u)
#define Cap_PWM_RESOLUTION_11_BITS     (0x07u)
#define Cap_PWM_RESOLUTION_12_BITS     (0x0Fu)
#define Cap_PWM_RESOLUTION_13_BITS     (0x1Fu)
#define Cap_PWM_RESOLUTION_14_BITS     (0x3Fu)
#define Cap_PWM_RESOLUTION_15_BITS     (0x7Fu)
#define Cap_PWM_RESOLUTION_16_BITS     (0xFFu)

/* Software Status Register Bit Masks */
#define Cap_SW_STS_BUSY                (0x01u)
/* Software Status Register Bit Masks */
#define Cap_SW_CTRL_SINGLE_SCAN        (0x80u)

/* Init Idac current */
#define Cap_TURN_OFF_IDAC              (0x00u)

/* Rbleed definitions */
#define Cap_RBLEED1                    (0u)
#define Cap_RBLEED2                    (1u)
#define Cap_RBLEED3                    (2u)

/* Flag of complex scan slot */
#define Cap_COMPLEX_SS_FLAG            (0x80u)
#define Cap_CHANNEL1_FLAG              (0x80u)


#define Cap_ANALOG_SWITCHES_SRC_PRESCALER (0x01u)
#define Cap_ANALOG_SWITCHES_SRC_PRS       (0x02u)


/***************************************
*             Registers
***************************************/

/* Control REG */
#define Cap_CONTROL_REG    (*(reg8 *) \
                                            Cap_ClockGen_SyncCtrl_CtrlReg__CONTROL_REG )
#define Cap_CONTROL_PTR    ( (reg8 *) \
                                            Cap_ClockGen_SyncCtrl_CtrlReg__CONTROL_REG )

/* Clock Gen - ScanSpeed REGs definitions */
#define Cap_SCANSPEED_AUX_CONTROL_REG (*(reg8 *) Cap_ClockGen_ScanSpeed__CONTROL_AUX_CTL_REG )
#define Cap_SCANSPEED_AUX_CONTROL_PTR ( (reg8 *) Cap_ClockGen_ScanSpeed__CONTROL_AUX_CTL_REG )

#define Cap_SCANSPEED_PERIOD_REG      (*(reg8 *) Cap_ClockGen_ScanSpeed__PERIOD_REG )
#define Cap_SCANSPEED_PERIOD_PTR      ( (reg8 *) Cap_ClockGen_ScanSpeed__PERIOD_REG )

#define Cap_SCANSPEED_COUNTER_REG     (*(reg8 *) Cap_ClockGen_ScanSpeed__COUNT_REG )
#define Cap_SCANSPEED_COUNTER_PTR     ( (reg8 *) Cap_ClockGen_ScanSpeed__COUNT_REG )


/* Clock Gen - Prescaler REGs definitions */
#if (Cap_PRESCALER_OPTIONS == Cap_PRESCALER_UDB)
    #define Cap_PRESCALER_PERIOD_REG       (*(reg8 *) Cap_ClockGen_UDB_PrescalerDp_u0__D0_REG)
    #define Cap_PRESCALER_PERIOD_PTR       ( (reg8 *) Cap_ClockGen_UDB_PrescalerDp_u0__D0_REG)
    
    #define Cap_PRESCALER_COMPARE_REG      (*(reg8 *) Cap_ClockGen_UDB_PrescalerDp_u0__D1_REG)
    #define Cap_PRESCALER_COMPARE_PTR      ( (reg8 *) Cap_ClockGen_UDB_PrescalerDp_u0__D1_REG)
    
#elif (Cap_PRESCALER_OPTIONS == Cap_PRESCALER_FF)
    #define Cap_PRESCALER_PERIOD_PTR       ( (reg16 *) Cap_ClockGen_FF_Prescaler__PER0 )
    #define Cap_PRESCALER_COMPARE_PTR      ( (reg16 *) Cap_ClockGen_FF_Prescaler__CNT_CMP0 )
    
    #define Cap_PRESCALER_CONTROL_REG      (*(reg8 *) Cap_ClockGen_FF_Prescaler__CFG0 )
    #define Cap_PRESCALER_CONTROL_PTR      ( (reg8 *) Cap_ClockGen_FF_Prescaler__CFG0 )
    
    #if (CY_PSOC5A)
        #define Cap_PRESCALER_CONTROL2_REG     (*(reg8 *) Cap_ClockGen_FF_Prescaler__CFG1 )
        #define Cap_PRESCALER_CONTROL2_PTR     ( (reg8 *) Cap_ClockGen_FF_Prescaler__CFG1 )
    #else
        #define Cap_PRESCALER_CONTROL2_REG     (*(reg8 *) Cap_ClockGen_FF_Prescaler__CFG2 )
        #define Cap_PRESCALER_CONTROL2_PTR     ( (reg8 *) Cap_ClockGen_FF_Prescaler__CFG2 )
    #endif  /* (CY_PSOC5A) */
    
    #define Cap_PRESCALER_ACT_PWRMGR_REG   (*(reg8 *) Cap_ClockGen_FF_Prescaler__PM_ACT_CFG )
    #define Cap_PRESCALER_ACT_PWRMGR_PTR   ( (reg8 *) Cap_ClockGen_FF_Prescaler__PM_ACT_CFG )
    #define Cap_PRESCALER_ACT_PWR_EN                 (Cap_ClockGen_FF_Prescaler__PM_ACT_MSK )
    
    #define Cap_PRESCALER_STBY_PWRMGR_REG  (*(reg8 *) Cap_ClockGen_FF_Prescaler__PM_STBY_CFG )
    #define Cap_PRESCALER_STBY_PWRMGR_PTR  ( (reg8 *) Cap_ClockGen_FF_Prescaler__PM_STBY_CFG )
    #define Cap_PRESCALER_STBY_PWR_EN                (Cap_ClockGen_FF_Prescaler__PM_STBY_MSK )

#else
    /* No prescaler */
#endif  /* (Cap_PRESCALER_OPTIONS == Cap_PRESCALER_UDB) */

/* PRS */
#if (Cap_PRS_OPTIONS == Cap_PRS_8BITS)  
    /* Polynomial */
    #define Cap_POLYNOM_REG        (*(reg8 *) Cap_ClockGen_sC8_PRSdp_u0__D0_REG )
    #define Cap_POLYNOM_PTR        ( (reg8 *) Cap_ClockGen_sC8_PRSdp_u0__D0_REG )
    /* Seed */
    #define Cap_SEED_REG           (*(reg8 *) Cap_ClockGen_sC8_PRSdp_u0__A0_REG )
    #define Cap_SEED_PTR           ( (reg8 *) Cap_ClockGen_sC8_PRSdp_u0__A0_REG )
    /* Seed COPY */
    #define Cap_SEED_COPY_REG      (*(reg8 *) Cap_ClockGen_sC8_PRSdp_u0__F0_REG )
    #define Cap_SEED_COPY_PTR      ( (reg8 *) Cap_ClockGen_sC8_PRSdp_u0__F0_REG )
    /* Aux control */
    #define Cap_AUX_CONTROL_A_REG  (*(reg8 *) Cap_ClockGen_sC8_PRSdp_u0__DP_AUX_CTL_REG )
    #define Cap_AUX_CONTROL_A_PTR  ( (reg8 *) Cap_ClockGen_sC8_PRSdp_u0__DP_AUX_CTL_REG )
        
#elif (Cap_PRS_OPTIONS == Cap_PRS_16BITS)
    /* Polynomial */
    #define Cap_POLYNOM_REG        (*(reg16 *) Cap_ClockGen_sC16_PRSdp_u0__D0_REG )
    #define Cap_POLYNOM_PTR        ( (reg16 *) Cap_ClockGen_sC16_PRSdp_u0__D0_REG )
    /* Seed */
    #define Cap_SEED_REG           (*(reg16 *) Cap_ClockGen_sC16_PRSdp_u0__A0_REG )
    #define Cap_SEED_PTR           ( (reg16 *) Cap_ClockGen_sC16_PRSdp_u0__A0_REG )
    /* Seed COPY */
    #define Cap_SEED_COPY_REG      (*(reg16 *) Cap_ClockGen_sC16_PRSdp_u0__F0_REG )
    #define Cap_SEED_COPY_PTR      ( (reg16 *) Cap_ClockGen_sC16_PRSdp_u0__F0_REG )
    /* Aux control */
    #define Cap_AUX_CONTROL_A_REG  (*(reg8 *) Cap_ClockGen_sC16_PRSdp_u0__DP_AUX_CTL_REG )
    #define Cap_AUX_CONTROL_A_PTR  ( (reg8 *) Cap_ClockGen_sC16_PRSdp_u0__DP_AUX_CTL_REG )
    
    #define Cap_AUX_CONTROL_B_REG  (*(reg8 *) Cap_ClockGen_sC16_PRSdp_u1__DP_AUX_CTL_REG )
    #define Cap_AUX_CONTROL_B_PTR  ( (reg8 *) Cap_ClockGen_sC16_PRSdp_u1__DP_AUX_CTL_REG )
    
#elif (Cap_PRS_OPTIONS == Cap_PRS_16BITS_4X)
    /* Polynomial */   
    #define Cap_POLYNOM_A__D1_REG      (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__D1_REG )
    #define Cap_POLYNOM_A__D1_PTR      ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__D1_REG )
    
    #define Cap_POLYNOM_A__D0_REG      (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__D0_REG )
    #define Cap_POLYNOM_A__D0_PTR      ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__D0_REG )
    /* Seed */
    #define Cap_SEED_A__A1_REG         (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__A1_REG )
    #define Cap_SEED_A__A1_PTR         ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__A1_REG )
    
    #define Cap_SEED_A__A0_REG         (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__A0_REG )
    #define Cap_SEED_A__A0_PTR         ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__A0_REG )
    /* Seed COPY */
    #define Cap_SEED_COPY_A__F1_REG    (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__F1_REG )
    #define Cap_SEED_COPY_A__F1_PTR    ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__F1_REG )
    
    #define Cap_SEED_COPY_A__F0_REG    (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__F0_REG )
    #define Cap_SEED_COPY_A__F0_PTR    ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__F0_REG )
    /* Aux control */
    #define Cap_AUX_CONTROL_A_REG  (*(reg8 *) Cap_ClockGen_b0_PRSdp_a__DP_AUX_CTL_REG )
    #define Cap_AUX_CONTROL_A_PTR  ( (reg8 *) Cap_ClockGen_b0_PRSdp_a__DP_AUX_CTL_REG )
    
#else
    /* No PRS */
#endif  /* (Cap_PRS_OPTIONS == Cap_PRS_8BITS)  */

/* Measure REGs  definitions */
#if (Cap_IMPLEMENTATION_CH0 == Cap_MEASURE_IMPLEMENTATION_FF)
    /* Window PWM */
    #define Cap_PWM_CH0_PERIOD_PTR         ( (reg16 *) Cap_MeasureCH0_FF_Window__PER0 )
    #define Cap_PWM_CH0_COUNTER_PTR        ( (reg16 *) Cap_MeasureCH0_FF_Window__CNT_CMP0 )
    
    #define Cap_PWM_CH0_CONTROL_REG        (*(reg8 *) Cap_MeasureCH0_FF_Window__CFG0 )
    #define Cap_PWM_CH0_CONTROL_PTR        ( (reg8 *) Cap_MeasureCH0_FF_Window__CFG0 )
    
    #define Cap_PWM_CH0_CONTROL2_REG       (*(reg8 *) Cap_MeasureCH0_FF_Window__CFG2 )
    #define Cap_PWM_CH0_CONTROL2_PTR       ( (reg8 *) Cap_MeasureCH0_FF_Window__CFG2 )
	
    #define Cap_PWM_CH0_ACT_PWRMGR_REG     (*(reg8 *) Cap_MeasureCH0_FF_Window__PM_ACT_CFG )
    #define Cap_PWM_CH0_ACT_PWRMGR_PTR     ( (reg8 *) Cap_MeasureCH0_FF_Window__PM_ACT_CFG )
    #define Cap_PWM_CH0_ACT_PWR_EN                   (Cap_MeasureCH0_FF_Window__PM_ACT_MSK )
    
    #define Cap_PWM_CH0_STBY_PWRMGR_REG    (*(reg8 *) Cap_MeasureCH0_FF_Window__PM_STBY_CFG )
    #define Cap_PWM_CH0_STBY_PWRMGR_PTR    ( (reg8 *) Cap_MeasureCH0_FF_Window__PM_STBY_CFG )
    #define Cap_PWM_CH0_STBY_PWR_EN                  (Cap_MeasureCH0_FF_Window__PM_STBY_MSK )
    
    /* Raw Counter */
    #define Cap_RAW_CH0_PERIOD_PTR         ( (reg16 *) Cap_MeasureCH0_FF_Counter__PER0 )
    #define Cap_RAW_CH0_COUNTER_PTR        ( (reg16 *) Cap_MeasureCH0_FF_Counter__CNT_CMP0 )
    
    #define Cap_RAW_CH0_CONTROL_REG        (*(reg8 *) Cap_MeasureCH0_FF_Counter__CFG0 )
    #define Cap_RAW_CH0_CONTROL_PTR        ( (reg8 *) Cap_MeasureCH0_FF_Counter__CFG0 )
    

    #define Cap_RAW_CH0_CONTROL2_REG   (*(reg8 *) Cap_MeasureCH0_FF_Counter__CFG2 )
    #define Cap_RAW_CH0_CONTROL2_PTR   ( (reg8 *) Cap_MeasureCH0_FF_Counter__CFG2 )

    
    #define Cap_RAW_CH0_ACT_PWRMGR_REG     (*(reg8 *) Cap_MeasureCH0_FF_Counter__PM_ACT_CFG )
    #define Cap_RAW_CH0_ACT_PWRMGR_PTR     ( (reg8 *) Cap_MeasureCH0_FF_Counter__PM_ACT_CFG )
    #define Cap_RAW_CH0_ACT_PWR_EN                   (Cap_MeasureCH0_FF_Counter__PM_ACT_MSK )
    
    #define Cap_RAW_CH0_STBY_PWRMGR_REG    (*(reg8 *) Cap_MeasureCH0_FF_Counter__PM_STBY_CFG )
    #define Cap_RAW_CH0_STBY_PWRMGR_PTR    ( (reg8 *) Cap_MeasureCH0_FF_Counter__PM_STBY_CFG )
    #define Cap_RAW_CH0_STBY_PWR_EN                  (Cap_MeasureCH0_FF_Counter__PM_STBY_MSK )
#else
     /* Window PWM */
    #define Cap_PWM_CH0_COUNTER_LO_REG     (*(reg8 *) Cap_MeasureCH0_UDB_Window_u0__A0_REG )
    #define Cap_PWM_CH0_COUNTER_LO_PTR     ( (reg8 *) Cap_MeasureCH0_UDB_Window_u0__A0_REG )
    
    #define Cap_PWM_CH0_COUNTER_HI_REG     (*(reg8 *) Cap_MeasureCH0_UDB_Window_u0__A1_REG )
    #define Cap_PWM_CH0_COUNTER_HI_PTR     ( (reg8 *) Cap_MeasureCH0_UDB_Window_u0__A1_REG )
    
    #define Cap_PWM_CH0_PERIOD_LO_REG      (*(reg8 *) Cap_MeasureCH0_UDB_Window_u0__F0_REG )
    #define Cap_PWM_CH0_PERIOD_LO_PTR      ( (reg8 *) Cap_MeasureCH0_UDB_Window_u0__F0_REG )
    
    #define Cap_PWM_CH0_PERIOD_HI_REG      (*(reg8 *) Cap_MeasureCH0_UDB_Window_u0__F1_REG )
    #define Cap_PWM_CH0_PERIOD_HI_PTR      ( (reg8 *) Cap_MeasureCH0_UDB_Window_u0__F1_REG )
    
    #define Cap_PWM_CH0_ADD_VALUE_REG      (*(reg8 *) Cap_MeasureCH0_UDB_Window_u0__D0_REG )
    #define Cap_PWM_CH0_ADD_VALUE_PTR      ( (reg8 *) Cap_MeasureCH0_UDB_Window_u0__D0_REG )
    
    #define Cap_PWM_CH0_AUX_CONTROL_REG    (*(reg8 *) \
                                                            Cap_MeasureCH0_UDB_Window_u0__DP_AUX_CTL_REG )
    #define Cap_PWM_CH0_AUX_CONTROL_PTR    ( (reg8 *) \
                                                            Cap_MeasureCH0_UDB_Window_u0__DP_AUX_CTL_REG )
    
    /* Raw Counter */
    #define Cap_RAW_CH0_COUNTER_LO_REG      (*(reg8 *) Cap_MeasureCH0_UDB_Counter_u0__A0_REG )
    #define Cap_RAW_CH0_COUNTER_LO_PTR      ( (reg8 *) Cap_MeasureCH0_UDB_Counter_u0__A0_REG )
    
    #define Cap_RAW_CH0_COUNTER_HI_REG      (*(reg8 *) Cap_MeasureCH0_UDB_Counter_u0__A1_REG )
    #define Cap_RAW_CH0_COUNTER_HI_PTR      ( (reg8 *) Cap_MeasureCH0_UDB_Counter_u0__A1_REG )
    
    #define Cap_RAW_CH0_PERIOD_LO_REG       (*(reg8 *) Cap_MeasureCH0_UDB_Counter_u0__F0_REG )
    #define Cap_RAW_CH0_PERIOD_LO_PTR       ( (reg8 *) Cap_MeasureCH0_UDB_Counter_u0__F0_REG )
    
    #define Cap_RAW_CH0_PERIOD_HI_REG       (*(reg8 *) Cap_MeasureCH0_UDB_Counter_u0__F1_REG )
    #define Cap_RAW_CH0_PERIOD_HI_PTR       ( (reg8 *) Cap_MeasureCH0_UDB_Counter_u0__F1_REG )
    
    #define Cap_RAW_CH0_ADD_VALUE_REG       (*(reg8 *) Cap_MeasureCH0_UDB_Counter_u0__D0_REG )
    #define Cap_RAW_CH0_ADD_VALUE_PTR       ( (reg8 *) Cap_MeasureCH0_UDB_Counter_u0__D0_REG )
    
    #define Cap_RAW_CH0_AUX_CONTROL_REG     (*(reg8 *) \
                                                            Cap_MeasureCH0_UDB_Counter_u0__DP_AUX_CTL_REG )
    #define Cap_RAW_CH0_AUX_CONTROL_PTR     ( (reg8 *) \
                                                            Cap_MeasureCH0_UDB_Counter_u0__DP_AUX_CTL_REG )

#endif  /* (Cap_IMPLEMENTATION_CH0 == Cap_MEASURE_IMPLEMENTATION_FF) */
    
#if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
    #if (Cap_IMPLEMENTATION_CH1 == Cap_MEASURE_IMPLEMENTATION_FF)
        /* Window PWM */
        #define Cap_PWM_CH1_PERIOD_PTR        ( (reg16 *) Cap_MeasureCH1_FF_Window__PER0 )
        #define Cap_PWM_CH1_COUNTER_PTR       ( (reg16 *) Cap_MeasureCH1_FF_Window__CNT_CMP0 )
        
        #define Cap_PWM_CH1_CONTROL_REG        (*(reg8 *) Cap_MeasureCH1_FF_Window__CFG0 )
        #define Cap_PWM_CH1_CONTROL_PTR        ( (reg8 *) Cap_MeasureCH1_FF_Window__CFG0 )
        
        #define Cap_PWM_CH1_CONTROL2_REG   (*(reg8 *) Cap_MeasureCH1_FF_Window__CFG2 )
        #define Cap_PWM_CH1_CONTROL2_PTR   ( (reg8 *) Cap_MeasureCH1_FF_Window__CFG2 )
        
        #define Cap_PWM_CH1_ACT_PWRMGR_REG   (*(reg8 *) Cap_MeasureCH1_FF_Window__PM_ACT_CFG )
        #define Cap_PWM_CH1_ACT_PWRMGR_PTR   ( (reg8 *) Cap_MeasureCH1_FF_Window__PM_ACT_CFG )
        #define Cap_PWM_CH1_ACT_PWR_EN                 (Cap_MeasureCH1_FF_Window__PM_ACT_MSK )
        
        #define Cap_PWM_CH1_STBY_PWRMGR_REG (*(reg8 *) Cap_MeasureCH1_FF_Window__PM_STBY_CFG )
        #define Cap_PWM_CH1_STBY_PWRMGR_PTR ( (reg8 *) Cap_MeasureCH1_FF_Window__PM_STBY_CFG )
        #define Cap_PWM_CH1_STBY_PWR_EN               (Cap_MeasureCH1_FF_Window__PM_STBY_MSK )
            
        /* Raw Counter */
        #define Cap_RAW_CH1_PERIOD_PTR       ( (reg16 *) Cap_MeasureCH1_FF_Counter__PER0 )
        #define Cap_RAW_CH1_COUNTER_PTR      ( (reg16 *) Cap_MeasureCH1_FF_Counter__CNT_CMP0 )
        
        #define Cap_RAW_CH1_CONTROL_REG      (*(reg8 *) Cap_MeasureCH1_FF_Counter__CFG0 )
        #define Cap_RAW_CH1_CONTROL_PTR      ( (reg8 *) Cap_MeasureCH1_FF_Counter__CFG0 )
        
        #define Cap_RAW_CH1_CONTROL2_REG   (*(reg8 *) Cap_MeasureCH1_FF_Counter__CFG2 )
        #define Cap_RAW_CH1_CONTROL2_PTR   ( (reg8 *) Cap_MeasureCH1_FF_Counter__CFG2 )
        
        #define Cap_RAW_CH1_ACT_PWRMGR_REG  (*(reg8 *) Cap_MeasureCH1_FF_Counter__PM_ACT_CFG )
        #define Cap_RAW_CH1_ACT_PWRMGR_PTR  ( (reg8 *) Cap_MeasureCH1_FF_Counter__PM_ACT_CFG )
        #define Cap_RAW_CH1_ACT_PWR_EN                (Cap_MeasureCH1_FF_Counter__PM_ACT_MSK )
        
        #define Cap_RAW_CH1_STBY_PWRMGR_REG (*(reg8 *) Cap_MeasureCH1_FF_Counter__PM_STBY_CFG)
        #define Cap_RAW_CH1_STBY_PWRMGR_PTR ( (reg8 *) Cap_MeasureCH1_FF_Counter__PM_STBY_CFG)
        #define Cap_RAW_CH1_STBY_PWR_EN               (Cap_MeasureCH1_FF_Counter__PM_STBY_MSK)
    
    #else
        /* Window PWM */
        #define Cap_PWM_CH1_COUNTER_LO_REG   (*(reg8 *) Cap_MeasureCH1_UDB_Window_u0__A0_REG )
        #define Cap_PWM_CH1_COUNTER_LO_PTR   ( (reg8 *) Cap_MeasureCH1_UDB_Window_u0__A0_REG )
        
        #define Cap_PWM_CH1_COUNTER_HI_REG   (*(reg8 *) Cap_MeasureCH1_UDB_Window_u0__A1_REG )
        #define Cap_PWM_CH1_COUNTER_HI_PTR   ( (reg8 *) Cap_MeasureCH1_UDB_Window_u0__A1_REG )
        
        #define Cap_PWM_CH1_PERIOD_LO_REG    (*(reg8 *) Cap_MeasureCH1_UDB_Window_u0__F0_REG )
        #define Cap_PWM_CH1_PERIOD_LO_PTR    ( (reg8 *) Cap_MeasureCH1_UDB_Window_u0__F0_REG )
        
        #define Cap_PWM_CH1_PERIOD_HI_REG    (*(reg8 *) Cap_MeasureCH1_UDB_Window_u0__F1_REG )
        #define Cap_PWM_CH1_PERIOD_HI_PTR    ( (reg8 *) Cap_MeasureCH1_UDB_Window_u0__F1_REG )
        
        #define Cap_PWM_CH1_ADD_VALUE_REG    (*(reg8 *) Cap_MeasureCH1_UDB_Window_u0__D0_REG )
        #define Cap_PWM_CH1_ADD_VALUE_PTR    ( (reg8 *) Cap_MeasureCH1_UDB_Window_u0__D0_REG )
        
        #define Cap_PWM_CH1_AUX_CONTROL_REG  (*(reg8 *) \
                                                            Cap_MeasureCH1_UDB_Window_u0__DP_AUX_CTL_REG )
        #define Cap_PWM_CH1_AUX_CONTROL_PTR  ( (reg8 *) \
                                                            Cap_MeasureCH1_UDB_Window_u0__DP_AUX_CTL_REG )
        
        /* Raw Counter */
        #define Cap_RAW_CH1_COUNTER_LO_REG  (*(reg8 *) Cap_MeasureCH1_UDB_Counter_u0__A0_REG )
        #define Cap_RAW_CH1_COUNTER_LO_PTR  ( (reg8 *) Cap_MeasureCH1_UDB_Counter_u0__A0_REG )
        
        #define Cap_RAW_CH1_COUNTER_HI_REG  (*(reg8 *) Cap_MeasureCH1_UDB_Counter_u0__A1_REG )
        #define Cap_RAW_CH1_COUNTER_HI_PTR  ( (reg8 *) Cap_MeasureCH1_UDB_Counter_u0__A1_REG )
        
        #define Cap_RAW_CH1_PERIOD_LO_REG   (*(reg8 *) Cap_MeasureCH1_UDB_Counter_u0__F0_REG )
        #define Cap_RAW_CH1_PERIOD_LO_PTR   ( (reg8 *) Cap_MeasureCH1_UDB_Counter_u0__F0_REG )
        
        #define Cap_RAW_CH1_PERIOD_HI_REG   (*(reg8 *) Cap_MeasureCH1_UDB_Counter_u0__F1_REG )
        #define Cap_RAW_CH1_PERIOD_HI_PTR   ( (reg8 *) Cap_MeasureCH1_UDB_Counter_u0__F1_REG )
        
        #define Cap_RAW_CH1_ADD_VALUE_REG   (*(reg8 *) Cap_MeasureCH1_UDB_Counter_u0__D0_REG )
        #define Cap_RAW_CH1_ADD_VALUE_PTR   ( (reg8 *) Cap_MeasureCH1_UDB_Counter_u0__D0_REG )
        
        #define Cap_RAW_CH1_AUX_CONTROL_REG  (*(reg8 *) \
                                                            Cap_MeasureCH1_UDB_Counter_u0__DP_AUX_CTL_REG )
        #define Cap_RAW_CH1_AUX_CONTROL_PTR  ( (reg8 *) \
                                                            Cap_MeasureCH1_UDB_Counter_u0__DP_AUX_CTL_REG )
        
    #endif  /* Cap_DESIGN_TYPE */
    
#endif  /* Cap_DESIGN_TYPE */


/* CapSense Buffer REGs definitions */
#define Cap_BufCH0_CAPS_CFG0_REG           (*(reg8 *) Cap_BufCH0__CFG0 )
#define Cap_BufCH0_CAPS_CFG0_PTR           ( (reg8 *) Cap_BufCH0__CFG0 )

#define Cap_BufCH0_CAPS_CFG1_REG           (*(reg8 *) Cap_BufCH0__CFG1 )
#define Cap_BufCH0_CAPS_CFG1_PTR           ( (reg8 *) Cap_BufCH0__CFG1 )

#define Cap_BufCH0_ACT_PWRMGR_REG          (*(reg8 *) Cap_BufCH0__PM_ACT_CFG )
#define Cap_BufCH0_ACT_PWRMGR_PTR          ( (reg8 *) Cap_BufCH0__PM_ACT_CFG )
#define Cap_BufCH0_ACT_PWR_EN                        (Cap_BufCH0__PM_ACT_MSK )

#define Cap_BufCH0_STBY_PWRMGR_REG         (*(reg8 *) Cap_BufCH0__PM_STBY_CFG )
#define Cap_BufCH0_STBY_PWRMGR_PTR         ( (reg8 *) Cap_BufCH0__PM_STBY_CFG )
#define Cap_BufCH0_STBY_PWR_EN                       (Cap_BufCH0__PM_STBY_MSK )

#if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
    #define Cap_BufCH1_CAPS_CFG0_REG       (*(reg8 *) Cap_BufCH1__CFG0 )
    #define Cap_BufCH1_CAPS_CFG0_PTR       ( (reg8 *) Cap_BufCH1__CFG0 )
    
    #define Cap_BufCH1_CAPS_CFG1_REG       (*(reg8 *) Cap_BufCH1__CFG1 )
    #define Cap_BufCH1_CAPS_CFG1_PTR       ( (reg8 *) Cap_BufCH1__CFG1 )
    
    #define Cap_BufCH1_ACT_PWRMGR_REG      (*(reg8 *) Cap_BufCH1__PM_ACT_CFG )
    #define Cap_BufCH1_ACT_PWRMGR_PTR      ( (reg8 *) Cap_BufCH1__PM_ACT_CFG )
    #define Cap_BufCH1_ACT_PWR_EN                    (Cap_BufCH1__PM_ACT_MSK )
    
    #define Cap_BufCH1_STBY_PWRMGR_REG     (*(reg8 *) Cap_BufCH1__PM_STBY_CFG )
    #define Cap_BufCH1_STBY_PWRMGR_PTR     ( (reg8 *) Cap_BufCH1__PM_STBY_CFG )
    #define Cap_BufCH1_STBY_PWR_EN                   (Cap_BufCH1__PM_STBY_MSK )
#endif  /* Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN */

/* ISR Number and Priority to work with CyLib functions */
#define Cap_IsrCH0_ISR_NUMBER        (Cap_IsrCH0__INTC_NUMBER)
#define Cap_IsrCH0_ISR_PRIORITY      (Cap_IsrCH0__INTC_PRIOR_NUM)

#if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
    #define Cap_IsrCH1_ISR_NUMBER        (Cap_IsrCH1__INTC_NUMBER)
    #define Cap_IsrCH1_ISR_PRIORITY      (Cap_IsrCH1__INTC_PRIOR_NUM)
#endif /* Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN */


/***************************************
*       Register Constants
***************************************/

/* Control Register definitions */
#define Cap_CTRL_SYNC_EN                       (0x01u)
#define Cap_CTRL_START                         (0x02u)
#define Cap_CTRL_WINDOW_EN__CH0                (0x04u)
#define Cap_CTRL_WINDOW_EN__CH1                (0x08u)
/* Addtional bit to verify if component is enalbed */
#define Cap_CTRL_CAPSENSE_EN                   (0x80u)

#define Cap_IS_CAPSENSE_ENABLE(reg)            ( ((reg) & Cap_CTRL_CAPSENSE_EN) != 0u )

/* ClockGen defines */
/* Prescaler */
#define Cap_PRESCALER_CTRL_ENABLE          (0x01u)
#define Cap_PRESCALER_CTRL_MODE_CMP        (0x02u) 

#define Cap_PRESCALER_CTRL_CMP_MODE_SHIFT  (0x04u)

#define Cap_PRESCALER_CTRL_CMP_LESS_EQ         (0x02u << Cap_PRESCALER_CTRL_CMP_MODE_SHIFT)

/* Set PRS polynomial */
#define Cap_PRS8_DEFAULT_POLYNOM           (0xB8u)
#define Cap_PRS16_DEFAULT_POLYNOM          (0xB400u)

/* Scan Speed */
#define Cap_SCANSPEED_CTRL_ENABLE          (0x20u)

/* Measure defines */
/* FF Timers */
#define Cap_MEASURE_FULL_RANGE             (0xFFFFu)
#define Cap_MEASURE_FULL_RANGE_LOW         (0xFFu)
#define Cap_MEASURE_CTRL_ENABLE            (0x01u)

#define Cap_MEASURE_CTRL_MODE_SHIFT        (0x00u)


#define Cap_MEASURE_CTRL_PULSEWIDTH        (0x01u << Cap_MEASURE_CTRL_MODE_SHIFT)

/* UDB timers */
#define Cap_AUXCTRL_FIFO_SINGLE_REG        (0x03u)
 
/* Masks of PTR PC Register */
#define Cap_DR_MASK            (0x01u)
#define Cap_DM0_MASK           (0x02u)
#define Cap_DM1_MASK           (0x04u)
#define Cap_DM2_MASK           (0x08u)
#define Cap_BYP_MASK           (0x80u)

#define Cap_PRT_PC_GND         (Cap_DM2_MASK)
#define Cap_PRT_PC_HIGHZ       (Cap_DM2_MASK |Cap_DR_MASK)
#define Cap_PRT_PC_SHIELD      (Cap_DM2_MASK | Cap_DM1_MASK | \
                                             Cap_BYP_MASK)

/* CapSense Buffer definitions */
#define Cap_CSBUF_BOOST_ENABLE         (0x02u)
#define Cap_CSBUF_ENABLE               (0x01u)

/* Define direction of Current - Souce as Sink */
#if (Cap_CURRENT_SOURCE == Cap_IDAC_SOURCE)
    #define Cap_IdacCH0_IDIR      (Cap_IdacCH0_SOURCE)
    #define Cap_IdacCH1_IDIR      (Cap_IdacCH1_SOURCE)
#elif (Cap_CURRENT_SOURCE == Cap_IDAC_SINK)
    #define Cap_IdacCH0_IDIR      (Cap_IdacCH0_SINK)
    #define Cap_IdacCH1_IDIR      (Cap_IdacCH1_SINK)
#else
    /* No Idac - Rb selected */
#endif  /* (Cap_CURRENT_SOURCE == Cap_IDAC_SOURCE) */


/* Rb init function */
#if (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB)
    void Cap_InitRb(void);
#endif /* End Cap_CURRENT_SOURCE */ 

#if (Cap_IS_COMPLEX_SCANSLOTS)
    void Cap_EnableScanSlot(uint8 slot) CYREENTRANT;
    void Cap_DisableScanSlot(uint8 slot) CYREENTRANT;
    
#else
    #define Cap_EnableScanSlot(slot)   Cap_EnableSensor(slot)
    #define Cap_DisableScanSlot(slot)  Cap_DisableSensor(slot)

#endif  /* End Cap_IS_COMPLEX_SCANSLOTS */

/* Helper functions - do nto part of public interface*/

/* Find next sensor for One Channel design */
#if (Cap_DESIGN_TYPE == Cap_ONE_CHANNEL_DESIGN)
    uint8 Cap_FindNextSensor(uint8 snsIndex) CYREENTRANT;
#endif  /* End Cap_DESIGN_TYPE */

/* Find next pair for Two Channels design */
 #if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
    uint8 Cap_FindNextPair(uint8 snsIndex) CYREENTRANT;
#endif  /* End Cap_DESIGN_TYPE */

/* Start and Compete the scan */
void Cap_PreScan(uint8 sensor) CYREENTRANT;
#if (Cap_DESIGN_TYPE == Cap_ONE_CHANNEL_DESIGN)
    void Cap_PostScan(uint8 sensor) CYREENTRANT;
#else
    void Cap_PostScanCh0(uint8 sensor) CYREENTRANT;
    void Cap_PostScanCh1(uint8 sensor) CYREENTRANT;
#endif  /* End Cap_DESIGN_TYPE */

#if (Cap_PRESCALER_OPTIONS)
    void Cap_SetPrescaler(uint8 prescaler) CYREENTRANT;
#endif  /* End Cap_PRESCALER_OPTIONS */

void Cap_SetScanSpeed(uint8 scanSpeed) ;

/* SmartSense functions */
#if (Cap_TUNING_METHOD == Cap_AUTO_TUNING)
    extern uint8 Cap_lowLevelTuningDone;
    extern void Cap_AutoTune(void) ;
#endif /* End (Cap_TUNING_METHOD == Cap_AUTO_TUNING) */

/* Global software variables */
extern volatile uint8 Cap_csv;            /* CapSense CSD status, control variable */
extern volatile uint8 Cap_sensorIndex;    /* Index of scannig sensor */

#if (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB)
    extern uint8  Cap_extRbCh0Cur;
    #if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
        extern uint8  Cap_extRbCh1Cur;
    #endif /* (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)*/ 
#endif /* (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB) */ 
        
/* Global array of Raw Counts */
extern uint16 Cap_sensorRaw[Cap_TOTAL_SENSOR_COUNT];


extern Cap_BACKUP_STRUCT Cap_backup;

/****************************************************************************************
*       Obsolete definitions. Not recommended to use. Will be removed in future releases.
*****************************************************************************************/

/* Auto Tuning defualt raw counts value */
#define Cap_DEFUALT_RAW_COUNTS_VALUE    (384u)

/* IDAC_CR0 registers save/restore flags */
#define Cap_IdacCH0_RESTORE_CFG (1u)
#define Cap_IdacCH1_RESTORE_CFG (2u)
/* DAC_CR0 register value when IDAC is stopped*/
#define Cap_IDAC_STOP_CR0_VAL   (0x1Eu)

/* Idac SetRange */
#define Cap_IDAC_RANGE_MASK            (0x0Cu)
#define Cap_IDAC_RANGE_32uA            (0x00u)
#define Cap_IDAC_RANGE_255uA           (0x04u)
#define Cap_IDAC_RANGE_2mA             (0x08u)

/* CR0 IDAC Control Register 0 definitions */
/* Bit Field DAC_MODE */
#define Cap_IDAC_MODE_MASK         (0x10u)
#define Cap_IDAC_MODE_V            (0x00u)
#define Cap_IDAC_MODE_I            (0x10u)

/* CR1 Idac Control Register 1 definitions */
/* Bit Field  DAC_I_DIR */
#define Cap_IDAC_IDIR_MASK         (0x04u)
#define Cap_IDAC_IDIR_SINK         (0x04u)
#define Cap_IDAC_IDIR_SRC          (0x00u)

/* Bit Field  DAC_MX_IOFF_SRC */
#define Cap_IDAC_IDIR_CTL_MASK     (0x02u)
#define Cap_IDAC_IDIR_CTL_REG      (0x00u)
#define Cap_IDAC_IDIR_CTL_UDB      (0x02u)

/* Obsolete names of variables */
//#define Cap_SensorRaw              Cap_sensorRaw
//#define Cap_SensorEnableMask       Cap_sensorEnableMask
//#define Cap_AnalogSwitchDivider    Cap_analogSwitchDivider


#endif /* CY_CAPSENSE_CSD_Cap_H */

 /* [] END OF FILE */
