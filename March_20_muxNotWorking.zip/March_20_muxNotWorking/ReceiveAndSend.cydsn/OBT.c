/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "OBT.h"

 
void OBT()
{
    uint32 ADC_X = ThrustLeftIn_Read();
    uint32 ADC_Y = ThrustRightIn_Read();
    uint8 DIR = 0;
    
	if (ADC_X > Forwardthresh)
	{   
   	    DIR = 1;
    	//LCD_Position(1,0);
    	//LCD_PrintString("Forward 	");
    	if (ADC_Y < Leftthresh)
    	{   	 
        	//LCD_Position(1,9);
        	//LCD_PrintString("Left 	");
        	PWM_T_WriteCompare1(1700);
        	PWM_T_WriteCompare2(5000-ADC_Y);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        	//LCD_Position(1,9);
        	//LCD_PrintString("Right	");
        	PWM_T_WriteCompare1(ADC_Y);
        	PWM_T_WriteCompare2(1700);
    	}
    	else
    	{
        //	LCD_Position(1,9);
        //	LCD_PrintString("Str 	");
        	PWM_T_WriteCompare1(ADC_Y);
        	PWM_T_WriteCompare2(ADC_Y);
    	}
	}
    
    
	else if (ADC_X < Backwardthresh)
	{
   	 
    	//LCD_Position(1,0);
    	//LCD_PrintString("Backward");
        DIR =0;
    	if (ADC_Y < Leftthresh)
    	{
        //	LCD_Position(1,9);
        //	LCD_PrintString("Left  ");
        	PWM_T_WriteCompare1(4000);
        	PWM_T_WriteCompare2(2300);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //	LCD_Position(1,9);
        //	LCD_PrintString("Right ");
        	PWM_T_WriteCompare1(2300);
        	PWM_T_WriteCompare2(4000);
    	}
    	else 
    	{
        //	LCD_Position(1,9);
        //	LCD_PrintString("Str	");
        	PWM_T_WriteCompare1(5000-ADC_Y);
        	PWM_T_WriteCompare2(5000-ADC_Y);
    	}
	}
    
	else //not forwards or backwards
	{
    	//LCD_Position(1,0);
    	//LCD_PrintString("Neutral ");
    	if (ADC_Y < Leftthresh)
    	{   	 
            
        //	LCD_Position(1,9);
        //	LCD_PrintString("Left 	");
        	PWM_T_WriteCompare1(2300);
        	PWM_T_WriteCompare2(1700);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        //	LCD_Position(1,9);
        //	LCD_PrintString("Right	");
        	PWM_T_WriteCompare1(1700);
        	PWM_T_WriteCompare2(2300);
    	}
   	 
    	else
    	{
        //	LCD_Position(1,9);
        //	LCD_PrintString("Str	");
        	PWM_T_WriteCompare1(5000-ADC_X);
        	PWM_T_WriteCompare2(5000-ADC_X);
    	}
	}
}