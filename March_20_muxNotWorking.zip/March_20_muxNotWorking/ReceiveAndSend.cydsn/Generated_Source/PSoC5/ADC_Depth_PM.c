/*******************************************************************************
* File Name: ADC_Depth_PM.c
* Version 3.10
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "ADC_Depth.h"


/***************************************
* Local data allocation
***************************************/

static ADC_Depth_BACKUP_STRUCT  ADC_Depth_backup =
{
    ADC_Depth_DISABLED
};


/*******************************************************************************
* Function Name: ADC_Depth_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void ADC_Depth_SaveConfig(void)
{
    /* All configuration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: ADC_Depth_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void ADC_Depth_RestoreConfig(void)
{
    /* All congiguration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: ADC_Depth_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred routine to prepare the component for sleep.
*  The ADC_Depth_Sleep() routine saves the current component state,
*  then it calls the ADC_Stop() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  ADC_Depth_backup - The structure field 'enableState' is modified
*  depending on the enable state of the block before entering to sleep mode.
*
*******************************************************************************/
void ADC_Depth_Sleep(void)
{
    if((ADC_Depth_PWRMGR_SAR_REG  & ADC_Depth_ACT_PWR_SAR_EN) != 0u)
    {
        if((ADC_Depth_SAR_CSR0_REG & ADC_Depth_SAR_SOF_START_CONV) != 0u)
        {
            ADC_Depth_backup.enableState = ADC_Depth_ENABLED | ADC_Depth_STARTED;
        }
        else
        {
            ADC_Depth_backup.enableState = ADC_Depth_ENABLED;
        }
        ADC_Depth_Stop();
    }
    else
    {
        ADC_Depth_backup.enableState = ADC_Depth_DISABLED;
    }
}


/*******************************************************************************
* Function Name: ADC_Depth_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred routine to restore the component to the state when
*  ADC_Depth_Sleep() was called. If the component was enabled before the
*  ADC_Depth_Sleep() function was called, the
*  ADC_Depth_Wakeup() function also re-enables the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  ADC_Depth_backup - The structure field 'enableState' is used to
*  restore the enable state of block after wakeup from sleep mode.
*
*******************************************************************************/
void ADC_Depth_Wakeup(void)
{
    if(ADC_Depth_backup.enableState != ADC_Depth_DISABLED)
    {
        ADC_Depth_Enable();
        #if(ADC_Depth_DEFAULT_CONV_MODE != ADC_Depth__HARDWARE_TRIGGER)
            if((ADC_Depth_backup.enableState & ADC_Depth_STARTED) != 0u)
            {
                ADC_Depth_StartConvert();
            }
        #endif /* End ADC_Depth_DEFAULT_CONV_MODE != ADC_Depth__HARDWARE_TRIGGER */
    }
}


/* [] END OF FILE */
