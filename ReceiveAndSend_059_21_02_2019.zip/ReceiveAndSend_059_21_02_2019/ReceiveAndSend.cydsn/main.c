/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    ADC_IR_Start();
    ADC_IR_StartConvert();
    LED1_Write(1);
    LED2_Write(1);
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
uint8 tog = 0;
    for(;;)
    {
        uint8 BallastDirIn = BallastDirIn_Read();
        uint8 BallastPWMIn = BallastPWMIn_Read();
        ThrustLeftIn_Read();
        ThrustRightIn_Read();
        DivingPlanesIn_Read();
        uint16 IR=0;
        uint16 temp= 0;
        uint16 Result = 0;
        
        for(uint8 i=0; i<=7; i++)
            {
                ADC_IR_IsEndConversion(ADC_IR_WAIT_FOR_RESULT);
                temp = ADC_IR_CountsTo_mVolts(ADC_IR_GetResult16());
                Result=Result+ temp;
            } 
        IR = Result/8;
        Result = 0;
        
         // causes it to sink
        if((BallastPWMIn == 1) & (BallastDirIn == 0))
        {
            if (IR < 3100)
            {
                BallastPWMOut_Write(255);
                BallastDirOut_Write(0);
            }
            else
            {
                BallastPWMOut_Write(0);
                BallastDirOut_Write(1);
            }
        }
        
        //causes it to rise
        else if ((BallastPWMIn == 1) & (BallastDirIn == 1))
        {
            BallastPWMOut_Write(255);
            BallastDirOut_Write(1);
        }
        // no more movement
        else
        {
            BallastPWMOut_Write(0);
            BallastDirOut_Write(1);
        } 
        if (tog == 0)
        {
            LED_Write(0);
            tog = 1;
        }
        else
        {
            LED_Write(1);
            tog = 0;
        }
        CyDelay(100);
    }
}

/* [] END OF FILE */
