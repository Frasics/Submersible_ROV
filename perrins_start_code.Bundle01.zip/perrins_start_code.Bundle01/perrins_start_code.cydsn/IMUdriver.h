/*
header file created by our group
*/


#include "project.h"


//perrin's

#define BNO 0x29
    #define MODE 0x3D //0x00 for config, 0x08 for IMU
    #define CONFIGMODE 0x00
    #define IMUMODE 0x08
    #define NDOFMODE 0x0C
    #define POWER 0x3E
    #define NORMALPOWER 0x00
    #define UNITS 0x3B
    #define SYSSTATUS 0x39
    #define CALIBSTATUS 0x35
    #define ERRSTATUS 0x3A
    #define ACC_Config 0x0D

    #define PITCH_LSB 0x1E
    #define PITCH_MSB 0x1F
    #define ROLL_LSB 0x1C
    #define ROLL_MSB 0x1D
    #define YAW_LSB 0x1A
    #define YAW_MSB 0x1B
    #define ZACC_LSB 0x0C
    #define ZACC_MSB 0x0D
    #define ZGRV_LSB 0x32
    #define ZGRV_MSB 0x33

    #define CHIP_ID 0xA0
    #define SYS_TRIGGER 0x3F








#define devaddr 0x28u // default address is 0x29u, unless changed to 0x28u. which may be the case

#ifndef _IMUdriver_h_included
#define _IMUdriver_h_included

    void write8(uint8 reg_addr, uint32 data);
    uint8 read8(uint8 reg_addr);
    uint8 read16(uint8 reg_addr);
    
    signed short int read_qw();
    signed short int read_qx();
    signed short int read_qy();
    signed short int read_qz();
    signed short int read_quat_data();
    
    signed short int read_ax();
    signed short int read_ay();
    signed short int read_az();
    
    uint8 get_temp();

    void sensor_set_mode();
    void set_data_type();
    void power_set_mode();
    void set_page(uint8 page_number);
    void units_set_mode(uint8 unitsel);
    void sensor_set_mode_config();
    void sensor_set_mode_data();
    void config_sensors();
    void sys_status();
    void axis_config();
#endif
