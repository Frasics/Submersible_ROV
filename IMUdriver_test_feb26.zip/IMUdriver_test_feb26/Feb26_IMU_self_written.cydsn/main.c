/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include "IMUdriver.h"

#include "bno055.h"

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //LCD start
    LCD_Start();
    LCD_Position(0,0);
    CyDelay(1000); // required so that the chip has time to boot up
    
    //i2c start
    I2C_Start();
    I2C_DisableInt(); // required so things dont break as reccomended by Perrin
     
    LCD_PrintString("12cStart Done");
    CyDelay(500);
    LCD_Position(0,0);
    LCD_PrintString("               ");
    LCD_Position(0,0);
    // check to see if the chip address correct
    LCD_Position(0,0);
    uint8 test = read8(BNO055_CHIP_ID_ADDR);
    if (test != 0xA0)
    {
        LCD_PrintNumber(test);
        LCD_PrintString("Could not read chip id");
    }
    else
    {
        LCD_PrintInt8(test); //this should read A0
        LCD_PrintString("Succ");
    }
    LCD_Position(0,0);
    CyDelay(200);
    LCD_ClearDisplay();
    CyDelay(1000); 
    
    // for the following functions look to IMU_Driver
    sensor_set_mode_config();
    CyDelay(10);
    
    config_sensors();
    CyDelay(10);
    power_set_mode();
    CyDelay(10);
    // do not know if these Delays are required
    CyDelay(10);
    units_set_mode(0<<2);
    CyDelay(10);
    sys_status();
    CyDelay(10000);
    axis_config();
    CyDelay(10);
    sensor_set_mode_data();
    CyDelay(10);
    // end of IMU driver functions
    
    
    for(;;)
    {
        //quaternion data?
        LCD_Position(0,0);
        LCD_PrintString("  w");
        LCD_PrintNumber(read_qw);
        LCD_PrintString("  x");
        LCD_PrintNumber(read_qx);
        LCD_Position(1,0);
        LCD_PrintString("  y");
        LCD_PrintNumber(read_qy);
        LCD_PrintString("  z");
        LCD_PrintNumber(read_qz);
    }
}