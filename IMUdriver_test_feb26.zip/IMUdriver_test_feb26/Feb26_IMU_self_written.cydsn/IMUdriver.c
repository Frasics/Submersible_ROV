/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "IMUdriver.h"

#include "bno055.h"

/*READ AND WRITE FUNCTIONS*/
//Read8 Function
uint8 read8(uint8 reg_addr)
{
    uint8 status = 0;
    volatile uint8 data = 0;
    status = I2C_MasterSendStart(devaddr,I2C_WRITE_XFER_MODE);
    status = I2C_MasterWriteByte(reg_addr);
    status = I2C_MasterSendStop();
    status = I2C_MasterSendStart(devaddr, I2C_READ_XFER_MODE);
    data = I2C_MasterReadByte(I2C_NAK_DATA);
    status = I2C_MasterSendStop();
    status = I2C_MasterStatus();
    if(status !=0)
    {
        LCD_PrintString("Read Error");
    }
    return data;
}
uint8 read16(uint8 reg_addr)
{
    uint8 status = 0;
    volatile uint8 dataLSB = 0;
    volatile uint8 dataMSB = 0;
    volatile uint8 data = 0;
    status = I2C_MasterSendStart(devaddr,I2C_WRITE_XFER_MODE);
    status = I2C_MasterWriteByte(reg_addr);
    status = I2C_MasterSendStop();
    status = I2C_MasterSendStart(devaddr, I2C_READ_XFER_MODE);
    dataLSB = I2C_MasterReadByte(I2C_ACK_DATA);
    
    /* commented out because I dont think we need these, but I am not confident.
    status = I2C_MasterSendStop();
    status = I2C_MasterSendStart(devaddr, I2C_READ_XFER_MODE); 
    */
    
    dataMSB = I2C_MasterReadByte(I2C_NAK_DATA);
    status = I2C_MasterSendStop();
    data = (uint16) dataMSB;
    data = data << 8;
    data |= dataLSB;
    status = I2C_MasterStatus();
    if(status !=0)
    {
        LCD_PrintString("Read Error");
    }
    return data;
}

//Write 8 function
void write8(uint8 reg_addr, uint8 data)
{
    volatile uint8 status = 0;
    status = I2C_MasterSendStart(devaddr, I2C_WRITE_XFER_MODE);
    status = I2C_MasterWriteByte(reg_addr);
    status = I2C_MasterWriteByte(data);
    status = I2C_MasterSendStop();
}

/*END OF W/R FUNC */

/* INITIALIZATION FUNCTIONS*/
//reset chip
void reset()
{
    write8(BNO055_SYS_TRIGGER_ADDR, 0x20);
    while (read8(BNO055_CHIP_ID_ADDR) != devaddr)
    {
        CyDelay(10);
    }
}
//axis map reconfig
void axis_config()
{
    write8(BNO055_AXIS_MAP_CONFIG_ADDR, 0x00); 
    CyDelay(10);
    write8(BNO055_AXIS_MAP_SIGN_ADDR, BNO055_REMAP_AXIS_POSITIVE); //0x06 is what they have in.cpp
    CyDelay(10);
    write8(BNO055_SYS_TRIGGER_ADDR,0x00);
    CyDelay(10);
}
//get the system status
void sys_status()
{
    /* System Status (see section 4.3.58)
     ---------------------------------
     0 = Idle
     1 = System Error
     2 = Initializing Peripherals
     3 = System Iniitalization
     4 = Executing Self-Test
     5 = Sensor fusio algorithm running
     6 = System running without fusion algorithms */
    set_page(0);
    uint8 system_status = read8(BNO055_SYS_STAT_ADDR);
    
    if (system_status != 0)
    {
        LCD_PrintNumber(system_status);
    }
    else
    {
        LCD_PrintString("status good");
    }
  /* Self Test Results (see section )
     --------------------------------
     1 = test passed, 0 = test failed

     Bit 0 = Accelerometer self test
     Bit 1 = Magnetometer self test
     Bit 2 = Gyroscope self test
     Bit 3 = MCU self test

     0x0F = all good! */
    uint8 self_test_result = read8(BNO055_SELFTEST_RESULT_ADDR);

    if (self_test_result != 0)
    {
        LCD_PrintNumber(system_status);
    }
    else
    {
        LCD_PrintString("self_test good");
    }    
  /* System Error (see section 4.3.59)
     ---------------------------------
     0 = No error
     1 = Peripheral initialization error
     2 = System initialization error
     3 = Self test result failed
     4 = Register map value out of range
     5 = Register map address out of range
     6 = Register map write error
     7 = BNO low power mode not available for selected operat ion mode
     8 = Accelerometer power mode not available
     9 = Fusion algorithm configuration error
     A = Sensor configuration error */
    uint8 system_error = read8(BNO055_SYS_ERR_ADDR);
  if (system_error != 0)
    {
        LCD_PrintNumber(system_status);
    }
    else
    {
        LCD_PrintString("sys_error good");
    }
  CyDelay(200);
}
//Sets page to page 0 as required by many functions
void set_page(u8 page_number)
{
    write8(BNO055_PAGE_ID_REG, page_number);
}

//sets the power mode to power mode normal
void power_set_mode()
{
    set_page(0);
    write8(BNO055_PWR_MODE_ADDR,BNO055_POWER_MODE_NORMAL);
}    
    
// set the units for Orientation
void units_set_mode(uint8 unitsel)
{
    	    /*
    uint8_t unitsel = (0 << 7) | // Orientation = Android
                    (0 << 4) | // Temperature = Celsius
                    (0 << 2) | // Euler = Degrees
                    (1 << 1) | // Gyro = Rads
                    (0 << 0);  // Accelerometer = m/s^2
    */
    write8(BNO055_PAGE_ID_ADDR,0);
    write8(BNO055_UNIT_SEL_ADDR, unitsel); 
    write8(BNO055_SYS_TRIGGER_ADDR,0x00);
   // CyDelay(10);
}

//Sets mode config
void sensor_set_mode_config()
{
    set_page(0);
    write8(BNO055_OPERATION_MODE_REG, BNO055_OPERATION_MODE_CONFIG);
}

//Sets the sensor mode to NDOF (Nine degrees of freedom)
void sensor_set_mode_data()
{
    set_page(0);
    write8(BNO055_OPERATION_MODE_REG, BNO055_OPERATION_MODE_NDOF);
}

void config_sensors()
{
    set_page(1);
    //configure acceleration
    u16 dat = 0b00001101; // 4g , Bandwidth = 62,5Hz , normal op Mode
    write8(BNO055_ACCEL_CONFIG_ADDR, dat);
    
    //configure gyro
    dat = 0b00011000;    // Range 2000dps; Bandw = 47Hz
    write8(BNO055_GYRO_CONFIG_ADDR, dat);
    dat = 0x00;      // Normal OpMode
    write8(BNO055_GYRO_CONFIG_ADDR, dat);
    
    // Configure MAG
   // 20Hz output Rate, OpMode = regular, Power Mode Normal  S.29
   dat = 0b000110;
   write8(BNO055_MAG_CONFIG_ADDR, dat);
   // Select page 0 to read sensors
   set_page(0);

// Select BNO055 sensor units (temperature in degrees C, rate in dps, accel in mg)
   dat = 0x01;
   write8(BNO055_UNIT_SEL_ADDR, dat);

   // Select BNO055 gyro temperature source
   dat = 0x01;
   write8(BNO055_TEMP_SOURCE_REG, dat);

    // Select BNO055 system power mode
   dat = 0x00;
   write8(BNO055_PWR_MODE_ADDR, dat);

    //Switch back to sensor mode
    sensor_set_mode_data();
}

/*END OF INITIALIZATION FUNCTIONS */

/*BEGINNING OF DATA FUNCTIONS*/

//reads the quaternion data from the quaternion functions
s16 read_quat_data()
{
    set_page(0);
	s8 data_u8[4] = {0, 0, 0, 0};
			/* Read the eight byte value
			of quaternion wxyz data*/
			/* Data W*/
            data_u8[0] = read_qw();
			/* Data X*/
            data_u8[1] = read_qx();
            /* Data Y*/
            data_u8[2] = read_qy();
			/* Data Z*/
            data_u8[3] = read_qz();
    return *data_u8; // returns a pointer to the array of data
}

//read from the quaternion registers:

//Reading quaternion W
s16 read_qw()
{
    set_page(0);
    s8 qw = read8(BNO055_QUATERNION_DATA_W_LSB_VALUEW_REG);
    return qw;
}
//Reading quaternion X
s16 read_qx()
{
    set_page(0);
    s8 qx = read16(BNO055_QUATERNION_DATA_X_LSB_ADDR);
    return qx;
}
//Reading quaternion Y
s16 read_qy()
{
    set_page(0);
    s8 qy = read16(BNO055_QUATERNION_DATA_Y_LSB_ADDR);
    return qy;
}
//Reading quaternion Z
s16 read_qz()
{
    set_page(0);
    s8 qz = read16(BNO055_QUATERNION_DATA_Z_LSB_ADDR);
    return qz;
}

//reading from acceleration data 

//x-acceleration data
s16 read_ax()
{
    set_page(0);
    s8 ax = read16(BNO055_ACCEL_DATA_X_LSB_VALUEX_REG);
    return ax;
}
//y-acceleration data
s16 read_ay()
{
    set_page(0);
    s8 ay = read16(BNO055_ACCEL_DATA_Y_LSB_VALUEY_REG);
    return ay;
}
//z-acceleration data
s16 read_az()
{
    set_page(0);
    s8 az = read16(BNO055_ACCEL_DATA_Z_LSB_VALUEZ_REG);
    return az;
}

//get temperature data
uint8 get_temp()
{
    units_set_mode(0<<4);
    uint8 temp = read8(BNO055_TEMP_ADDR);
    units_set_mode(0<<2);
    return temp;
}
