/*******************************************************************************
* File Name: Cap_SMS_Wrapper.c
* Version 3.50
*
* Description:
*  This file provides the source code of wrapper between CapSense CSD component 
*  and Auto Tuning library.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Cap.h"
#include "Cap_CSHL.h"

#if (Cap_TUNING_METHOD == Cap_AUTO_TUNING)

extern uint8 Cap_noiseThreshold[Cap_WIDGET_CSHL_PARAMETERS_COUNT];
extern uint8 Cap_hysteresis[Cap_WIDGET_CSHL_PARAMETERS_COUNT];
extern uint8 Cap_widgetResolution[Cap_WIDGET_RESOLUTION_PARAMETERS_COUNT];
extern const uint8 CYCODE Cap_numberOfSensors[Cap_SENSORS_TBL_SIZE];
extern const uint8 CYCODE Cap_rawDataIndex[Cap_SENSORS_TBL_SIZE];

extern uint8 Cap_fingerThreshold[Cap_WIDGET_CSHL_PARAMETERS_COUNT];
extern uint8 Cap_idacSettings[Cap_TOTAL_SENSOR_COUNT];
extern uint8 Cap_analogSwitchDivider[Cap_TOTAL_SCANSLOT_COUNT];

extern void SMS_LIB_V3_50_CalculateThresholds(uint8 SensorNumber);
extern void SMS_LIB_V3_50_AutoTune1Ch(void);
extern void SMS_LIB_V3_50_AutoTune2Ch(void);

uint8  * SMS_LIB_noiseThreshold = Cap_noiseThreshold;
uint8 * SMS_LIB_hysteresis = Cap_hysteresis;

uint8 * SMS_LIB_widgetResolution = Cap_widgetResolution;

const uint8 CYCODE * SMS_LIB_widgetNumber = Cap_widgetNumber;
const uint8 CYCODE * SMS_LIB_numberOfSensors = Cap_numberOfSensors;
const uint8 CYCODE * SMS_LIB_rawDataIndex = Cap_rawDataIndex;

uint8 * SMS_LIB_fingerThreshold = Cap_fingerThreshold;
uint8 * SMS_LIB_idacSettings = Cap_idacSettings;
uint8 * SMS_LIB_prescaler = Cap_analogSwitchDivider;

uint16 * SMS_LIB_SensorRaw = Cap_sensorRaw;
uint16 * SMS_LIB_SensorBaseline = Cap_sensorBaseline;

const uint8 CYCODE SMS_LIB_SensorSensitivity[] = {
    2, 2, 
};


const uint8 CYCODE SMS_LIB_PrescalerTbl[] = {
    1u, 1u, 1u, 1u, 1u, 1u, 2u, 2u, 2u, 2u, 2u, 3u, 3u, 3u, 3u, 3u, 3u, 4u, 4u, 4u, 4u, 4u, 4u, 5u, 5u, 5u, 5u, 5u, 5u, 6u, 6u, 6u, 
};



uint8 SMS_LIB_Table2[Cap_TOTAL_SENSOR_COUNT];
uint8 SMS_LIB_Table3[Cap_TOTAL_SENSOR_COUNT];
uint16 SMS_LIB_Table4[Cap_TOTAL_SENSOR_COUNT];
uint16 SMS_LIB_Table5[Cap_TOTAL_SENSOR_COUNT];
uint8 SMS_LIB_Table6[Cap_TOTAL_SENSOR_COUNT];
uint8 SMS_LIB_Table7[Cap_TOTAL_SENSOR_COUNT];

uint8 SMS_LIB_Table8[Cap_END_OF_WIDGETS_INDEX];
uint8 SMS_LIB_Table9[Cap_END_OF_WIDGETS_INDEX];

uint8 SMS_LIB_Var1 = (5u);
uint16 SMS_LIB_Var2 = (10738u);

uint8 SMS_LIB_TotalSnsCnt = Cap_TOTAL_SENSOR_COUNT;
uint8 SMS_LIB_TotalScanSlCnt = Cap_TOTAL_SCANSLOT_COUNT;
uint8 SMS_LIB_EndOfWidgInd = Cap_END_OF_WIDGETS_INDEX;

#if (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
    uint8 SMS_LIB_TotalSnsCnt_CH0 = Cap_TOTAL_SENSOR_COUNT__CH0;
    uint8 SMS_LIB_TotalSnsCnt_CH1 = Cap_TOTAL_SENSOR_COUNT__CH1;
#else
    uint8 SMS_LIB_TotalSnsCnt_CH0 = 0u;
    uint8 SMS_LIB_TotalSnsCnt_CH1 = 0u;
#endif  /* (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN) */

/*******************************************************************************
* Function Name: SMS_LIB_ScanSensor
********************************************************************************
*
* Summary:
*  Wrapper to Cap_ScanSensor function.
*
* Parameters:
*  SensorNumber:  Sensor number.
*
* Return:
*  None
*
* Reentrant:
*  No
*
*******************************************************************************/
void SMS_LIB_ScanSensor(uint8 SensorNumber) 
{
    Cap_ScanSensor(SensorNumber);
}

/*******************************************************************************
* Function Name: SMS_LIB_IsBusy
********************************************************************************
*
* Summary:
*  Wrapper to Cap_IsBusy function.
*  
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
uint8 SMS_LIB_IsBusy(void) 
{
    return Cap_IsBusy();
}


/*******************************************************************************
* Function Name: Cap_CalculateThresholds
********************************************************************************
*
* Summary:
*  Wrapper to SMS_LIB_CalculateThresholds function.
*
* Parameters:
*  SensorNumber:  Sensor number.
*
* Return:
*  None
*
* Reentrant:
*  No
*
*******************************************************************************/
void Cap_CalculateThresholds(uint8 SensorNumber) 
{
    SMS_LIB_V3_50_CalculateThresholds(SensorNumber);
}


/*******************************************************************************
* Function Name: Cap_AutoTune
********************************************************************************
*
* Summary:
*  Wrapper for SMS_LIB_AutoTune1Ch or SMS_LIB_AutoTune2Ch function.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Reentrant:
*  No
*
*******************************************************************************/
void Cap_AutoTune(void) 
{
    #if (Cap_DESIGN_TYPE == Cap_ONE_CHANNEL_DESIGN)
        SMS_LIB_V3_50_AutoTune1Ch();
    #elif (Cap_DESIGN_TYPE == Cap_TWO_CHANNELS_DESIGN)
        SMS_LIB_V3_50_AutoTune2Ch();
    #endif /* (Cap_DESIGN_TYPE == Cap_ONE_CHANNEL_DESIGN) */
}

/*******************************************************************************
* Function Name: SMS_LIB_SetPrescaler
********************************************************************************
*
* Summary:
*  Empty wrapper for version compliance.
*
* Parameters:
*  prescaler:  prascaler value.
*
* Return:
*  None
*
*******************************************************************************/
void SMS_LIB_SetPrescaler(uint8 prescaler) 
{
    prescaler = prescaler;
}

void SMS_LIB_V3_50_SetAnalogSwitchesSrc_PRS(void) 
{
	Cap_SetAnalogSwitchesSource(Cap_ANALOG_SWITCHES_SRC_PRS);
}

void SMS_LIB_V3_50_SetAnalogSwitchesSrc_Prescaler(void) 
{
	Cap_SetAnalogSwitchesSource(Cap_ANALOG_SWITCHES_SRC_PRESCALER);
}

#endif  /* (Cap_TUNING_METHOD == Cap_AUTO_TUNING) */


/* [] END OF FILE */
