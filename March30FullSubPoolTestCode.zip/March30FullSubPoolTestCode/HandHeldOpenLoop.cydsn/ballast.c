
#include "project.h"
#include "ballast.h"

//uint8 count = 1;
void CapSense_DisplayState();

void ballast()
{
    /* BUTTON0 */
    uint8 bu = BallastUp_Read();
    uint8 bd = BallastDown_Read();
    
	if (bu!=0 && bd==0) 
	{   
        LED1_Write(1u);
        LED2_Write(0u);
        //////////////////////////////
        //         up              //
        /////////////////////////////
        BallastDirOut_Write(1u);
        BallastOnOut_Write(1u);          
      /*      if(value < 1328)//at max up postion
            {
                PWM_WriteCompare1(0);
                PWM_WriteCompare2(0);
            }*/        
    }
	/* BUTTON1 */
	else if (bu==0 && bd!=0)
	{     
        LED1_Write(0u);
        LED2_Write(1u);
        
        //////////////////////////////
        //         DOWN            //
        ///////////////////////////// 
        BallastOnOut_Write(1u); 
        BallastDirOut_Write(0u);
	}
	else
	{
		LED1_Write(0u);
        LED2_Write(0u);
        BallastOnOut_Write(0u);
        BallastDirOut_Write(0u);
	}
}