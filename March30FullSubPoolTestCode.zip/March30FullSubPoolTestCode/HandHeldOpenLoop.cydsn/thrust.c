/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "thrust.h"
#include "math.h"

void thrust()//volatile uint16 ADC_X,volatile uint16 ADC_Y,uint32 y, double speedMag1, double speedMag2)
{
 	 
	uint32 ResultX = 0;
	uint32 tempX;
	uint32 ResultY = 0;
	uint32 tempY;
    //uint8 DIR = 0;
    
	// for(int i=0; i<=7; i++)
    //	{
        	ADC_X_IsEndConversion(ADC_X_WAIT_FOR_RESULT);
        	tempX = ADC_X_CountsTo_mVolts(ADC_X_GetResult16());
        	ResultX += tempX;
    //	}
    	volatile uint32 ADC_X = ResultX;//8;
        
    	ResultY = 0;
      //  for(int i=0; i<=7; i++)  
      //  {
        	ADC_Y_IsEndConversion(ADC_Y_WAIT_FOR_RESULT);
        	tempY = ADC_Y_CountsTo_mVolts(ADC_Y_GetResult16());
        	ResultY += tempY;
    	//}
    	volatile uint32 ADC_Y = ResultY;//8;
        LCD_Position(0,0);
	LCD_PrintNumber(ADC_X);
    LCD_PrintString(" ");
    LCD_PrintNumber(ADC_Y);
    //Thrust_left_Write(ADC_X);
    //Thrust_right_Write(ADC_Y);
    
	if (ADC_X > Forwardthresh)
	{   
   	    //DIR = 1;
    	LCD_Position(1,0);
    	LCD_PrintString("Forward ");
    	if (ADC_Y < Leftthresh)
    	{   	 
        	LCD_Position(1,9);
        	LCD_PrintString("Left ");
        	PWM_T_WriteCompare1(3000);
            PWM_T_WriteCompare2(2100);
        	//PWM_T_WriteCompare2(5000-ADC_Y);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Right");
            //PWM_T_WriteCompare1(ADC_Y);
            PWM_T_WriteCompare1(4000);
        	PWM_T_WriteCompare2(3000);
    	}
    	else
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Str  ");
            
            if (ADC_X < 4000)
            {
                PWM_T_WriteCompare1(2500);
        	    PWM_T_WriteCompare2(2500);
            }
            else if (ADC_X < 4400)
            {
                PWM_T_WriteCompare1(3000);
        	    PWM_T_WriteCompare2(3000);
            }
            else if (ADC_X <4800)
            {
                PWM_T_WriteCompare1(4000);
        	    PWM_T_WriteCompare2(4000);
            }
           // PWM_T_WriteCompare1(ADC_X-1000);
        //	PWM_T_WriteCompare2(ADC_X-1000);
    	}
	}
    
    
	else if (ADC_X < Backwardthresh)
	{
   	 
    	LCD_Position(1,0);
    	LCD_PrintString("Backward");
       // DIR =0;
    	if (ADC_Y < Leftthresh)
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Left ");
        	PWM_T_WriteCompare1(3000);
        	PWM_T_WriteCompare2(2500);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Right");
        	PWM_T_WriteCompare1(2500);
        	PWM_T_WriteCompare2(3000);
    	}
    	else 
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Str  ");
        	PWM_T_WriteCompare1(3000);
        	PWM_T_WriteCompare2(3000);
    	}
	}
    
	else //not forwards or backwards
	{
    	LCD_Position(1,0);
    	LCD_PrintString("Neutral ");
    	if (ADC_Y < Leftthresh)
    	{   	 
            
        	LCD_Position(1,9);
        	LCD_PrintString("Left ");
        	PWM_T_WriteCompare1(3000);
        	PWM_T_WriteCompare2(1700);
    	}
    	else if(ADC_Y > Rightthresh)
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Right");
        	PWM_T_WriteCompare1(1700);
        	PWM_T_WriteCompare2(3000);
    	}
   	 
    	else
    	{
        	LCD_Position(1,9);
        	LCD_PrintString("Str  ");
        	PWM_T_WriteCompare1(1700);
        	PWM_T_WriteCompare2(1700);
    	}
	}

    /*
       
   // volatile uint32 ADC_X = ADC_X_CountsTo_mVolts(ADC_X_GetResult16()); // converts result to mV for X
   // volatile uint32 ADC_Y = ADC_Y_CountsTo_mVolts(ADC_Y_GetResult16()); // onverts results to mV for Y
   // uint32 x = (((float)ADC_X/maxPot)*(float)freq); 
    volatile float y = (((float)ADC_Y/maxPot)*(float)freq); // 
    volatile float speedX = (((float)ADC_X/3299)*(float)4000); //Calculates the PWM for thrust magnitude
    volatile float turn = (((float)ADC_Y/3299)); //calculates the turning PWM
    char turnRatio = (float)turn/2353.5; // so when not left or right this should be == 1
    // The two calculations below are for when you want to turn and move forwards atst
    //volatile double more = ((speedX^2.0) +(turnRatio^2.0));
   // volatile float less = ((speedX^2.0) - (turnRatio^2.0)); 
   // volatile double speedMag1 = sqrt(more); 
   // volatile double speedMag2 = sqrt(less);
    //end of thrust initiations
    
    if (ADC_X > Forwardthresh) // when moving forwards but not max
        {
            LCD_Position(1,0);
            LCD_PrintString("Forward     ");
            
            if (ADC_Y < Leftthresh) // if you want to turn left while moving forwards
            {
                LCD_Position(1,9);
                LCD_PrintString("Left     ");
                PWM_T_WriteCompare1(speedMag2*y); //makes the left thruster slower
                PWM_T_WriteCompare2(speedMag1*y); // makes the right thruster faster
            }
            else if (ADC_Y > Rightthresh) // if you want to go right while moving forwards
            {
                PWM_T_WriteCompare1(speedMag1*y); // makes the left thruster faster
                PWM_T_WriteCompare2(speedMag2*y); // makes the right thruster slower
                LCD_Position(1,9);
                LCD_PrintString("Right    ");
            }
            else //neither left or right
            {
                LCD_Position(1,9);
                LCD_PrintString("Str      ");
                LCD_Position(0,0);
                LCD_PrintNumber(speedMag1);
                PWM_T_WriteCompare1(speedMag1); // same speeds
                PWM_T_WriteCompare2(speedMag1); // same speeds
            }
        }
    else if (ADC_X <Backwardthresh) //for when you are moving backwards
    {
        LCD_Position(1,0);
        LCD_PrintString("Backward  ");
        if (ADC_Y < Leftthresh) // if you want to turn left while moving backwards
        {
            LCD_Position(1,9);
            LCD_PrintString("Left       ");
            PWM_T_WriteCompare1(speedMag2*y); //makes the left thruster slower
            PWM_T_WriteCompare2(speedMag1*y); // makes the right thruster faster
        }
        else if (ADC_Y > Rightthresh) // if you want to go right while moving backwards
        {
            LCD_Position(1,9);
            LCD_PrintString("Right      ");
            PWM_T_WriteCompare1(speedMag1*y); // makes the left thruster faster
            PWM_T_WriteCompare2(speedMag2*y); // makes the right thruster slower
        }
         else //neither left or right
        {
            LCD_Position(1,9);
            LCD_PrintString("Str      ");
             PWM_T_WriteCompare1(speedMag1); // same speeds
             PWM_T_WriteCompare2(speedMag1); // same speeds
        }
    }
    else // if not forwards or backwards
    {
        LCD_Position(1,0);
        LCD_PrintString("Stati       ");
        if (ADC_Y < Leftthresh) // if you want to turn left while moving backwards
        {
            LCD_Position(1,9);
            LCD_PrintString("Left       ");
            PWM_T_WriteCompare1(speedMag2*y); //makes the left thruster slower
            PWM_T_WriteCompare2(0); // makes the right thruster faster
        }
        else if (ADC_Y > Rightthresh) // if you want to go right while moving backwards
        {
            LCD_Position(1,9);
            LCD_PrintString("Right      ");
            PWM_T_WriteCompare1(0); // makes the left thruster faster
            PWM_T_WriteCompare2(speedMag2*y); // makes the right thruster slower
        }
         else //neither left or right
        {
            LCD_Position(1,9);
            LCD_PrintString("Str      ");
            // PWM_T_WriteCompare1(speedMag1); // same speeds
            // PWM_T_WriteCompare2(speedMag1); // same speeds
        }
        
    }
    
    */
}