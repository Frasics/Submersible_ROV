#include "project.h"
#include <stdio.h>
/*
********************
Pressure sensor pins:
Black: Ground
Red: 5V input
Yellow: Analog output
********************
*/
float getDepth()
{
    float value = 0;
    volatile float P = 0;
    float temp = 0;
    float ResultP = 0;
    for(int i=0; i<=7; i++)
    {
        ADC_P_IsEndConversion(ADC_P_WAIT_FOR_RESULT);
        temp = ADC_P_CountsTo_mVolts(ADC_P_GetResult16());
        ResultP = ResultP + temp;
    } 
    value = (float)ResultP/(float)8;
    P = ((value/(float)5000.0-(float)0.1)/(float)0.75)*1000; //Vout = VCC x (0.75 x P + 0.1), P is Pressure in kPa
    //Calculating depth
    float depth = P/(1000.0*9.81);
    return depth;
}