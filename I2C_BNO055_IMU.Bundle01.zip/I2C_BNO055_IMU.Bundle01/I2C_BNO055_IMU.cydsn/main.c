#include "project.h"
#include "BNO055.h"
#include <stdio.h>
//;;
const int READDELAY = 1000;

// function declarations
void write8(uint8 Reg, uint32 value);
uint8 read8(uint8 Reg);
uint16 read16(uint8 Reg);
void readMultiByte(uint8 Reg, uint8 NumberOfValues, uint8 *dest);

int main(void)
{   
    uint8 data = 0;
    int16 Q = 0;
    int16 X = 0;
    int16 Y = 0;
    int16 Z = 0;
    char buffer[50];
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    I2C_Start(); //Start I2C component
    LCD_Start();
    LCD_Position(0,0);
    LCD_PrintString("Starting..");
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_CHIP_ID_ADDR); 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("CHIP ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_ACCEL_REV_ID_ADDR); 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("ACCEL REV ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_MAG_REV_ID_ADDR); 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("MAG REV ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_GYRO_REV_ID_ADDR); 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("GYRO REV ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_SW_REV_ID_LSB_ADDR); 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("SW REV LSB ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_SW_REV_ID_MSB_ADDR); 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("SW REV MSB ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Read device ID and display on LCD
    data = read8(BNO055_BL_REV_ID_ADDR) ; 
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("BL REV ID:");
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    CyDelay(READDELAY);
    //Set to configure mode
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("Set to Config");
    write8(BNO055_OPR_MODE_ADDR, POWER_MODE_NORMAL );
    CyDelay(READDELAY);
    //Set units
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("Setting Units");
    uint8_t unitsel = (1 << 7) | // Orientation = Android (disagrees with code, agrees with datasheet)
                    (0 << 4) | // Temperature = Celsius
                    (0 << 2) | // Euler = Degrees
                    (0 << 1) | // Gyro = Degrees
                    (0 << 0);  // Accelerometer = m/s^2
    write8(BNO055_UNIT_SEL_ADDR , unitsel);
    CyDelay(READDELAY);
    //Stop future resets
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("Black Magic");
    write8(BNO055_SYS_TRIGGER_ADDR, 0x00); //stopping any future resets
    CyDelay(READDELAY);
    //Set to IMU mode
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("Setting to IMU");
    write8(BNO055_OPR_MODE_ADDR , OPERATION_MODE_IMUPLUS );
    CyDelay(READDELAY);
    //Check the status and print "good" to LCD if set to Sensor Fusion
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("System Status: ");
    uint8 status = read8(BNO055_SYS_STAT_ADDR );
    LCD_PrintNumber(status);
    LCD_Position(1,0);
    if(status == 5) { //should be 5 if sensor fusion
        LCD_PrintString(" Good");
    }
    else {
        LCD_PrintString(" Bad");
    }
    CyDelay(READDELAY);
    //Calibrate sensors
    LCD_ClearDisplay();
    LCD_Position(0,0);    
    LCD_PrintString("Please Move");
    LCD_Position(1,0);  
    LCD_PrintString("Device to Calib");
    CyDelay(10000); 
    //Check calibration status
    LCD_ClearDisplay();
    LCD_Position(0,0);   
    LCD_PrintString("Calib Status:");
    status = read8(BNO055_CALIB_STAT_ADDR );
    uint8 systatus = (status & 0b11000000) >> 6;
    uint8 gyrstatus = (status & 0b00110000) >> 4;
    uint8 accstatus = (status & 0b00001100) >> 2;
    uint8 magstatus = (status & 0b00000011);
    CyDelay(READDELAY);
    //Display status
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("SYS: ");
    LCD_PrintNumber(systatus);
    LCD_PrintString("  GYR: ");
    LCD_PrintNumber(gyrstatus);
    LCD_Position(1,0);
    LCD_PrintString("ACC: ");
    LCD_PrintNumber(accstatus);
    LCD_PrintString("  MAG: ");
    LCD_PrintNumber(magstatus);
    CyDelay(4*READDELAY); //gives user time to read

    for(;;)
    {
        /* Place your application code here. */
        Q = read16(BNO055_QUATERNION_DATA_W_LSB_ADDR);
        X = read16(BNO055_QUATERNION_DATA_X_LSB_ADDR);
        Y = read16(BNO055_QUATERNION_DATA_Y_LSB_ADDR);
        Z = read16(BNO055_QUATERNION_DATA_Z_LSB_ADDR);
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("Q");
        //LCD_PrintDecUint16(Q); //printnumber
        
        sprintf(buffer, "%i", Q);
        //printf("%s", buffer);
        LCD_PrintString(buffer);
        
        LCD_Position(0,8);
        LCD_PrintString("X");
        //LCD_PrintDecUint16(X);
        sprintf(buffer, "%i", X);
        //printf("%s", buffer);
        LCD_PrintString(buffer);
        
        LCD_Position(1,0);
        LCD_PrintString("Y");
        //LCD_PrintDecUint16(Y); //sprintf %i
        sprintf(buffer, "%i", Y);
        //printf("%s", buffer);
        LCD_PrintString(buffer);
        
        LCD_Position(1,8);
        LCD_PrintString("Z");
        //LCD_PrintDecUint16(Z);
        sprintf(buffer, "%i", Z);
        //printf("%s", buffer);
        LCD_PrintString(buffer);
        
        CyDelay(200);
    }
}

void write8(uint8 Reg, uint32 value ){
    uint8 status = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    status = I2C_MasterWriteByte(Reg );
    //Write byte to the data register specified by value
    status = I2C_MasterWriteByte(value & 0xFF);
    status = I2C_MasterSendStop();
}

uint8 read8(uint8 Reg){
    volatile uint8 status = 0;
    uint8 data = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    //Mask the command bit and the Register to read/Write from
    status = I2C_MasterWriteByte(Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //Send NAK to indicate end of data to be read
    data = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    
    return data;
}

uint16 read16(uint8 Reg){
    uint8 status = 0;
    uint16 data = 0;
    uint8 dataL = 0;
    uint8 dataH = 0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    //Mask the command bit with Comand Increment Mode and the Register to read/Write from
    status = I2C_MasterWriteByte( Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //Send ACK to acknowlege data received
    dataL = I2C_MasterReadByte(I2C_ACK_DATA);
    //Send NAK to indicate end of data to be read
    dataH = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    //Combine 2 uint8 values (High byte and Low byte) into a uint16 value
    data = (uint16) dataH;
    data = data << 8;
    data |= dataL;
    
    return data;
}

void readMultiByte(uint8 Reg, uint8 NumberOfValues, uint8 *dest){
    uint8 data[NumberOfValues];
    uint8 status = 0;
    int i =0;
    //Send start command for write mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_WRITE_XFER_MODE);
    //Specify which register we want to write to
    status = I2C_MasterWriteByte(Reg );
    status = I2C_MasterSendStop();
    //Send start command for read mode
    status = I2C_MasterSendStart(BNO055_ADDRESS, I2C_READ_XFER_MODE);
    //receive NumberOfValue - 1 values and send ACK
    for (i=0 ; i< (NumberOfValues - 1); i++){
      data[i] = I2C_MasterReadByte(I2C_ACK_DATA);
    }
    //Receive last value and send NAK
    data[i+1] = I2C_MasterReadByte(I2C_NAK_DATA);
    //Send stop bit
    status = I2C_MasterSendStop();
    for (i=0 ; i< (NumberOfValues); i++){
      dest[i] = data[i];
    }
}

/* [] END OF FILE */
