/*******************************************************************************
* File Name: BallastDownIn.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BallastDownIn_ALIASES_H) /* Pins BallastDownIn_ALIASES_H */
#define CY_PINS_BallastDownIn_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define BallastDownIn_0			(BallastDownIn__0__PC)
#define BallastDownIn_0_INTR	((uint16)((uint16)0x0001u << BallastDownIn__0__SHIFT))

#define BallastDownIn_INTR_ALL	 ((uint16)(BallastDownIn_0_INTR))

#endif /* End Pins BallastDownIn_ALIASES_H */


/* [] END OF FILE */
