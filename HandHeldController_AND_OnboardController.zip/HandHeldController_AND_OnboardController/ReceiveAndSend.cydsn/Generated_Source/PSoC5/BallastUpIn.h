/*******************************************************************************
* File Name: BallastUpIn.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BallastUpIn_H) /* Pins BallastUpIn_H */
#define CY_PINS_BallastUpIn_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BallastUpIn_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BallastUpIn__PORT == 15 && ((BallastUpIn__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BallastUpIn_Write(uint8 value);
void    BallastUpIn_SetDriveMode(uint8 mode);
uint8   BallastUpIn_ReadDataReg(void);
uint8   BallastUpIn_Read(void);
void    BallastUpIn_SetInterruptMode(uint16 position, uint16 mode);
uint8   BallastUpIn_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BallastUpIn_SetDriveMode() function.
     *  @{
     */
        #define BallastUpIn_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BallastUpIn_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BallastUpIn_DM_RES_UP          PIN_DM_RES_UP
        #define BallastUpIn_DM_RES_DWN         PIN_DM_RES_DWN
        #define BallastUpIn_DM_OD_LO           PIN_DM_OD_LO
        #define BallastUpIn_DM_OD_HI           PIN_DM_OD_HI
        #define BallastUpIn_DM_STRONG          PIN_DM_STRONG
        #define BallastUpIn_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BallastUpIn_MASK               BallastUpIn__MASK
#define BallastUpIn_SHIFT              BallastUpIn__SHIFT
#define BallastUpIn_WIDTH              1u

/* Interrupt constants */
#if defined(BallastUpIn__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BallastUpIn_SetInterruptMode() function.
     *  @{
     */
        #define BallastUpIn_INTR_NONE      (uint16)(0x0000u)
        #define BallastUpIn_INTR_RISING    (uint16)(0x0001u)
        #define BallastUpIn_INTR_FALLING   (uint16)(0x0002u)
        #define BallastUpIn_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BallastUpIn_INTR_MASK      (0x01u) 
#endif /* (BallastUpIn__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BallastUpIn_PS                     (* (reg8 *) BallastUpIn__PS)
/* Data Register */
#define BallastUpIn_DR                     (* (reg8 *) BallastUpIn__DR)
/* Port Number */
#define BallastUpIn_PRT_NUM                (* (reg8 *) BallastUpIn__PRT) 
/* Connect to Analog Globals */                                                  
#define BallastUpIn_AG                     (* (reg8 *) BallastUpIn__AG)                       
/* Analog MUX bux enable */
#define BallastUpIn_AMUX                   (* (reg8 *) BallastUpIn__AMUX) 
/* Bidirectional Enable */                                                        
#define BallastUpIn_BIE                    (* (reg8 *) BallastUpIn__BIE)
/* Bit-mask for Aliased Register Access */
#define BallastUpIn_BIT_MASK               (* (reg8 *) BallastUpIn__BIT_MASK)
/* Bypass Enable */
#define BallastUpIn_BYP                    (* (reg8 *) BallastUpIn__BYP)
/* Port wide control signals */                                                   
#define BallastUpIn_CTL                    (* (reg8 *) BallastUpIn__CTL)
/* Drive Modes */
#define BallastUpIn_DM0                    (* (reg8 *) BallastUpIn__DM0) 
#define BallastUpIn_DM1                    (* (reg8 *) BallastUpIn__DM1)
#define BallastUpIn_DM2                    (* (reg8 *) BallastUpIn__DM2) 
/* Input Buffer Disable Override */
#define BallastUpIn_INP_DIS                (* (reg8 *) BallastUpIn__INP_DIS)
/* LCD Common or Segment Drive */
#define BallastUpIn_LCD_COM_SEG            (* (reg8 *) BallastUpIn__LCD_COM_SEG)
/* Enable Segment LCD */
#define BallastUpIn_LCD_EN                 (* (reg8 *) BallastUpIn__LCD_EN)
/* Slew Rate Control */
#define BallastUpIn_SLW                    (* (reg8 *) BallastUpIn__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BallastUpIn_PRTDSI__CAPS_SEL       (* (reg8 *) BallastUpIn__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BallastUpIn_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BallastUpIn__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BallastUpIn_PRTDSI__OE_SEL0        (* (reg8 *) BallastUpIn__PRTDSI__OE_SEL0) 
#define BallastUpIn_PRTDSI__OE_SEL1        (* (reg8 *) BallastUpIn__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BallastUpIn_PRTDSI__OUT_SEL0       (* (reg8 *) BallastUpIn__PRTDSI__OUT_SEL0) 
#define BallastUpIn_PRTDSI__OUT_SEL1       (* (reg8 *) BallastUpIn__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BallastUpIn_PRTDSI__SYNC_OUT       (* (reg8 *) BallastUpIn__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BallastUpIn__SIO_CFG)
    #define BallastUpIn_SIO_HYST_EN        (* (reg8 *) BallastUpIn__SIO_HYST_EN)
    #define BallastUpIn_SIO_REG_HIFREQ     (* (reg8 *) BallastUpIn__SIO_REG_HIFREQ)
    #define BallastUpIn_SIO_CFG            (* (reg8 *) BallastUpIn__SIO_CFG)
    #define BallastUpIn_SIO_DIFF           (* (reg8 *) BallastUpIn__SIO_DIFF)
#endif /* (BallastUpIn__SIO_CFG) */

/* Interrupt Registers */
#if defined(BallastUpIn__INTSTAT)
    #define BallastUpIn_INTSTAT            (* (reg8 *) BallastUpIn__INTSTAT)
    #define BallastUpIn_SNAP               (* (reg8 *) BallastUpIn__SNAP)
    
	#define BallastUpIn_0_INTTYPE_REG 		(* (reg8 *) BallastUpIn__0__INTTYPE)
#endif /* (BallastUpIn__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BallastUpIn_H */


/* [] END OF FILE */
