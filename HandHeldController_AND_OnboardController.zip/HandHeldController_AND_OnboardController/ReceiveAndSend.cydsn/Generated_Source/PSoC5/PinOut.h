/*******************************************************************************
* File Name: PinOut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PinOut_H) /* Pins PinOut_H */
#define CY_PINS_PinOut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PinOut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PinOut__PORT == 15 && ((PinOut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    PinOut_Write(uint8 value);
void    PinOut_SetDriveMode(uint8 mode);
uint8   PinOut_ReadDataReg(void);
uint8   PinOut_Read(void);
void    PinOut_SetInterruptMode(uint16 position, uint16 mode);
uint8   PinOut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the PinOut_SetDriveMode() function.
     *  @{
     */
        #define PinOut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define PinOut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define PinOut_DM_RES_UP          PIN_DM_RES_UP
        #define PinOut_DM_RES_DWN         PIN_DM_RES_DWN
        #define PinOut_DM_OD_LO           PIN_DM_OD_LO
        #define PinOut_DM_OD_HI           PIN_DM_OD_HI
        #define PinOut_DM_STRONG          PIN_DM_STRONG
        #define PinOut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define PinOut_MASK               PinOut__MASK
#define PinOut_SHIFT              PinOut__SHIFT
#define PinOut_WIDTH              1u

/* Interrupt constants */
#if defined(PinOut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PinOut_SetInterruptMode() function.
     *  @{
     */
        #define PinOut_INTR_NONE      (uint16)(0x0000u)
        #define PinOut_INTR_RISING    (uint16)(0x0001u)
        #define PinOut_INTR_FALLING   (uint16)(0x0002u)
        #define PinOut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define PinOut_INTR_MASK      (0x01u) 
#endif /* (PinOut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PinOut_PS                     (* (reg8 *) PinOut__PS)
/* Data Register */
#define PinOut_DR                     (* (reg8 *) PinOut__DR)
/* Port Number */
#define PinOut_PRT_NUM                (* (reg8 *) PinOut__PRT) 
/* Connect to Analog Globals */                                                  
#define PinOut_AG                     (* (reg8 *) PinOut__AG)                       
/* Analog MUX bux enable */
#define PinOut_AMUX                   (* (reg8 *) PinOut__AMUX) 
/* Bidirectional Enable */                                                        
#define PinOut_BIE                    (* (reg8 *) PinOut__BIE)
/* Bit-mask for Aliased Register Access */
#define PinOut_BIT_MASK               (* (reg8 *) PinOut__BIT_MASK)
/* Bypass Enable */
#define PinOut_BYP                    (* (reg8 *) PinOut__BYP)
/* Port wide control signals */                                                   
#define PinOut_CTL                    (* (reg8 *) PinOut__CTL)
/* Drive Modes */
#define PinOut_DM0                    (* (reg8 *) PinOut__DM0) 
#define PinOut_DM1                    (* (reg8 *) PinOut__DM1)
#define PinOut_DM2                    (* (reg8 *) PinOut__DM2) 
/* Input Buffer Disable Override */
#define PinOut_INP_DIS                (* (reg8 *) PinOut__INP_DIS)
/* LCD Common or Segment Drive */
#define PinOut_LCD_COM_SEG            (* (reg8 *) PinOut__LCD_COM_SEG)
/* Enable Segment LCD */
#define PinOut_LCD_EN                 (* (reg8 *) PinOut__LCD_EN)
/* Slew Rate Control */
#define PinOut_SLW                    (* (reg8 *) PinOut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PinOut_PRTDSI__CAPS_SEL       (* (reg8 *) PinOut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PinOut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PinOut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PinOut_PRTDSI__OE_SEL0        (* (reg8 *) PinOut__PRTDSI__OE_SEL0) 
#define PinOut_PRTDSI__OE_SEL1        (* (reg8 *) PinOut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PinOut_PRTDSI__OUT_SEL0       (* (reg8 *) PinOut__PRTDSI__OUT_SEL0) 
#define PinOut_PRTDSI__OUT_SEL1       (* (reg8 *) PinOut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PinOut_PRTDSI__SYNC_OUT       (* (reg8 *) PinOut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(PinOut__SIO_CFG)
    #define PinOut_SIO_HYST_EN        (* (reg8 *) PinOut__SIO_HYST_EN)
    #define PinOut_SIO_REG_HIFREQ     (* (reg8 *) PinOut__SIO_REG_HIFREQ)
    #define PinOut_SIO_CFG            (* (reg8 *) PinOut__SIO_CFG)
    #define PinOut_SIO_DIFF           (* (reg8 *) PinOut__SIO_DIFF)
#endif /* (PinOut__SIO_CFG) */

/* Interrupt Registers */
#if defined(PinOut__INTSTAT)
    #define PinOut_INTSTAT            (* (reg8 *) PinOut__INTSTAT)
    #define PinOut_SNAP               (* (reg8 *) PinOut__SNAP)
    
	#define PinOut_0_INTTYPE_REG 		(* (reg8 *) PinOut__0__INTTYPE)
#endif /* (PinOut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PinOut_H */


/* [] END OF FILE */
