/*******************************************************************************
* File Name: Pot_LR.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pot_LR_H) /* Pins Pot_LR_H */
#define CY_PINS_Pot_LR_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Pot_LR_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Pot_LR__PORT == 15 && ((Pot_LR__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Pot_LR_Write(uint8 value);
void    Pot_LR_SetDriveMode(uint8 mode);
uint8   Pot_LR_ReadDataReg(void);
uint8   Pot_LR_Read(void);
void    Pot_LR_SetInterruptMode(uint16 position, uint16 mode);
uint8   Pot_LR_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Pot_LR_SetDriveMode() function.
     *  @{
     */
        #define Pot_LR_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Pot_LR_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Pot_LR_DM_RES_UP          PIN_DM_RES_UP
        #define Pot_LR_DM_RES_DWN         PIN_DM_RES_DWN
        #define Pot_LR_DM_OD_LO           PIN_DM_OD_LO
        #define Pot_LR_DM_OD_HI           PIN_DM_OD_HI
        #define Pot_LR_DM_STRONG          PIN_DM_STRONG
        #define Pot_LR_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Pot_LR_MASK               Pot_LR__MASK
#define Pot_LR_SHIFT              Pot_LR__SHIFT
#define Pot_LR_WIDTH              1u

/* Interrupt constants */
#if defined(Pot_LR__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Pot_LR_SetInterruptMode() function.
     *  @{
     */
        #define Pot_LR_INTR_NONE      (uint16)(0x0000u)
        #define Pot_LR_INTR_RISING    (uint16)(0x0001u)
        #define Pot_LR_INTR_FALLING   (uint16)(0x0002u)
        #define Pot_LR_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Pot_LR_INTR_MASK      (0x01u) 
#endif /* (Pot_LR__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pot_LR_PS                     (* (reg8 *) Pot_LR__PS)
/* Data Register */
#define Pot_LR_DR                     (* (reg8 *) Pot_LR__DR)
/* Port Number */
#define Pot_LR_PRT_NUM                (* (reg8 *) Pot_LR__PRT) 
/* Connect to Analog Globals */                                                  
#define Pot_LR_AG                     (* (reg8 *) Pot_LR__AG)                       
/* Analog MUX bux enable */
#define Pot_LR_AMUX                   (* (reg8 *) Pot_LR__AMUX) 
/* Bidirectional Enable */                                                        
#define Pot_LR_BIE                    (* (reg8 *) Pot_LR__BIE)
/* Bit-mask for Aliased Register Access */
#define Pot_LR_BIT_MASK               (* (reg8 *) Pot_LR__BIT_MASK)
/* Bypass Enable */
#define Pot_LR_BYP                    (* (reg8 *) Pot_LR__BYP)
/* Port wide control signals */                                                   
#define Pot_LR_CTL                    (* (reg8 *) Pot_LR__CTL)
/* Drive Modes */
#define Pot_LR_DM0                    (* (reg8 *) Pot_LR__DM0) 
#define Pot_LR_DM1                    (* (reg8 *) Pot_LR__DM1)
#define Pot_LR_DM2                    (* (reg8 *) Pot_LR__DM2) 
/* Input Buffer Disable Override */
#define Pot_LR_INP_DIS                (* (reg8 *) Pot_LR__INP_DIS)
/* LCD Common or Segment Drive */
#define Pot_LR_LCD_COM_SEG            (* (reg8 *) Pot_LR__LCD_COM_SEG)
/* Enable Segment LCD */
#define Pot_LR_LCD_EN                 (* (reg8 *) Pot_LR__LCD_EN)
/* Slew Rate Control */
#define Pot_LR_SLW                    (* (reg8 *) Pot_LR__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Pot_LR_PRTDSI__CAPS_SEL       (* (reg8 *) Pot_LR__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Pot_LR_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Pot_LR__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Pot_LR_PRTDSI__OE_SEL0        (* (reg8 *) Pot_LR__PRTDSI__OE_SEL0) 
#define Pot_LR_PRTDSI__OE_SEL1        (* (reg8 *) Pot_LR__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Pot_LR_PRTDSI__OUT_SEL0       (* (reg8 *) Pot_LR__PRTDSI__OUT_SEL0) 
#define Pot_LR_PRTDSI__OUT_SEL1       (* (reg8 *) Pot_LR__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Pot_LR_PRTDSI__SYNC_OUT       (* (reg8 *) Pot_LR__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Pot_LR__SIO_CFG)
    #define Pot_LR_SIO_HYST_EN        (* (reg8 *) Pot_LR__SIO_HYST_EN)
    #define Pot_LR_SIO_REG_HIFREQ     (* (reg8 *) Pot_LR__SIO_REG_HIFREQ)
    #define Pot_LR_SIO_CFG            (* (reg8 *) Pot_LR__SIO_CFG)
    #define Pot_LR_SIO_DIFF           (* (reg8 *) Pot_LR__SIO_DIFF)
#endif /* (Pot_LR__SIO_CFG) */

/* Interrupt Registers */
#if defined(Pot_LR__INTSTAT)
    #define Pot_LR_INTSTAT            (* (reg8 *) Pot_LR__INTSTAT)
    #define Pot_LR_SNAP               (* (reg8 *) Pot_LR__SNAP)
    
	#define Pot_LR_0_INTTYPE_REG 		(* (reg8 *) Pot_LR__0__INTTYPE)
#endif /* (Pot_LR__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Pot_LR_H */


/* [] END OF FILE */
