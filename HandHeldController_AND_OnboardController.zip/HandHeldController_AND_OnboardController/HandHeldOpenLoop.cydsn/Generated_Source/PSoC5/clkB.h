/*******************************************************************************
* File Name: clkB.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_clkB_H)
#define CY_CLOCK_clkB_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void clkB_Start(void) ;
void clkB_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void clkB_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void clkB_StandbyPower(uint8 state) ;
void clkB_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 clkB_GetDividerRegister(void) ;
void clkB_SetModeRegister(uint8 modeBitMask) ;
void clkB_ClearModeRegister(uint8 modeBitMask) ;
uint8 clkB_GetModeRegister(void) ;
void clkB_SetSourceRegister(uint8 clkSource) ;
uint8 clkB_GetSourceRegister(void) ;
#if defined(clkB__CFG3)
void clkB_SetPhaseRegister(uint8 clkPhase) ;
uint8 clkB_GetPhaseRegister(void) ;
#endif /* defined(clkB__CFG3) */

#define clkB_Enable()                       clkB_Start()
#define clkB_Disable()                      clkB_Stop()
#define clkB_SetDivider(clkDivider)         clkB_SetDividerRegister(clkDivider, 1u)
#define clkB_SetDividerValue(clkDivider)    clkB_SetDividerRegister((clkDivider) - 1u, 1u)
#define clkB_SetMode(clkMode)               clkB_SetModeRegister(clkMode)
#define clkB_SetSource(clkSource)           clkB_SetSourceRegister(clkSource)
#if defined(clkB__CFG3)
#define clkB_SetPhase(clkPhase)             clkB_SetPhaseRegister(clkPhase)
#define clkB_SetPhaseValue(clkPhase)        clkB_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(clkB__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define clkB_CLKEN              (* (reg8 *) clkB__PM_ACT_CFG)
#define clkB_CLKEN_PTR          ((reg8 *) clkB__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define clkB_CLKSTBY            (* (reg8 *) clkB__PM_STBY_CFG)
#define clkB_CLKSTBY_PTR        ((reg8 *) clkB__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define clkB_DIV_LSB            (* (reg8 *) clkB__CFG0)
#define clkB_DIV_LSB_PTR        ((reg8 *) clkB__CFG0)
#define clkB_DIV_PTR            ((reg16 *) clkB__CFG0)

/* Clock MSB divider configuration register. */
#define clkB_DIV_MSB            (* (reg8 *) clkB__CFG1)
#define clkB_DIV_MSB_PTR        ((reg8 *) clkB__CFG1)

/* Mode and source configuration register */
#define clkB_MOD_SRC            (* (reg8 *) clkB__CFG2)
#define clkB_MOD_SRC_PTR        ((reg8 *) clkB__CFG2)

#if defined(clkB__CFG3)
/* Analog clock phase configuration register */
#define clkB_PHASE              (* (reg8 *) clkB__CFG3)
#define clkB_PHASE_PTR          ((reg8 *) clkB__CFG3)
#endif /* defined(clkB__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define clkB_CLKEN_MASK         clkB__PM_ACT_MSK
#define clkB_CLKSTBY_MASK       clkB__PM_STBY_MSK

/* CFG2 field masks */
#define clkB_SRC_SEL_MSK        clkB__CFG2_SRC_SEL_MASK
#define clkB_MODE_MASK          (~(clkB_SRC_SEL_MSK))

#if defined(clkB__CFG3)
/* CFG3 phase mask */
#define clkB_PHASE_MASK         clkB__CFG3_PHASE_DLY_MASK
#endif /* defined(clkB__CFG3) */

#endif /* CY_CLOCK_clkB_H */


/* [] END OF FILE */
