/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#include "project.h"
#include "gripper.h"

void grip()
{
    volatile uint8 griptogOld;
    
    uint8 griptog = gripSW_Read();
    
    if (griptog == 1)
    {
        if (PWM_G_ReadCompare() == 255) // if its currently open
        {
            PWM_G_WriteCompare(0); // close
        }
        else if (PWM_G_ReadCompare() == 0) // if its currently closed
        {
            PWM_G_WriteCompare(255); // open
        }
        else //default open
        {
            PWM_G_WriteCompare(255); 
        }            
    }
    griptogOld = griptog;
}