/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    //initialize components
    ADC_Start();
    ADC_StartConvert();
    LCD_Start();
    Clock_Start();
    PWM_Start();
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    for(;;)
    {
        LCD_Position(0,0);
        LCD_PrintString("          ");
        LCD_Position(1,0);
        volatile float ADC_Val = ADC_CountsTo_mVolts(ADC_GetResult16()); // converts result to mV
        LCD_PrintNumber(ADC_Val);
        LCD_Position(0,0);
        float speed1 = (((float)ADC_Val/4999)*19999); //calculates forwards PWM output signal
        LCD_PrintNumber(speed1);
        PWM_WriteCompare(speed1); // this sets the speed
        
        
    }
}

/* [] END OF FILE */
