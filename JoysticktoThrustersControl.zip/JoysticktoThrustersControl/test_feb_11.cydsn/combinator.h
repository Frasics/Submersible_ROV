/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define temp_x_quat 1
#define temp_y_quat 2
#define temp_z_quat 3

#ifndef _combinator_h_included
    #define _combinator_h_included
    char balance_x(uint32 ADC_Y);
    char balance_z(uint8 ballast, uint16 plane_angle);

    #endif