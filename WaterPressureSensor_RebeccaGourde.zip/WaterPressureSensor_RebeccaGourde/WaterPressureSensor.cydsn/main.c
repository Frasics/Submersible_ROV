/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

/*

********************

Pressure sensor pins:
Black: Ground
Red: 5V input
Yellow: Analog output

********************

*/
uint16 ResultP = 0;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    uint16 value;
    uint16 P;
    uint16 temp;
    
    ADC_P_Start();
    ADC_P_StartConvert();
    
    LCD_Start();

    for(;;)
    {
        for(int i=0; i<=7; i++)
        {
            ADC_P_IsEndConversion(ADC_P_WAIT_FOR_RESULT);
            temp = ADC_P_CountsTo_mVolts(ADC_P_GetResult16());
            ResultP = ResultP + temp;
        } 
        value = ResultP/8;
        ResultP=0;
        P = (value / 5 - 0.1) / 0.75; //Vout = VCC x (0.75 x P + 0.1), P is Pressure.
        
        LCD_ClearDisplay();
        LCD_Position(0,8);
        LCD_PrintNumber(P);
        CyDelay(100); //for LCD print
        
        /*
        
        Pressure:
        out of water: 195-197
        Just below water: 197
        
        */
        
    }
}

/* [] END OF FILE */
