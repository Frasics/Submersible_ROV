/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include "math.h"
#include "ballast.h"
#include "thrust.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //thrust intiations
    ADC_X_Start();
    ADC_Y_Start();
    ADC_X_StartConvert();
    ADC_Y_StartConvert();
    //end of thruster initialization
    
    //start of ballast initiations
    PWM_B_Start();
    clkB_Start();
    LCD_Start();
    Cap_Start(); 
    Cap_InitializeAllBaselines();
    //endof ballast initiations
    
    for(;;)
    {
       LCD_Position(0,0);
       LCD_PrintNumber(ballast());
       
       thrust();//ADC_X,ADC_Y, y, speedMag1,speedMag2);
       //CyDelay(10);
    }
}
