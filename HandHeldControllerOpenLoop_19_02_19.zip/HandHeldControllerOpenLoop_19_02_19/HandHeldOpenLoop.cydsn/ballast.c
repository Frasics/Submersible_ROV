
#include "project.h"
#include "ballast.h"

uint8 count = 1;
int CapSense_DisplayState();

int ballast()
{
	CyGlobalIntEnable;    /* Enable global interrupts */
    if(Cap_IsBusy() == 0)
	{
        Cap_UpdateEnabledBaselines();
    	Cap_ScanEnabledWidgets();
	}
	CapSense_DisplayState(count);
    return count;
}

int CapSense_DisplayState()
{
    /* BUTTON0 */

	if (Cap_CheckIsWidgetActive(Cap_BUTTON0__BTN)) 
	{
        if (Cap_CheckIsWidgetActive(Cap_BUTTON1__BTN))
        {
            LED1_Write(0u);
            LED2_Write(0u);
            PWM_B_WriteCompare1(0);
            PWM_B_WriteCompare2(0);
        }
        else // up 
        {
            LED1_Write(1u);
            LED2_Write(0u);
            
            PWM_B_WriteCompare1(255);
            PWM_B_WriteCompare2(0);
            count++;
            if(count >  71)//at max up postion
            {
                PWM_B_WriteCompare1(0);
                PWM_B_WriteCompare2(0);
                count--;
            }
        }
	}
	else
	{
		LED1_Write(0u);
        PWM_B_WriteCompare1(0);
	}
   
	/* BUTTON1 */
	if (Cap_CheckIsWidgetActive(Cap_BUTTON1__BTN))
	{
        if (Cap_CheckIsWidgetActive(Cap_BUTTON0__BTN))
        {
            LED1_Write(0u);
            LED2_Write(0u);
            PWM_B_WriteCompare1(0);
            PWM_B_WriteCompare2(0);
        }
        else // DOWN 
        {
            LED1_Write(0u);
            LED2_Write(1u); 
            PWM_B_WriteCompare1(0);
            PWM_B_WriteCompare2(255);        
            count--;
            if (count <  1) //at max down position
            {
                PWM_B_WriteCompare1(0);
                PWM_B_WriteCompare2(0);
                count++;
            }
        }
	}
	else
	{
		LED2_Write(0u);
        PWM_B_WriteCompare2(0);
        CyDelay(40);
	}
    return count;
}