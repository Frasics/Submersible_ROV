#include "project.h"
#include "math.h"
#define freq 100000
    //uint32 halfFreq = freq/2;
#define maxPot 3299 // max potentiometer value
#define Forwardthresh 3900 // threshold where thrusters go forwards
#define Backwardthresh 2380 // backwards threshold
    //uint16 maxFor = 4000;// gussed maxforwards value
    //uint16 maxBack = 100;// guessed maxbackwards value
#define Rightthresh 3900 // joystick to the left 
#define Leftthresh 2000 // joystick to the right

#ifndef _thrust_h_included
    #define _thrust_h_included
    void thrust();//volatile uint16 ADC_X, volatile uint16 ADC_Y, uint32 y, double speedMag1, double speedMag2);
    #endif


/* [] END OF FILE */
