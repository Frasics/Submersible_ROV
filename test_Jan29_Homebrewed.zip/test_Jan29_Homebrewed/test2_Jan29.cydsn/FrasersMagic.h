/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "bno055.h"
#ifndef _FrasersMagic_h_included
    #define _FrasersMagic_h_included

    u8 dev_addr = BNO055_I2C_ADDR2;

    void write8(uint8 reg_addr, uint8 data);
    uint8 read8(uint8 reg_addr);
    
    s16 read_qw();
    s16 read_qx();
    s16 read_qy();
    s16 read_qz();
    s16 read_quat_data();
    
    s16 read_ax();
    s16 read_ay();
    s16 read_az();
    

    void sensor_set_mode();
    void set_data_type();
    void power_set_mode();
    void set_page(u8 page_number);
    void units_set_mode();
    void sensor_set_mode_config();
    void sensor_set_mode_data();
    void config_sensors();

#endif
