/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "bno055.h"
#include "project.h"
#include "FrasersMagic.h"

/*READ AND WRITE FUNCTIONS*/
//Read8 Function
uint8 read8(uint8 reg_addr)
{
    volatile uint8 status = 0;
    volatile uint8 dataStored = 0;
    status = I2C_MasterSendStart(dev_addr,I2C_WRITE_XFER_MODE);
    status = I2C_MasterWriteByte(reg_addr);
    status = I2C_MasterSendStop();
    status = I2C_MasterSendStart(dev_addr, I2C_READ_XFER_MODE);
    dataStored = I2C_MasterReadByte(I2C_NAK_DATA);
    status = I2C_MasterSendStop();
   // status = I2C_MasterStatus();
    if(status !=0)
    {
        LCD_PrintString("Read Error");
    }
    return dataStored;
}

//Write 8 function
void write8(uint8 reg_addr, uint8 data)
{
    volatile uint8 status = 0;
    status = I2C_MasterSendStart(dev_addr, I2C_WRITE_XFER_MODE);
    status = I2C_MasterWriteByte(reg_addr);
    status = I2C_MasterWriteByte(data);
    I2C_MasterSendStop();
}

/*END OF W/R FUNC */

/*
s8 set_data_type()
{
    write8(
}
*/

/* INITIALIZATION FUNCTIONS*/

//Sets page to page 0 as required by many functions
void set_page(u8 page_number)
{
    write8(BNO055_PAGE_ID_REG, page_number);
}

//sets the power mode to power mode normal
void power_set_mode()
{
    set_page(0);
    write8(BNO055_PWR_MODE_ADDR,BNO055_POWER_MODE_NORMAL);
    CyDelay(10);
}    
    
// set the units to Orientation = Android
void units_set_mode()
{
    	    /*
    uint8_t unitsel = (0 << 7) | // Orientation = Android
                    (0 << 4) | // Temperature = Celsius
                    (0 << 2) | // Euler = Degrees
                    (1 << 1) | // Gyro = Rads
                    (0 << 0);  // Accelerometer = m/s^2
    */
    write8(BNO055_PAGE_ID_ADDR,0);
    write8(BNO055_UNIT_SEL_ADDR, 0<<7);
    write8(BNO055_SYS_TRIGGER_ADDR,0x00);
    CyDelay(10);
}

//Sets mode config
void sensor_set_mode_config()
{
    set_page(0);
    write8(BNO055_OPERATION_MODE_REG, BNO055_OPERATION_MODE_CONFIG);
}

//Sets the sensor mode to NDOF (Nine degrees of freedom)
void sensor_set_mode_data()
{
    set_page(0);
    write8(BNO055_OPERATION_MODE_REG, BNO055_OPERATION_MODE_NDOF);
}

void config_sensors()
{
    set_page(1);
    //configure acceleration
    u16 dat = 0b00001101; // 4g , Bandwidth = 62,5Hz , normal op Mode
    write8(BNO055_ACCEL_CONFIG_ADDR, dat);
    
    //configure gyro
    dat = 0b00011000;    // Range 2000dps; Bandw = 47Hz
    write8(BNO055_GYRO_CONFIG_ADDR, dat);
    dat = 0x00;      // Normal OpMode
    write8(BNO055_GYRO_CONFIG_ADDR, dat);
    
    // Configure MAG
   // 20Hz output Rate, OpMode = regular, Power Mode Normal  S.29
   dat = 0b000110;
   write8(BNO055_MAG_CONFIG_ADDR, dat);
   // Select page 0 to read sensors
   set_page(0);

// Select BNO055 sensor units (temperature in degrees C, rate in dps, accel in mg)
   dat = 0x01;
   write8(BNO055_UNIT_SEL_ADDR, dat);

   // Select BNO055 gyro temperature source
   dat = 0x01;
   write8(BNO055_TEMP_SOURCE_REG, dat);

    // Select BNO055 system power mode
   dat = 0x00;
   write8(BNO055_PWR_MODE_ADDR, dat);

    //Switch back to sensor mode
    sensor_set_mode_data();
}

/*END OF INITIALIZATION FUNCTIONS */

/*BEGINNING OF DATA FUNCTIONS*/

//reads the quaternion data from the quaternion functions
s16 read_quat_data()
{
    set_page(0);
	s8 data_u8[4] = {0, 0, 0, 0};
			/* Read the eight byte value
			of quaternion wxyz data*/
			/* Data W*/
            data_u8[0] = read_qw();
			/* Data X*/
            data_u8[1] =read_qx();
            /* Data Y*/
            data_u8[2] = read_qy();
			/* Data Z*/
            data_u8[3] = read_qz();
    return data_u8[0];
    return data_u8[1];
    return data_u8[2];
    return data_u8[3];    
}

//read from the quaternion registers:

//Reading quaternion W
s16 read_qw()
{
    set_page(0);
    s8 qw1 = read8(BNO055_QUATERNION_DATA_W_LSB_VALUEW_REG);
    s8 qw2 = read8(BNO055_QUATERNION_DATA_W_MSB_VALUEW_REG);
    s16 qw = (s16)qw1;
    qw = qw<<8;
    qw |= qw2;
    return qw;
}
//Reading quaternion X
s16 read_qx()
{
    set_page(0);
    s8 qx1 = read8(BNO055_QUATERNION_DATA_W_LSB_ADDR);
    s8 qx2 = read8(BNO055_QUATERNION_DATA_W_MSB_ADDR);
    s16 qx = (s16)qx1;
    qx = qx<<8;
    qx |= qx2;
    return qx;
}
//Reading quaternion Y
s16 read_qy()
{
    set_page(0);
    s8 qy1 = read8(BNO055_QUATERNION_DATA_W_LSB_ADDR);
    s8 qy2 = read8(BNO055_QUATERNION_DATA_W_MSB_ADDR);
    s16 qy = (s16)qy1;
    qy = qy<<8;
    qy |= qy2;
    return qy;
}
//Reading quaternion Z
s16 read_qz()
{
    set_page(0);
    s8 qz1 = read8(BNO055_QUATERNION_DATA_W_LSB_ADDR);
    s8 qz2 = read8(BNO055_QUATERNION_DATA_W_MSB_ADDR);
    s16 qz = (s16)qz1;
    qz = qz<<8;
    qz |= qz2;
    return qz;
}

//reading from acceleration data 

//x-acceleration data
s16 read_ax()
{
    set_page(0);
    s8 ax1 = read8(BNO055_ACCEL_DATA_X_LSB_VALUEX_REG);
    s8 ax2 = read8(BNO055_ACCEL_DATA_X_MSB_VALUEX_REG);
    s16 ax = (s16)ax1;
    ax = ax<<8;
    ax |= ax2;
    return ax;
}
//y-acceleration data
s16 read_ay()
{
    set_page(0);
    s8 ay1 = read8(BNO055_ACCEL_DATA_Y_LSB_VALUEY_REG);
    s8 ay2 = read8(BNO055_ACCEL_DATA_Y_MSB_VALUEY_REG);
    s16 ay = (s16)ay1;
    ay = ay<<8;
    ay |= ay2;
    return ay;
}
//z-acceleration data
s16 read_az()
{
    set_page(0);
    s8 az1 = read8(BNO055_ACCEL_DATA_Z_LSB_VALUEZ_REG);
    s8 az2 = read8(BNO055_ACCEL_DATA_Z_MSB_VALUEZ_REG);
    s16 az = (s16)az1;
    az = az<<8;
    az |= az2;
    return az;
}
