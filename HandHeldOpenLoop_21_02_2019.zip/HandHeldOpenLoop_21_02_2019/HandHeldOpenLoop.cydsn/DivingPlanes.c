
#include "project.h"
#include "DivingPlanes.h"

//uint16 angle;
int Dive()
{
    volatile uint16 pos = 0;
    //uint16 test = DiveUp_Read();
    if(DiveUp_Read() == 0)
    {
        pos = 5000;
    }
    else if (DiveDown_Read() == 0)
    {
        pos = 3000;
    }
    else
    {
        pos=4000;
    }
    PWM_D_WriteCompare(pos);
    
    return pos;
}