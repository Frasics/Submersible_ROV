/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include "math.h"
//#include "ballast.h"
#include "thrust.h"
#include "DivingPlanes.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //thrust intiations
    ADC_X_Start();
    ADC_Y_Start();
    ADC_X_StartConvert();
    ADC_Y_StartConvert();
    PWM_T_Start();
    //end of thruster initialization
    
    //start of ballast initiations
    PWM_B_Start();
    clkB_Start();
    LCD_Start();
    Cap_Start(); 
    Cap_InitializeAllBaselines();
    //endof ballast initiations
    
    //Beginning of Diving Planes Initialization
    clk_D_Start();
    PWM_D_Start();
    //end of diving planes initializations
    
    PWM_T_Start();
    
    
    for(;;)
    {
        LCD_Position(0,0);
      //  ballast();
      //  LCD_PrintNumber(ballast());
        uint16 test = DiveUp_Read();
        LCD_PrintNumber(test);
        Dive();
        thrust();//ADC_X,ADC_Y, y, speedMag1,speedMag2);
       //CyDelay(10);
    }
}
