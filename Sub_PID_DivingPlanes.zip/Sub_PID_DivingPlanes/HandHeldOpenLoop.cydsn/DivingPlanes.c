
#include "project.h"
#include "DivingPlanes.h"

//uint16 angle;
void Dive()
{
    volatile uint16 pos = 0;
 
    //uint16 test = DiveUp_Read();
    if(DiveUp_Read() == 0 && DiveDown_Read() != 0)
    {
        if(pos < 4500)
        {
            pos += 100;
        }
        else
        {
            pos = 4500;
        }
       PWM_D_WriteCompare(pos);
    }
    else if (DiveDown_Read() == 0 && DiveUp_Read() != 0)
    {
        if(pos > 3000)
        {
            pos -= 100;
        }
        else
        {
            pos = 3000;
        }
        PWM_D_WriteCompare(pos);
    }
    else    //neutral position   
    {
        pos=3999;
        
        //Stabilization
        Stabilize(pos);
        
    }    
    
}

void Stabilize(uint16 pos)
{
    
    
    //speed -> less angle the faster it goes
    volatile float zquat = getZ();   //imu?
    
    unsigned long lastTime;
    double output, setpoint;
    double errSum, lastErr;
    double kp,ki,kd;
    
    //calculating how long its been since last run
    unsigned long now = ms();    //counter
    double timeChange = (double)(now - lastTime);
    
    double error = setpoint - zquat;
    errSum+=(error*timeChange);
    double dErr = (error-lastErr)/timeChange;
    
    //compute PID output
    output = kp*error +ki*errSum +kd*dErr;
    lastErr = error;
    lastTime = now;
    
    if(zquat > 0)
    {
        PWM_D_WriteCompare(pos-error);
    }
    else if(zquat < 0)
    {
        PWM_D_WriteCompare(pos+error);
    }
    else
    {
        PWM_D_WriteCompare(pos);
    }
    
}

unsigned long ms()
{
    uint32 currentTime = 0;
    uint32 lastTime = 0;
    uint32 deltaTime = 0;
    currentTime = CounterDP_ReadCounter();
    deltaTime = currentTime - lastTime;
    lastTime = currentTime;
    
    return deltaTime;
}