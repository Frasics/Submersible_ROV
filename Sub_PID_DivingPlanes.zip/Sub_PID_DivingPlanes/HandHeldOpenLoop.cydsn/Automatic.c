/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
#include "project.h"
#include "ballast.h"
#include "DivingPlanes.h"
#include "thrust.h"

void Rise(uint8 sw)
{
    if(sw == 1)// if activated
    {
        DirOut_Write(1);
        BallastOnOut_Write(1);  
        CyDelay(2000); //time it takes for ballast to evacutate
    }
}

void CircleTen() // circle in a 10m radius circle? Completely guessed the values
{
    PWM_T_WriteCompare1(4000);
    PWM_T_WriteCompare2(2300);
}

