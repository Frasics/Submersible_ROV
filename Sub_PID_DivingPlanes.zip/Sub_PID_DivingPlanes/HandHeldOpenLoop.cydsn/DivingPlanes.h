#include "project.h"

#ifndef _DivingPlanes_h_included
    #define _DivingPlanes_h_included
    void Dive();
    void Stabilize(uint16 pos);
    unsigned long ms();
#endif
