/*******************************************************************************
* File Name: Cap_IntClock.h
* Version 2.10
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Cap_IntClock_H)
#define CY_CLOCK_Cap_IntClock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void Cap_IntClock_Start(void) ;
void Cap_IntClock_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void Cap_IntClock_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void Cap_IntClock_StandbyPower(uint8 state) ;
void Cap_IntClock_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 Cap_IntClock_GetDividerRegister(void) ;
void Cap_IntClock_SetModeRegister(uint8 modeBitMask) ;
void Cap_IntClock_ClearModeRegister(uint8 modeBitMask) ;
uint8 Cap_IntClock_GetModeRegister(void) ;
void Cap_IntClock_SetSourceRegister(uint8 clkSource) ;
uint8 Cap_IntClock_GetSourceRegister(void) ;
#if defined(Cap_IntClock__CFG3)
void Cap_IntClock_SetPhaseRegister(uint8 clkPhase) ;
uint8 Cap_IntClock_GetPhaseRegister(void) ;
#endif /* defined(Cap_IntClock__CFG3) */

#define Cap_IntClock_Enable()                       Cap_IntClock_Start()
#define Cap_IntClock_Disable()                      Cap_IntClock_Stop()
#define Cap_IntClock_SetDivider(clkDivider)         Cap_IntClock_SetDividerRegister(clkDivider, 1u)
#define Cap_IntClock_SetDividerValue(clkDivider)    Cap_IntClock_SetDividerRegister((clkDivider) - 1u, 1u)
#define Cap_IntClock_SetMode(clkMode)               Cap_IntClock_SetModeRegister(clkMode)
#define Cap_IntClock_SetSource(clkSource)           Cap_IntClock_SetSourceRegister(clkSource)
#if defined(Cap_IntClock__CFG3)
#define Cap_IntClock_SetPhase(clkPhase)             Cap_IntClock_SetPhaseRegister(clkPhase)
#define Cap_IntClock_SetPhaseValue(clkPhase)        Cap_IntClock_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(Cap_IntClock__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define Cap_IntClock_CLKEN              (* (reg8 *) Cap_IntClock__PM_ACT_CFG)
#define Cap_IntClock_CLKEN_PTR          ((reg8 *) Cap_IntClock__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define Cap_IntClock_CLKSTBY            (* (reg8 *) Cap_IntClock__PM_STBY_CFG)
#define Cap_IntClock_CLKSTBY_PTR        ((reg8 *) Cap_IntClock__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define Cap_IntClock_DIV_LSB            (* (reg8 *) Cap_IntClock__CFG0)
#define Cap_IntClock_DIV_LSB_PTR        ((reg8 *) Cap_IntClock__CFG0)
#define Cap_IntClock_DIV_PTR            ((reg16 *) Cap_IntClock__CFG0)

/* Clock MSB divider configuration register. */
#define Cap_IntClock_DIV_MSB            (* (reg8 *) Cap_IntClock__CFG1)
#define Cap_IntClock_DIV_MSB_PTR        ((reg8 *) Cap_IntClock__CFG1)

/* Mode and source configuration register */
#define Cap_IntClock_MOD_SRC            (* (reg8 *) Cap_IntClock__CFG2)
#define Cap_IntClock_MOD_SRC_PTR        ((reg8 *) Cap_IntClock__CFG2)

#if defined(Cap_IntClock__CFG3)
/* Analog clock phase configuration register */
#define Cap_IntClock_PHASE              (* (reg8 *) Cap_IntClock__CFG3)
#define Cap_IntClock_PHASE_PTR          ((reg8 *) Cap_IntClock__CFG3)
#endif /* defined(Cap_IntClock__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define Cap_IntClock_CLKEN_MASK         Cap_IntClock__PM_ACT_MSK
#define Cap_IntClock_CLKSTBY_MASK       Cap_IntClock__PM_STBY_MSK

/* CFG2 field masks */
#define Cap_IntClock_SRC_SEL_MSK        Cap_IntClock__CFG2_SRC_SEL_MASK
#define Cap_IntClock_MODE_MASK          (~(Cap_IntClock_SRC_SEL_MSK))

#if defined(Cap_IntClock__CFG3)
/* CFG3 phase mask */
#define Cap_IntClock_PHASE_MASK         Cap_IntClock__CFG3_PHASE_DLY_MASK
#endif /* defined(Cap_IntClock__CFG3) */

#endif /* CY_CLOCK_Cap_IntClock_H */


/* [] END OF FILE */
