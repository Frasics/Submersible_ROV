/*******************************************************************************
* File Name: Cap_Pins.h
* Version 3.50
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_Pins_Cap_H)
#define CY_CAPSENSE_CSD_Pins_Cap_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Cap.h"


/***************************************
*        Function Prototypes
***************************************/

void Cap_SetAllSensorsDriveMode(uint8 mode) ;
void Cap_SetAllCmodsDriveMode(uint8 mode) ;
#if (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB)
    void Cap_SetAllRbsDriveMode(uint8 mode) ;    
#endif  /* (Cap_CURRENT_SOURCE == Cap_EXTERNAL_RB) */   


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Cap_DM_ALG_HIZ         (PIN_DM_ALG_HIZ)
#define Cap_DM_DIG_HIZ         (PIN_DM_DIG_HIZ)
#define Cap_DM_RES_UP          (PIN_DM_RES_UP)
#define Cap_DM_RES_DWN         (PIN_DM_RES_DWN)
#define Cap_DM_OD_LO           (PIN_DM_OD_LO)
#define Cap_DM_OD_HI           (PIN_DM_OD_HI)
#define Cap_DM_STRONG          (PIN_DM_STRONG)
#define Cap_DM_RES_UPDWN       (PIN_DM_RES_UPDWN)

/* PC registers defines for sensors */
#define Cap_PortCH0__Button0__BTN  Cap_PortCH0__Button0__BTN__PC
#define Cap_PortCH0__Button1__BTN  Cap_PortCH0__Button1__BTN__PC
/* For Cmods*/
#define Cap_CmodCH0_Cmod_CH0       Cap_CmodCH0__Cmod_CH0__PC


#endif /* (CY_CAPSENSE_CSD_Pins_Cap_H) */


/* [] END OF FILE */
