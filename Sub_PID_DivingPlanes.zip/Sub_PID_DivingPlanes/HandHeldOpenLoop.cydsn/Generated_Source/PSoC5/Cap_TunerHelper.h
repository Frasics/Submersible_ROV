/*******************************************************************************
* File Name: Cap_TunerHelper.h
* Version 3.50
*
* Description:
*  This file provides constants and structure declarations for the tunner hepl
*  APIs for CapSense CSD component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_TUNERHELPER_Cap_H)
#define CY_CAPSENSE_CSD_TUNERHELPER_Cap_H

#include "Cap.h"
#include "Cap_CSHL.h"
#if (Cap_TUNER_API_GENERATE)
    #include "Cap_MBX.h"
    #include "EZI2C.h"
#endif /* (Cap_TUNER_API_GENERATE) */


/***************************************
*     Constants for mailboxes
***************************************/

#define Cap_DEFAULT_MAILBOXES_NUMBER   (1u)


/***************************************
*        Function Prototypes
***************************************/

void Cap_TunerStart(void) ;
void Cap_TunerComm(void) ;

#if (Cap_TUNER_API_GENERATE)
    Cap_NO_STRICT_VOLATILE void Cap_ProcessAllWidgets(volatile Cap_OUTBOX *outbox)
	                                        					;

    extern volatile Cap_MAILBOXES Cap_mailboxesComm;
#endif /* (Cap_TUNER_API_GENERATE) */

#endif  /* (CY_CAPSENSE_CSD_TUNERHELPER_Cap_H)*/


/* [] END OF FILE */
