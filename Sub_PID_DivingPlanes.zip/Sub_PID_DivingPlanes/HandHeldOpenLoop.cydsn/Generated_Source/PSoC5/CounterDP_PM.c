/*******************************************************************************
* File Name: CounterDP_PM.c  
* Version 3.0
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CounterDP.h"

static CounterDP_backupStruct CounterDP_backup;


/*******************************************************************************
* Function Name: CounterDP_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  CounterDP_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void CounterDP_SaveConfig(void) 
{
    #if (!CounterDP_UsingFixedFunction)

        CounterDP_backup.CounterUdb = CounterDP_ReadCounter();

        #if(!CounterDP_ControlRegRemoved)
            CounterDP_backup.CounterControlRegister = CounterDP_ReadControlRegister();
        #endif /* (!CounterDP_ControlRegRemoved) */

    #endif /* (!CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  CounterDP_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void CounterDP_RestoreConfig(void) 
{      
    #if (!CounterDP_UsingFixedFunction)

       CounterDP_WriteCounter(CounterDP_backup.CounterUdb);

        #if(!CounterDP_ControlRegRemoved)
            CounterDP_WriteControlRegister(CounterDP_backup.CounterControlRegister);
        #endif /* (!CounterDP_ControlRegRemoved) */

    #endif /* (!CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  CounterDP_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void CounterDP_Sleep(void) 
{
    #if(!CounterDP_ControlRegRemoved)
        /* Save Counter's enable state */
        if(CounterDP_CTRL_ENABLE == (CounterDP_CONTROL & CounterDP_CTRL_ENABLE))
        {
            /* Counter is enabled */
            CounterDP_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            CounterDP_backup.CounterEnableState = 0u;
        }
    #else
        CounterDP_backup.CounterEnableState = 1u;
        if(CounterDP_backup.CounterEnableState != 0u)
        {
            CounterDP_backup.CounterEnableState = 0u;
        }
    #endif /* (!CounterDP_ControlRegRemoved) */
    
    CounterDP_Stop();
    CounterDP_SaveConfig();
}


/*******************************************************************************
* Function Name: CounterDP_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  CounterDP_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void CounterDP_Wakeup(void) 
{
    CounterDP_RestoreConfig();
    #if(!CounterDP_ControlRegRemoved)
        if(CounterDP_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            CounterDP_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!CounterDP_ControlRegRemoved) */
    
}


/* [] END OF FILE */
