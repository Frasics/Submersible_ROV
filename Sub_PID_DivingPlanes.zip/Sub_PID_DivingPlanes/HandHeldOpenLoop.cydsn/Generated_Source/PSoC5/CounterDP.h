/*******************************************************************************
* File Name: CounterDP.h  
* Version 3.0
*
*  Description:
*   Contains the function prototypes and constants available to the counter
*   user module.
*
*   Note:
*    None
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
    
#if !defined(CY_COUNTER_CounterDP_H)
#define CY_COUNTER_CounterDP_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 CounterDP_initVar;

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Counter_v3_0 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */

/* Error message for removed CounterDP_CounterUDB_sCTRLReg_ctrlreg through optimization */
#ifdef CounterDP_CounterUDB_sCTRLReg_ctrlreg__REMOVED
    #error Counter_v3_0 detected with a constant 0 for the enable, a \
                                constant 0 for the count or constant 1 for \
                                the reset. This will prevent the component from\
                                operating.
#endif /* CounterDP_CounterUDB_sCTRLReg_ctrlreg__REMOVED */


/**************************************
*           Parameter Defaults        
**************************************/

#define CounterDP_Resolution            32u
#define CounterDP_UsingFixedFunction    0u
#define CounterDP_ControlRegRemoved     0u
#define CounterDP_COMPARE_MODE_SOFTWARE 0u
#define CounterDP_CAPTURE_MODE_SOFTWARE 0u
#define CounterDP_RunModeUsed           0u


/***************************************
*       Type defines
***************************************/


/**************************************************************************
 * Sleep Mode API Support
 * Backup structure for Sleep Wake up operations
 *************************************************************************/
typedef struct
{
    uint8 CounterEnableState; 
    uint32 CounterUdb;         /* Current Counter Value */

    #if (!CounterDP_ControlRegRemoved)
        uint8 CounterControlRegister;               /* Counter Control Register */
    #endif /* (!CounterDP_ControlRegRemoved) */

}CounterDP_backupStruct;


/**************************************
 *  Function Prototypes
 *************************************/
void    CounterDP_Start(void) ;
void    CounterDP_Stop(void) ;
void    CounterDP_SetInterruptMode(uint8 interruptsMask) ;
uint8   CounterDP_ReadStatusRegister(void) ;
#define CounterDP_GetInterruptSource() CounterDP_ReadStatusRegister()
#if(!CounterDP_ControlRegRemoved)
    uint8   CounterDP_ReadControlRegister(void) ;
    void    CounterDP_WriteControlRegister(uint8 control) \
        ;
#endif /* (!CounterDP_ControlRegRemoved) */
#if (!(CounterDP_UsingFixedFunction && (CY_PSOC5A)))
    void    CounterDP_WriteCounter(uint32 counter) \
            ; 
#endif /* (!(CounterDP_UsingFixedFunction && (CY_PSOC5A))) */
uint32  CounterDP_ReadCounter(void) ;
uint32  CounterDP_ReadCapture(void) ;
void    CounterDP_WritePeriod(uint32 period) \
    ;
uint32  CounterDP_ReadPeriod( void ) ;
#if (!CounterDP_UsingFixedFunction)
    void    CounterDP_WriteCompare(uint32 compare) \
        ;
    uint32  CounterDP_ReadCompare( void ) \
        ;
#endif /* (!CounterDP_UsingFixedFunction) */

#if (CounterDP_COMPARE_MODE_SOFTWARE)
    void    CounterDP_SetCompareMode(uint8 compareMode) ;
#endif /* (CounterDP_COMPARE_MODE_SOFTWARE) */
#if (CounterDP_CAPTURE_MODE_SOFTWARE)
    void    CounterDP_SetCaptureMode(uint8 captureMode) ;
#endif /* (CounterDP_CAPTURE_MODE_SOFTWARE) */
void CounterDP_ClearFIFO(void)     ;
void CounterDP_Init(void)          ;
void CounterDP_Enable(void)        ;
void CounterDP_SaveConfig(void)    ;
void CounterDP_RestoreConfig(void) ;
void CounterDP_Sleep(void)         ;
void CounterDP_Wakeup(void)        ;


/***************************************
*   Enumerated Types and Parameters
***************************************/

/* Enumerated Type B_Counter__CompareModes, Used in Compare Mode retained for backward compatibility of tests*/
#define CounterDP__B_COUNTER__LESS_THAN 1
#define CounterDP__B_COUNTER__LESS_THAN_OR_EQUAL 2
#define CounterDP__B_COUNTER__EQUAL 0
#define CounterDP__B_COUNTER__GREATER_THAN 3
#define CounterDP__B_COUNTER__GREATER_THAN_OR_EQUAL 4
#define CounterDP__B_COUNTER__SOFTWARE 5

/* Enumerated Type Counter_CompareModes */
#define CounterDP_CMP_MODE_LT 1u
#define CounterDP_CMP_MODE_LTE 2u
#define CounterDP_CMP_MODE_EQ 0u
#define CounterDP_CMP_MODE_GT 3u
#define CounterDP_CMP_MODE_GTE 4u
#define CounterDP_CMP_MODE_SOFTWARE_CONTROLLED 5u

/* Enumerated Type B_Counter__CaptureModes, Used in Capture Mode retained for backward compatibility of tests*/
#define CounterDP__B_COUNTER__NONE 0
#define CounterDP__B_COUNTER__RISING_EDGE 1
#define CounterDP__B_COUNTER__FALLING_EDGE 2
#define CounterDP__B_COUNTER__EITHER_EDGE 3
#define CounterDP__B_COUNTER__SOFTWARE_CONTROL 4

/* Enumerated Type Counter_CompareModes */
#define CounterDP_CAP_MODE_NONE 0u
#define CounterDP_CAP_MODE_RISE 1u
#define CounterDP_CAP_MODE_FALL 2u
#define CounterDP_CAP_MODE_BOTH 3u
#define CounterDP_CAP_MODE_SOFTWARE_CONTROLLED 4u


/***************************************
 *  Initialization Values
 **************************************/
#define CounterDP_CAPTURE_MODE_CONF       0u
#define CounterDP_INIT_PERIOD_VALUE       4294967294u
#define CounterDP_INIT_COUNTER_VALUE      0u
#if (CounterDP_UsingFixedFunction)
#define CounterDP_INIT_INTERRUPTS_MASK    ((uint8)((uint8)0u << CounterDP_STATUS_ZERO_INT_EN_MASK_SHIFT))
#else
#define CounterDP_INIT_COMPARE_VALUE      4294967294u
#define CounterDP_INIT_INTERRUPTS_MASK ((uint8)((uint8)0u << CounterDP_STATUS_ZERO_INT_EN_MASK_SHIFT) | \
        ((uint8)((uint8)0u << CounterDP_STATUS_CAPTURE_INT_EN_MASK_SHIFT)) | \
        ((uint8)((uint8)0u << CounterDP_STATUS_CMP_INT_EN_MASK_SHIFT)) | \
        ((uint8)((uint8)0u << CounterDP_STATUS_OVERFLOW_INT_EN_MASK_SHIFT)) | \
        ((uint8)((uint8)0u << CounterDP_STATUS_UNDERFLOW_INT_EN_MASK_SHIFT)))
#define CounterDP_DEFAULT_COMPARE_MODE    1u

#if( 0 != CounterDP_CAPTURE_MODE_CONF)
    #define CounterDP_DEFAULT_CAPTURE_MODE    ((uint8)((uint8)0u << CounterDP_CTRL_CAPMODE0_SHIFT))
#else    
    #define CounterDP_DEFAULT_CAPTURE_MODE    (0u )
#endif /* ( 0 != CounterDP_CAPTURE_MODE_CONF) */

#endif /* (CounterDP_UsingFixedFunction) */


/**************************************
 *  Registers
 *************************************/
#if (CounterDP_UsingFixedFunction)
    #define CounterDP_STATICCOUNT_LSB     (*(reg16 *) CounterDP_CounterHW__CAP0 )
    #define CounterDP_STATICCOUNT_LSB_PTR ( (reg16 *) CounterDP_CounterHW__CAP0 )
    #define CounterDP_PERIOD_LSB          (*(reg16 *) CounterDP_CounterHW__PER0 )
    #define CounterDP_PERIOD_LSB_PTR      ( (reg16 *) CounterDP_CounterHW__PER0 )
    /* MODE must be set to 1 to set the compare value */
    #define CounterDP_COMPARE_LSB         (*(reg16 *) CounterDP_CounterHW__CNT_CMP0 )
    #define CounterDP_COMPARE_LSB_PTR     ( (reg16 *) CounterDP_CounterHW__CNT_CMP0 )
    /* MODE must be set to 0 to get the count */
    #define CounterDP_COUNTER_LSB         (*(reg16 *) CounterDP_CounterHW__CNT_CMP0 )
    #define CounterDP_COUNTER_LSB_PTR     ( (reg16 *) CounterDP_CounterHW__CNT_CMP0 )
    #define CounterDP_RT1                 (*(reg8 *) CounterDP_CounterHW__RT1)
    #define CounterDP_RT1_PTR             ( (reg8 *) CounterDP_CounterHW__RT1)
#else
    
    #if (CounterDP_Resolution <= 8u) /* 8-bit Counter */
    
        #define CounterDP_STATICCOUNT_LSB     (*(reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
        #define CounterDP_STATICCOUNT_LSB_PTR ( (reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
        #define CounterDP_PERIOD_LSB          (*(reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
        #define CounterDP_PERIOD_LSB_PTR      ( (reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
        #define CounterDP_COMPARE_LSB         (*(reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
        #define CounterDP_COMPARE_LSB_PTR     ( (reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
        #define CounterDP_COUNTER_LSB         (*(reg8 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )  
        #define CounterDP_COUNTER_LSB_PTR     ( (reg8 *)\
            CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )
    
    #elif(CounterDP_Resolution <= 16u) /* 16-bit Counter */
        #if(CY_PSOC3) /* 8-bit address space */ 
            #define CounterDP_STATICCOUNT_LSB     (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
            #define CounterDP_STATICCOUNT_LSB_PTR ( (reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
            #define CounterDP_PERIOD_LSB          (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
            #define CounterDP_PERIOD_LSB_PTR      ( (reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
            #define CounterDP_COMPARE_LSB         (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
            #define CounterDP_COMPARE_LSB_PTR     ( (reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
            #define CounterDP_COUNTER_LSB         (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )  
            #define CounterDP_COUNTER_LSB_PTR     ( (reg16 *)\
                CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )
        #else /* 16-bit address space */
            #define CounterDP_STATICCOUNT_LSB     (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_F0_REG )
            #define CounterDP_STATICCOUNT_LSB_PTR ( (reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_F0_REG )
            #define CounterDP_PERIOD_LSB          (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_D0_REG )
            #define CounterDP_PERIOD_LSB_PTR      ( (reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_D0_REG )
            #define CounterDP_COMPARE_LSB         (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_D1_REG )
            #define CounterDP_COMPARE_LSB_PTR     ( (reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_D1_REG )
            #define CounterDP_COUNTER_LSB         (*(reg16 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_A0_REG )  
            #define CounterDP_COUNTER_LSB_PTR     ( (reg16 *)\
                CounterDP_CounterUDB_sC32_counterdp_u0__16BIT_A0_REG )
        #endif /* CY_PSOC3 */   
    #elif(CounterDP_Resolution <= 24u) /* 24-bit Counter */
        
        #define CounterDP_STATICCOUNT_LSB     (*(reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
        #define CounterDP_STATICCOUNT_LSB_PTR ( (reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
        #define CounterDP_PERIOD_LSB          (*(reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
        #define CounterDP_PERIOD_LSB_PTR      ( (reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
        #define CounterDP_COMPARE_LSB         (*(reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
        #define CounterDP_COMPARE_LSB_PTR     ( (reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
        #define CounterDP_COUNTER_LSB         (*(reg32 *) \
            CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )  
        #define CounterDP_COUNTER_LSB_PTR     ( (reg32 *)\
            CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )
    
    #else /* 32-bit Counter */
        #if(CY_PSOC3 || CY_PSOC5) /* 8-bit address space */
            #define CounterDP_STATICCOUNT_LSB     (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
            #define CounterDP_STATICCOUNT_LSB_PTR ( (reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__F0_REG )
            #define CounterDP_PERIOD_LSB          (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
            #define CounterDP_PERIOD_LSB_PTR      ( (reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D0_REG )
            #define CounterDP_COMPARE_LSB         (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
            #define CounterDP_COMPARE_LSB_PTR     ( (reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__D1_REG )
            #define CounterDP_COUNTER_LSB         (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )  
            #define CounterDP_COUNTER_LSB_PTR     ( (reg32 *)\
                CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )
        #else /* 32-bit address space */
            #define CounterDP_STATICCOUNT_LSB     (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_F0_REG )
            #define CounterDP_STATICCOUNT_LSB_PTR ( (reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_F0_REG )
            #define CounterDP_PERIOD_LSB          (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_D0_REG )
            #define CounterDP_PERIOD_LSB_PTR      ( (reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_D0_REG )
            #define CounterDP_COMPARE_LSB         (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_D1_REG )
            #define CounterDP_COMPARE_LSB_PTR     ( (reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_D1_REG )
            #define CounterDP_COUNTER_LSB         (*(reg32 *) \
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_A0_REG )  
            #define CounterDP_COUNTER_LSB_PTR     ( (reg32 *)\
                CounterDP_CounterUDB_sC32_counterdp_u0__32BIT_A0_REG )
        #endif /* CY_PSOC3 || CY_PSOC5 */   
    #endif

	#define CounterDP_COUNTER_LSB_PTR_8BIT     ( (reg8 *)\
                CounterDP_CounterUDB_sC32_counterdp_u0__A0_REG )
				
    #define CounterDP_AUX_CONTROLDP0 \
        (*(reg8 *) CounterDP_CounterUDB_sC32_counterdp_u0__DP_AUX_CTL_REG)
    
    #define CounterDP_AUX_CONTROLDP0_PTR \
        ( (reg8 *) CounterDP_CounterUDB_sC32_counterdp_u0__DP_AUX_CTL_REG)
    
    #if (CounterDP_Resolution == 16 || CounterDP_Resolution == 24 || CounterDP_Resolution == 32)
       #define CounterDP_AUX_CONTROLDP1 \
           (*(reg8 *) CounterDP_CounterUDB_sC32_counterdp_u1__DP_AUX_CTL_REG)
       #define CounterDP_AUX_CONTROLDP1_PTR \
           ( (reg8 *) CounterDP_CounterUDB_sC32_counterdp_u1__DP_AUX_CTL_REG)
    #endif /* (CounterDP_Resolution == 16 || CounterDP_Resolution == 24 || CounterDP_Resolution == 32) */
    
    #if (CounterDP_Resolution == 24 || CounterDP_Resolution == 32)
       #define CounterDP_AUX_CONTROLDP2 \
           (*(reg8 *) CounterDP_CounterUDB_sC32_counterdp_u2__DP_AUX_CTL_REG)
       #define CounterDP_AUX_CONTROLDP2_PTR \
           ( (reg8 *) CounterDP_CounterUDB_sC32_counterdp_u2__DP_AUX_CTL_REG)
    #endif /* (CounterDP_Resolution == 24 || CounterDP_Resolution == 32) */
    
    #if (CounterDP_Resolution == 32)
       #define CounterDP_AUX_CONTROLDP3 \
           (*(reg8 *) CounterDP_CounterUDB_sC32_counterdp_u3__DP_AUX_CTL_REG)
       #define CounterDP_AUX_CONTROLDP3_PTR \
           ( (reg8 *) CounterDP_CounterUDB_sC32_counterdp_u3__DP_AUX_CTL_REG)
    #endif /* (CounterDP_Resolution == 32) */

#endif  /* (CounterDP_UsingFixedFunction) */

#if (CounterDP_UsingFixedFunction)
    #define CounterDP_STATUS         (*(reg8 *) CounterDP_CounterHW__SR0 )
    /* In Fixed Function Block Status and Mask are the same register */
    #define CounterDP_STATUS_MASK             (*(reg8 *) CounterDP_CounterHW__SR0 )
    #define CounterDP_STATUS_MASK_PTR         ( (reg8 *) CounterDP_CounterHW__SR0 )
    #define CounterDP_CONTROL                 (*(reg8 *) CounterDP_CounterHW__CFG0)
    #define CounterDP_CONTROL_PTR             ( (reg8 *) CounterDP_CounterHW__CFG0)
    #define CounterDP_CONTROL2                (*(reg8 *) CounterDP_CounterHW__CFG1)
    #define CounterDP_CONTROL2_PTR            ( (reg8 *) CounterDP_CounterHW__CFG1)
    #if (CY_PSOC3 || CY_PSOC5LP)
        #define CounterDP_CONTROL3       (*(reg8 *) CounterDP_CounterHW__CFG2)
        #define CounterDP_CONTROL3_PTR   ( (reg8 *) CounterDP_CounterHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define CounterDP_GLOBAL_ENABLE           (*(reg8 *) CounterDP_CounterHW__PM_ACT_CFG)
    #define CounterDP_GLOBAL_ENABLE_PTR       ( (reg8 *) CounterDP_CounterHW__PM_ACT_CFG)
    #define CounterDP_GLOBAL_STBY_ENABLE      (*(reg8 *) CounterDP_CounterHW__PM_STBY_CFG)
    #define CounterDP_GLOBAL_STBY_ENABLE_PTR  ( (reg8 *) CounterDP_CounterHW__PM_STBY_CFG)
    

    /********************************
    *    Constants
    ********************************/

    /* Fixed Function Block Chosen */
    #define CounterDP_BLOCK_EN_MASK          CounterDP_CounterHW__PM_ACT_MSK
    #define CounterDP_BLOCK_STBY_EN_MASK     CounterDP_CounterHW__PM_STBY_MSK 
    
    /* Control Register Bit Locations */    
    /* As defined in Register Map, part of TMRX_CFG0 register */
    #define CounterDP_CTRL_ENABLE_SHIFT      0x00u
    #define CounterDP_ONESHOT_SHIFT          0x02u
    /* Control Register Bit Masks */
    #define CounterDP_CTRL_ENABLE            ((uint8)((uint8)0x01u << CounterDP_CTRL_ENABLE_SHIFT))         
    #define CounterDP_ONESHOT                ((uint8)((uint8)0x01u << CounterDP_ONESHOT_SHIFT))

    /* Control2 Register Bit Masks */
    /* Set the mask for run mode */
    #if (CY_PSOC5A)
        /* Use CFG1 Mode bits to set run mode */
        #define CounterDP_CTRL_MODE_SHIFT        0x01u    
        #define CounterDP_CTRL_MODE_MASK         ((uint8)((uint8)0x07u << CounterDP_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC5A) */
    #if (CY_PSOC3 || CY_PSOC5LP)
        /* Use CFG2 Mode bits to set run mode */
        #define CounterDP_CTRL_MODE_SHIFT        0x00u    
        #define CounterDP_CTRL_MODE_MASK         ((uint8)((uint8)0x03u << CounterDP_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    /* Set the mask for interrupt (raw/status register) */
    #define CounterDP_CTRL2_IRQ_SEL_SHIFT     0x00u
    #define CounterDP_CTRL2_IRQ_SEL          ((uint8)((uint8)0x01u << CounterDP_CTRL2_IRQ_SEL_SHIFT))     
    
    /* Status Register Bit Locations */
    #define CounterDP_STATUS_ZERO_SHIFT      0x07u  /* As defined in Register Map, part of TMRX_SR0 register */ 

    /* Status Register Interrupt Enable Bit Locations */
    #define CounterDP_STATUS_ZERO_INT_EN_MASK_SHIFT      (CounterDP_STATUS_ZERO_SHIFT - 0x04u)

    /* Status Register Bit Masks */                           
    #define CounterDP_STATUS_ZERO            ((uint8)((uint8)0x01u << CounterDP_STATUS_ZERO_SHIFT))

    /* Status Register Interrupt Bit Masks*/
    #define CounterDP_STATUS_ZERO_INT_EN_MASK       ((uint8)((uint8)CounterDP_STATUS_ZERO >> 0x04u))
    
    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP */
    #define CounterDP_RT1_SHIFT            0x04u
    #define CounterDP_RT1_MASK             ((uint8)((uint8)0x03u << CounterDP_RT1_SHIFT))  /* Sync TC and CMP bit masks */
    #define CounterDP_SYNC                 ((uint8)((uint8)0x03u << CounterDP_RT1_SHIFT))
    #define CounterDP_SYNCDSI_SHIFT        0x00u
    #define CounterDP_SYNCDSI_MASK         ((uint8)((uint8)0x0Fu << CounterDP_SYNCDSI_SHIFT)) /* Sync all DSI inputs */
    #define CounterDP_SYNCDSI_EN           ((uint8)((uint8)0x0Fu << CounterDP_SYNCDSI_SHIFT)) /* Sync all DSI inputs */
    
#else /* !CounterDP_UsingFixedFunction */
    #define CounterDP_STATUS               (* (reg8 *) CounterDP_CounterUDB_sSTSReg_stsreg__STATUS_REG )
    #define CounterDP_STATUS_PTR           (  (reg8 *) CounterDP_CounterUDB_sSTSReg_stsreg__STATUS_REG )
    #define CounterDP_STATUS_MASK          (* (reg8 *) CounterDP_CounterUDB_sSTSReg_stsreg__MASK_REG )
    #define CounterDP_STATUS_MASK_PTR      (  (reg8 *) CounterDP_CounterUDB_sSTSReg_stsreg__MASK_REG )
    #define CounterDP_STATUS_AUX_CTRL      (*(reg8 *) CounterDP_CounterUDB_sSTSReg_stsreg__STATUS_AUX_CTL_REG)
    #define CounterDP_STATUS_AUX_CTRL_PTR  ( (reg8 *) CounterDP_CounterUDB_sSTSReg_stsreg__STATUS_AUX_CTL_REG)
    #define CounterDP_CONTROL              (* (reg8 *) CounterDP_CounterUDB_sCTRLReg_ctrlreg__CONTROL_REG )
    #define CounterDP_CONTROL_PTR          (  (reg8 *) CounterDP_CounterUDB_sCTRLReg_ctrlreg__CONTROL_REG )


    /********************************
    *    Constants
    ********************************/
    /* Control Register Bit Locations */
    #define CounterDP_CTRL_CAPMODE0_SHIFT    0x03u       /* As defined by Verilog Implementation */
    #define CounterDP_CTRL_RESET_SHIFT       0x06u       /* As defined by Verilog Implementation */
    #define CounterDP_CTRL_ENABLE_SHIFT      0x07u       /* As defined by Verilog Implementation */
    /* Control Register Bit Masks */
    #define CounterDP_CTRL_CMPMODE_MASK      0x07u 
    #define CounterDP_CTRL_CAPMODE_MASK      0x03u  
    #define CounterDP_CTRL_RESET             ((uint8)((uint8)0x01u << CounterDP_CTRL_RESET_SHIFT))  
    #define CounterDP_CTRL_ENABLE            ((uint8)((uint8)0x01u << CounterDP_CTRL_ENABLE_SHIFT)) 

    /* Status Register Bit Locations */
    #define CounterDP_STATUS_CMP_SHIFT       0x00u       /* As defined by Verilog Implementation */
    #define CounterDP_STATUS_ZERO_SHIFT      0x01u       /* As defined by Verilog Implementation */
    #define CounterDP_STATUS_OVERFLOW_SHIFT  0x02u       /* As defined by Verilog Implementation */
    #define CounterDP_STATUS_UNDERFLOW_SHIFT 0x03u       /* As defined by Verilog Implementation */
    #define CounterDP_STATUS_CAPTURE_SHIFT   0x04u       /* As defined by Verilog Implementation */
    #define CounterDP_STATUS_FIFOFULL_SHIFT  0x05u       /* As defined by Verilog Implementation */
    #define CounterDP_STATUS_FIFONEMP_SHIFT  0x06u       /* As defined by Verilog Implementation */
    /* Status Register Interrupt Enable Bit Locations - UDB Status Interrupt Mask match Status Bit Locations*/
    #define CounterDP_STATUS_CMP_INT_EN_MASK_SHIFT       CounterDP_STATUS_CMP_SHIFT       
    #define CounterDP_STATUS_ZERO_INT_EN_MASK_SHIFT      CounterDP_STATUS_ZERO_SHIFT      
    #define CounterDP_STATUS_OVERFLOW_INT_EN_MASK_SHIFT  CounterDP_STATUS_OVERFLOW_SHIFT  
    #define CounterDP_STATUS_UNDERFLOW_INT_EN_MASK_SHIFT CounterDP_STATUS_UNDERFLOW_SHIFT 
    #define CounterDP_STATUS_CAPTURE_INT_EN_MASK_SHIFT   CounterDP_STATUS_CAPTURE_SHIFT   
    #define CounterDP_STATUS_FIFOFULL_INT_EN_MASK_SHIFT  CounterDP_STATUS_FIFOFULL_SHIFT  
    #define CounterDP_STATUS_FIFONEMP_INT_EN_MASK_SHIFT  CounterDP_STATUS_FIFONEMP_SHIFT  
    /* Status Register Bit Masks */                
    #define CounterDP_STATUS_CMP             ((uint8)((uint8)0x01u << CounterDP_STATUS_CMP_SHIFT))  
    #define CounterDP_STATUS_ZERO            ((uint8)((uint8)0x01u << CounterDP_STATUS_ZERO_SHIFT)) 
    #define CounterDP_STATUS_OVERFLOW        ((uint8)((uint8)0x01u << CounterDP_STATUS_OVERFLOW_SHIFT)) 
    #define CounterDP_STATUS_UNDERFLOW       ((uint8)((uint8)0x01u << CounterDP_STATUS_UNDERFLOW_SHIFT)) 
    #define CounterDP_STATUS_CAPTURE         ((uint8)((uint8)0x01u << CounterDP_STATUS_CAPTURE_SHIFT)) 
    #define CounterDP_STATUS_FIFOFULL        ((uint8)((uint8)0x01u << CounterDP_STATUS_FIFOFULL_SHIFT))
    #define CounterDP_STATUS_FIFONEMP        ((uint8)((uint8)0x01u << CounterDP_STATUS_FIFONEMP_SHIFT))
    /* Status Register Interrupt Bit Masks  - UDB Status Interrupt Mask match Status Bit Locations */
    #define CounterDP_STATUS_CMP_INT_EN_MASK            CounterDP_STATUS_CMP                    
    #define CounterDP_STATUS_ZERO_INT_EN_MASK           CounterDP_STATUS_ZERO            
    #define CounterDP_STATUS_OVERFLOW_INT_EN_MASK       CounterDP_STATUS_OVERFLOW        
    #define CounterDP_STATUS_UNDERFLOW_INT_EN_MASK      CounterDP_STATUS_UNDERFLOW       
    #define CounterDP_STATUS_CAPTURE_INT_EN_MASK        CounterDP_STATUS_CAPTURE         
    #define CounterDP_STATUS_FIFOFULL_INT_EN_MASK       CounterDP_STATUS_FIFOFULL        
    #define CounterDP_STATUS_FIFONEMP_INT_EN_MASK       CounterDP_STATUS_FIFONEMP         
    

    /* StatusI Interrupt Enable bit Location in the Auxilliary Control Register */
    #define CounterDP_STATUS_ACTL_INT_EN     0x10u /* As defined for the ACTL Register */
    
    /* Datapath Auxillary Control Register definitions */
    #define CounterDP_AUX_CTRL_FIFO0_CLR         0x01u   /* As defined by Register map */
    #define CounterDP_AUX_CTRL_FIFO1_CLR         0x02u   /* As defined by Register map */
    #define CounterDP_AUX_CTRL_FIFO0_LVL         0x04u   /* As defined by Register map */
    #define CounterDP_AUX_CTRL_FIFO1_LVL         0x08u   /* As defined by Register map */
    #define CounterDP_STATUS_ACTL_INT_EN_MASK    0x10u   /* As defined for the ACTL Register */
    
#endif /* CounterDP_UsingFixedFunction */

#endif  /* CY_COUNTER_CounterDP_H */


/* [] END OF FILE */

