/*******************************************************************************
* File Name: CounterDP.c  
* Version 3.0
*
*  Description:
*     The Counter component consists of a 8, 16, 24 or 32-bit counter with
*     a selectable period between 2 and 2^Width - 1.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CounterDP.h"

uint8 CounterDP_initVar = 0u;


/*******************************************************************************
* Function Name: CounterDP_Init
********************************************************************************
* Summary:
*     Initialize to the schematic state
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void CounterDP_Init(void) 
{
        #if (!CounterDP_UsingFixedFunction && !CounterDP_ControlRegRemoved)
            uint8 ctrl;
        #endif /* (!CounterDP_UsingFixedFunction && !CounterDP_ControlRegRemoved) */
        
        #if(!CounterDP_UsingFixedFunction) 
            /* Interrupt State Backup for Critical Region*/
            uint8 CounterDP_interruptState;
        #endif /* (!CounterDP_UsingFixedFunction) */
        
        #if (CounterDP_UsingFixedFunction)
            /* Clear all bits but the enable bit (if it's already set for Timer operation */
            CounterDP_CONTROL &= CounterDP_CTRL_ENABLE;
            
            /* Clear the mode bits for continuous run mode */
            #if (CY_PSOC5A)
                CounterDP_CONTROL2 &= ((uint8)(~CounterDP_CTRL_MODE_MASK));
            #endif /* (CY_PSOC5A) */
            #if (CY_PSOC3 || CY_PSOC5LP)
                CounterDP_CONTROL3 &= ((uint8)(~CounterDP_CTRL_MODE_MASK));                
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            /* Check if One Shot mode is enabled i.e. RunMode !=0*/
            #if (CounterDP_RunModeUsed != 0x0u)
                /* Set 3rd bit of Control register to enable one shot mode */
                CounterDP_CONTROL |= CounterDP_ONESHOT;
            #endif /* (CounterDP_RunModeUsed != 0x0u) */
            
            /* Set the IRQ to use the status register interrupts */
            CounterDP_CONTROL2 |= CounterDP_CTRL2_IRQ_SEL;
            
            /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
            CounterDP_RT1 &= ((uint8)(~CounterDP_RT1_MASK));
            CounterDP_RT1 |= CounterDP_SYNC;     
                    
            /*Enable DSI Sync all all inputs of the Timer*/
            CounterDP_RT1 &= ((uint8)(~CounterDP_SYNCDSI_MASK));
            CounterDP_RT1 |= CounterDP_SYNCDSI_EN;

        #else
            #if(!CounterDP_ControlRegRemoved)
            /* Set the default compare mode defined in the parameter */
            ctrl = CounterDP_CONTROL & ((uint8)(~CounterDP_CTRL_CMPMODE_MASK));
            CounterDP_CONTROL = ctrl | CounterDP_DEFAULT_COMPARE_MODE;
            
            /* Set the default capture mode defined in the parameter */
            ctrl = CounterDP_CONTROL & ((uint8)(~CounterDP_CTRL_CAPMODE_MASK));
            
            #if( 0 != CounterDP_CAPTURE_MODE_CONF)
                CounterDP_CONTROL = ctrl | CounterDP_DEFAULT_CAPTURE_MODE;
            #else
                CounterDP_CONTROL = ctrl;
            #endif /* 0 != CounterDP_CAPTURE_MODE */ 
            
            #endif /* (!CounterDP_ControlRegRemoved) */
        #endif /* (CounterDP_UsingFixedFunction) */
        
        /* Clear all data in the FIFO's */
        #if (!CounterDP_UsingFixedFunction)
            CounterDP_ClearFIFO();
        #endif /* (!CounterDP_UsingFixedFunction) */
        
        /* Set Initial values from Configuration */
        CounterDP_WritePeriod(CounterDP_INIT_PERIOD_VALUE);
        #if (!(CounterDP_UsingFixedFunction && (CY_PSOC5A)))
            CounterDP_WriteCounter(CounterDP_INIT_COUNTER_VALUE);
        #endif /* (!(CounterDP_UsingFixedFunction && (CY_PSOC5A))) */
        CounterDP_SetInterruptMode(CounterDP_INIT_INTERRUPTS_MASK);
        
        #if (!CounterDP_UsingFixedFunction)
            /* Read the status register to clear the unwanted interrupts */
            (void)CounterDP_ReadStatusRegister();
            /* Set the compare value (only available to non-fixed function implementation */
            CounterDP_WriteCompare(CounterDP_INIT_COMPARE_VALUE);
            /* Use the interrupt output of the status register for IRQ output */
            
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            CounterDP_interruptState = CyEnterCriticalSection();
            
            CounterDP_STATUS_AUX_CTRL |= CounterDP_STATUS_ACTL_INT_EN_MASK;
            
            /* Exit Critical Region*/
            CyExitCriticalSection(CounterDP_interruptState);
            
        #endif /* (!CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_Enable
********************************************************************************
* Summary:
*     Enable the Counter
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: 
*   If the Enable mode is set to Hardware only then this function has no effect 
*   on the operation of the counter.
*
*******************************************************************************/
void CounterDP_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (CounterDP_UsingFixedFunction)
        CounterDP_GLOBAL_ENABLE |= CounterDP_BLOCK_EN_MASK;
        CounterDP_GLOBAL_STBY_ENABLE |= CounterDP_BLOCK_STBY_EN_MASK;
    #endif /* (CounterDP_UsingFixedFunction) */  
        
    /* Enable the counter from the control register  */
    /* If Fixed Function then make sure Mode is set correctly */
    /* else make sure reset is clear */
    #if(!CounterDP_ControlRegRemoved || CounterDP_UsingFixedFunction)
        CounterDP_CONTROL |= CounterDP_CTRL_ENABLE;                
    #endif /* (!CounterDP_ControlRegRemoved || CounterDP_UsingFixedFunction) */
    
}


/*******************************************************************************
* Function Name: CounterDP_Start
********************************************************************************
* Summary:
*  Enables the counter for operation 
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Global variables:
*  CounterDP_initVar: Is modified when this function is called for the  
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void CounterDP_Start(void) 
{
    if(CounterDP_initVar == 0u)
    {
        CounterDP_Init();
        
        CounterDP_initVar = 1u; /* Clear this bit for Initialization */        
    }
    
    /* Enable the Counter */
    CounterDP_Enable();        
}


/*******************************************************************************
* Function Name: CounterDP_Stop
********************************************************************************
* Summary:
* Halts the counter, but does not change any modes or disable interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: If the Enable mode is set to Hardware only then this function
*               has no effect on the operation of the counter.
*
*******************************************************************************/
void CounterDP_Stop(void) 
{
    /* Disable Counter */
    #if(!CounterDP_ControlRegRemoved || CounterDP_UsingFixedFunction)
        CounterDP_CONTROL &= ((uint8)(~CounterDP_CTRL_ENABLE));        
    #endif /* (!CounterDP_ControlRegRemoved || CounterDP_UsingFixedFunction) */
    
    /* Globally disable the Fixed Function Block chosen */
    #if (CounterDP_UsingFixedFunction)
        CounterDP_GLOBAL_ENABLE &= ((uint8)(~CounterDP_BLOCK_EN_MASK));
        CounterDP_GLOBAL_STBY_ENABLE &= ((uint8)(~CounterDP_BLOCK_STBY_EN_MASK));
    #endif /* (CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_SetInterruptMode
********************************************************************************
* Summary:
* Configures which interrupt sources are enabled to generate the final interrupt
*
* Parameters:  
*  InterruptsMask: This parameter is an or'd collection of the status bits
*                   which will be allowed to generate the counters interrupt.   
*
* Return: 
*  void
*
*******************************************************************************/
void CounterDP_SetInterruptMode(uint8 interruptsMask) 
{
    CounterDP_STATUS_MASK = interruptsMask;
}


/*******************************************************************************
* Function Name: CounterDP_ReadStatusRegister
********************************************************************************
* Summary:
*   Reads the status register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the status register
*
* Side Effects:
*   Status register bits may be clear on read. 
*
*******************************************************************************/
uint8   CounterDP_ReadStatusRegister(void) 
{
    return CounterDP_STATUS;
}


#if(!CounterDP_ControlRegRemoved)
/*******************************************************************************
* Function Name: CounterDP_ReadControlRegister
********************************************************************************
* Summary:
*   Reads the control register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
uint8   CounterDP_ReadControlRegister(void) 
{
    return CounterDP_CONTROL;
}


/*******************************************************************************
* Function Name: CounterDP_WriteControlRegister
********************************************************************************
* Summary:
*   Sets the bit-field of the control register.  This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
void    CounterDP_WriteControlRegister(uint8 control) 
{
    CounterDP_CONTROL = control;
}

#endif  /* (!CounterDP_ControlRegRemoved) */


#if (!(CounterDP_UsingFixedFunction && (CY_PSOC5A)))
/*******************************************************************************
* Function Name: CounterDP_WriteCounter
********************************************************************************
* Summary:
*   This funtion is used to set the counter to a specific value
*
* Parameters:  
*  counter:  New counter value. 
*
* Return: 
*  void 
*
*******************************************************************************/
void CounterDP_WriteCounter(uint32 counter) \
                                   
{
    #if(CounterDP_UsingFixedFunction)
        /* assert if block is already enabled */
        CYASSERT (0u == (CounterDP_GLOBAL_ENABLE & CounterDP_BLOCK_EN_MASK));
        /* If block is disabled, enable it and then write the counter */
        CounterDP_GLOBAL_ENABLE |= CounterDP_BLOCK_EN_MASK;
        CY_SET_REG16(CounterDP_COUNTER_LSB_PTR, (uint16)counter);
        CounterDP_GLOBAL_ENABLE &= ((uint8)(~CounterDP_BLOCK_EN_MASK));
    #else
        CY_SET_REG32(CounterDP_COUNTER_LSB_PTR, counter);
    #endif /* (CounterDP_UsingFixedFunction) */
}
#endif /* (!(CounterDP_UsingFixedFunction && (CY_PSOC5A))) */


/*******************************************************************************
* Function Name: CounterDP_ReadCounter
********************************************************************************
* Summary:
* Returns the current value of the counter.  It doesn't matter
* if the counter is enabled or running.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint32) The present value of the counter.
*
*******************************************************************************/
uint32 CounterDP_ReadCounter(void) 
{
    /* Force capture by reading Accumulator */
    /* Must first do a software capture to be able to read the counter */
    /* It is up to the user code to make sure there isn't already captured data in the FIFO */
    #if(CounterDP_UsingFixedFunction)
		(void)CY_GET_REG16(CounterDP_COUNTER_LSB_PTR);
	#else
		(void)CY_GET_REG8(CounterDP_COUNTER_LSB_PTR_8BIT);
	#endif/* (CounterDP_UsingFixedFunction) */
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    #if(CounterDP_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(CounterDP_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG32(CounterDP_STATICCOUNT_LSB_PTR));
    #endif /* (CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_ReadCapture
********************************************************************************
* Summary:
*   This function returns the last value captured.
*
* Parameters:  
*  void
*
* Return: 
*  (uint32) Present Capture value.
*
*******************************************************************************/
uint32 CounterDP_ReadCapture(void) 
{
    #if(CounterDP_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(CounterDP_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG32(CounterDP_STATICCOUNT_LSB_PTR));
    #endif /* (CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_WritePeriod
********************************************************************************
* Summary:
* Changes the period of the counter.  The new period 
* will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period: (uint32) A value of 0 will result in
*         the counter remaining at zero.  
*
* Return: 
*  void
*
*******************************************************************************/
void CounterDP_WritePeriod(uint32 period) 
{
    #if(CounterDP_UsingFixedFunction)
        CY_SET_REG16(CounterDP_PERIOD_LSB_PTR,(uint16)period);
    #else
        CY_SET_REG32(CounterDP_PERIOD_LSB_PTR, period);
    #endif /* (CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_ReadPeriod
********************************************************************************
* Summary:
* Reads the current period value without affecting counter operation.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint32) Present period value.
*
*******************************************************************************/
uint32 CounterDP_ReadPeriod(void) 
{
    #if(CounterDP_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(CounterDP_PERIOD_LSB_PTR));
    #else
        return (CY_GET_REG32(CounterDP_PERIOD_LSB_PTR));
    #endif /* (CounterDP_UsingFixedFunction) */
}


#if (!CounterDP_UsingFixedFunction)
/*******************************************************************************
* Function Name: CounterDP_WriteCompare
********************************************************************************
* Summary:
* Changes the compare value.  The compare output will 
* reflect the new value on the next UDB clock.  The compare output will be 
* driven high when the present counter value compares true based on the 
* configured compare mode setting. 
*
* Parameters:  
*  Compare:  New compare value. 
*
* Return: 
*  void
*
*******************************************************************************/
void CounterDP_WriteCompare(uint32 compare) \
                                   
{
    #if(CounterDP_UsingFixedFunction)
        CY_SET_REG16(CounterDP_COMPARE_LSB_PTR, (uint16)compare);
    #else
        CY_SET_REG32(CounterDP_COMPARE_LSB_PTR, compare);
    #endif /* (CounterDP_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CounterDP_ReadCompare
********************************************************************************
* Summary:
* Returns the compare value.
*
* Parameters:  
*  void:
*
* Return: 
*  (uint32) Present compare value.
*
*******************************************************************************/
uint32 CounterDP_ReadCompare(void) 
{
    return (CY_GET_REG32(CounterDP_COMPARE_LSB_PTR));
}


#if (CounterDP_COMPARE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: CounterDP_SetCompareMode
********************************************************************************
* Summary:
*  Sets the software controlled Compare Mode.
*
* Parameters:
*  compareMode:  Compare Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void CounterDP_SetCompareMode(uint8 compareMode) 
{
    /* Clear the compare mode bits in the control register */
    CounterDP_CONTROL &= ((uint8)(~CounterDP_CTRL_CMPMODE_MASK));
    
    /* Write the new setting */
    CounterDP_CONTROL |= compareMode;
}
#endif  /* (CounterDP_COMPARE_MODE_SOFTWARE) */


#if (CounterDP_CAPTURE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: CounterDP_SetCaptureMode
********************************************************************************
* Summary:
*  Sets the software controlled Capture Mode.
*
* Parameters:
*  captureMode:  Capture Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void CounterDP_SetCaptureMode(uint8 captureMode) 
{
    /* Clear the capture mode bits in the control register */
    CounterDP_CONTROL &= ((uint8)(~CounterDP_CTRL_CAPMODE_MASK));
    
    /* Write the new setting */
    CounterDP_CONTROL |= ((uint8)((uint8)captureMode << CounterDP_CTRL_CAPMODE0_SHIFT));
}
#endif  /* (CounterDP_CAPTURE_MODE_SOFTWARE) */


/*******************************************************************************
* Function Name: CounterDP_ClearFIFO
********************************************************************************
* Summary:
*   This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void:
*
* Return: 
*  None
*
*******************************************************************************/
void CounterDP_ClearFIFO(void) 
{

    while(0u != (CounterDP_ReadStatusRegister() & CounterDP_STATUS_FIFONEMP))
    {
        (void)CounterDP_ReadCapture();
    }

}
#endif  /* (!CounterDP_UsingFixedFunction) */


/* [] END OF FILE */

