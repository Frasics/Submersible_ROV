/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include "math.h"
#include "ballast.h"
#include "thrust.h"
#include "DivingPlanes.h"
#include "gripper.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //thrust intiations
    ADC_X_Start();
    ADC_Y_Start();
    ADC_X_StartConvert();
    ADC_Y_StartConvert();
   
    //end of thruster initialization
    
    //start of ballast initiations
    LCD_Start();
    Cap_Start(); 
    Cap_InitializeAllBaselines();
    //endof ballast initiations
    
    //Beginning of Diving Planes Initialization
    clk_D_Start();
    PWM_D_Start();
    //end of diving planes initializations
    
    //Beginning of Thruster Initialization
    PWM_T_Start();
    clk_T_Start();
    //end of thruster initialization
    
    //beginning of gripper initialization
    PWM_G_Start();
    clk_G_Start();
    //end of gripper initialization
    
    //initialize counter
    CounterDP_Start();
    
    for(;;)
    {
        LCD_Position(0,0);
        LCD_PrintString("          ");
        LCD_Position(0,0);
        ballast();
      //  LCD_PrintNumber(ballast());
       // uint16 test = DiveUp_Read();
       // LCD_PrintNumber(test);
        grip();
        Dive();
        thrust();//ADC_X,ADC_Y, y, speedMag1,speedMag2);
       //CyDelay(10);
    }
}
