
#include "project.h"
#include "ballast.h"

uint8 count = 1;
void CapSense_DisplayState();

void ballast()
{
	CyGlobalIntEnable;    /* Enable global interrupts */
    if(Cap_IsBusy() == 0)
	{
        Cap_UpdateEnabledBaselines();
    	Cap_ScanEnabledWidgets();
	}
	CapSense_DisplayState();
 //   return count;
}

void CapSense_DisplayState()
{       
    /* BUTTON0 */
	if (Cap_CheckIsWidgetActive(Cap_BUTTON0__BTN) &! Cap_CheckIsWidgetActive(Cap_BUTTON1__BTN)) 
	{   
        LED1_Write(1u);
        LED2_Write(0u);
        //////////////////////////////
        //         up              //
        /////////////////////////////
        BallastDirOut_Write(1);
        BallastOnOut_Write(1);          
      /*      if(value < 1328)//at max up postion
            {
                PWM_WriteCompare1(0);
                PWM_WriteCompare2(0);
            }*/        
    }
	/* BUTTON1 */
	else if (Cap_CheckIsWidgetActive(Cap_BUTTON1__BTN) &! Cap_CheckIsWidgetActive(Cap_BUTTON0__BTN))
	{     
        LED1_Write(0u);
        LED2_Write(1u);
        
        //////////////////////////////
        //         DOWN            //
        ///////////////////////////// 
        BallastOnOut_Write(1); 
        BallastDirOut_Write(0);
	}
	else
	{
		LED1_Write(0u);
        LED2_Write(0u);
        BallastOnOut_Write(0);
        BallastDirOut_Write(0);
	}
}