/*******************************************************************************
* File Name: DirOut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DirOut_H) /* Pins DirOut_H */
#define CY_PINS_DirOut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DirOut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 DirOut__PORT == 15 && ((DirOut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    DirOut_Write(uint8 value);
void    DirOut_SetDriveMode(uint8 mode);
uint8   DirOut_ReadDataReg(void);
uint8   DirOut_Read(void);
void    DirOut_SetInterruptMode(uint16 position, uint16 mode);
uint8   DirOut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the DirOut_SetDriveMode() function.
     *  @{
     */
        #define DirOut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define DirOut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define DirOut_DM_RES_UP          PIN_DM_RES_UP
        #define DirOut_DM_RES_DWN         PIN_DM_RES_DWN
        #define DirOut_DM_OD_LO           PIN_DM_OD_LO
        #define DirOut_DM_OD_HI           PIN_DM_OD_HI
        #define DirOut_DM_STRONG          PIN_DM_STRONG
        #define DirOut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define DirOut_MASK               DirOut__MASK
#define DirOut_SHIFT              DirOut__SHIFT
#define DirOut_WIDTH              1u

/* Interrupt constants */
#if defined(DirOut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DirOut_SetInterruptMode() function.
     *  @{
     */
        #define DirOut_INTR_NONE      (uint16)(0x0000u)
        #define DirOut_INTR_RISING    (uint16)(0x0001u)
        #define DirOut_INTR_FALLING   (uint16)(0x0002u)
        #define DirOut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define DirOut_INTR_MASK      (0x01u) 
#endif /* (DirOut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DirOut_PS                     (* (reg8 *) DirOut__PS)
/* Data Register */
#define DirOut_DR                     (* (reg8 *) DirOut__DR)
/* Port Number */
#define DirOut_PRT_NUM                (* (reg8 *) DirOut__PRT) 
/* Connect to Analog Globals */                                                  
#define DirOut_AG                     (* (reg8 *) DirOut__AG)                       
/* Analog MUX bux enable */
#define DirOut_AMUX                   (* (reg8 *) DirOut__AMUX) 
/* Bidirectional Enable */                                                        
#define DirOut_BIE                    (* (reg8 *) DirOut__BIE)
/* Bit-mask for Aliased Register Access */
#define DirOut_BIT_MASK               (* (reg8 *) DirOut__BIT_MASK)
/* Bypass Enable */
#define DirOut_BYP                    (* (reg8 *) DirOut__BYP)
/* Port wide control signals */                                                   
#define DirOut_CTL                    (* (reg8 *) DirOut__CTL)
/* Drive Modes */
#define DirOut_DM0                    (* (reg8 *) DirOut__DM0) 
#define DirOut_DM1                    (* (reg8 *) DirOut__DM1)
#define DirOut_DM2                    (* (reg8 *) DirOut__DM2) 
/* Input Buffer Disable Override */
#define DirOut_INP_DIS                (* (reg8 *) DirOut__INP_DIS)
/* LCD Common or Segment Drive */
#define DirOut_LCD_COM_SEG            (* (reg8 *) DirOut__LCD_COM_SEG)
/* Enable Segment LCD */
#define DirOut_LCD_EN                 (* (reg8 *) DirOut__LCD_EN)
/* Slew Rate Control */
#define DirOut_SLW                    (* (reg8 *) DirOut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DirOut_PRTDSI__CAPS_SEL       (* (reg8 *) DirOut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DirOut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DirOut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DirOut_PRTDSI__OE_SEL0        (* (reg8 *) DirOut__PRTDSI__OE_SEL0) 
#define DirOut_PRTDSI__OE_SEL1        (* (reg8 *) DirOut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DirOut_PRTDSI__OUT_SEL0       (* (reg8 *) DirOut__PRTDSI__OUT_SEL0) 
#define DirOut_PRTDSI__OUT_SEL1       (* (reg8 *) DirOut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DirOut_PRTDSI__SYNC_OUT       (* (reg8 *) DirOut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(DirOut__SIO_CFG)
    #define DirOut_SIO_HYST_EN        (* (reg8 *) DirOut__SIO_HYST_EN)
    #define DirOut_SIO_REG_HIFREQ     (* (reg8 *) DirOut__SIO_REG_HIFREQ)
    #define DirOut_SIO_CFG            (* (reg8 *) DirOut__SIO_CFG)
    #define DirOut_SIO_DIFF           (* (reg8 *) DirOut__SIO_DIFF)
#endif /* (DirOut__SIO_CFG) */

/* Interrupt Registers */
#if defined(DirOut__INTSTAT)
    #define DirOut_INTSTAT            (* (reg8 *) DirOut__INTSTAT)
    #define DirOut_SNAP               (* (reg8 *) DirOut__SNAP)
    
	#define DirOut_0_INTTYPE_REG 		(* (reg8 *) DirOut__0__INTTYPE)
#endif /* (DirOut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_DirOut_H */


/* [] END OF FILE */
