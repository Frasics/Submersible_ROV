/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#define    ACCEL_4G_TO_SCALE_G           0.000488281    // +- 4g = 14 bits == 8 g für 16384bits D.h. 0.000488281 g pro bit

#define dev_addr BNO055_I2C_ADDR2

#define    GYRO_2000DPS_TO_SCALE_DEG     0.0305         // 2000°/s = 16bits == 2000 auf 65536 D.h.  0.0305°/s pro bit

#define    RM_CHIP_ID_content     0xA0
#define    RM_ACC_ID_content      0xFB
#define    RM_MAG_ID_content      0x32
#define    RM_GYR_ID_content      0x0F

short BNO55_Detect();
void  Config_BNO55();
void  Print_MPU_register_map(int , int );
void  Print_MPU_register( unsigned char, unsigned char);
void Print_BNO55_Data();

void MPU_I2C_Write(unsigned char s_addr, unsigned char r_addr, unsigned char len, unsigned char *dat);
void MPU_I2C_Read_Multi(unsigned char s_addr, unsigned char r_addr, unsigned char len, unsigned char *dat);
void MPU_I2C_Read(unsigned char s_addr, unsigned char r_addr, unsigned char len, unsigned char *dat);

// config mode settings  for OPR_MODE register
#define    CONFIGMODE_CON       0x00
#define    ACCGYRO_CON          0b0000000101
#define    AMG_CON              0b0000000111
#define    IMU_CON              0b0000001000
#define    NDOF_CON             0b0000001100


// Data Registers
#define    TEMPERATUR_DATA_ADR  0X34
#define    ACCEL_DATA_ADR       0X08
#define    GYRO_DATA_ADR        0X14
#define    MAG_DATA_ADR         0X0E
#define    EULER_DATA_ADR       0X1A


/* [] END OF FILE */
