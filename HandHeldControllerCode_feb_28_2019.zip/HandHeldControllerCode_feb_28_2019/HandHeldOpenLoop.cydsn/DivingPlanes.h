#include "project.h"

#ifndef _DivingPlanes_h_included
    #define _DivingPlanes_h_included
    int Dive();
#endif
