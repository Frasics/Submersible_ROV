/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Fraser Forbes.
 *
 * ========================================
*/
#include "project.h"
#include "OBB.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    //initialize ADCs for onboard sensors
    ADC_IR_Start();
    ADC_IR_StartConvert();
    ADC_Depth_Start();
    ADC_Depth_StartConvert();
    
    //turn on front lights
    LED1_Write(1);
    LED2_Write(1);
    
    uint16 tog = 0;
    
    for(;;)
    {
        //Checking all the Signals from the handheld controller
        uint8 BallastDirIn = BallastDirIn_Read();
        uint8 BallastOnIn = BallastOnIn_Read();
        ThrustLeftIn_Read();
        ThrustRightIn_Read();
        DivingPlanesIn_Read();
        
        if( BallastOnIn == 0) // if no ballast inputs
        {
            holdDepth();
        }
        
        else //Acting on the Ballast Inputs
        {
            obb(BallastOnIn, BallastDirIn);
        }
        
        //Just  a flashing LED to indicate that it is being powered
        if (tog <= (65535/8))
        {
            LED_Write(1);
            tog++;
        }
        else if ((tog > (65535/8)) && (tog<65535/4) )
        {
            LED_Write(0);
            tog++;
        }
        else
        {
           tog = 0;
        }
    }
}

/* [] END OF FILE */
