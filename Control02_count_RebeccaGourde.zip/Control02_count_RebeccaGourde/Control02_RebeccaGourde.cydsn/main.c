/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
	CyGlobalIntEnable;    /* Enable global interrupts */
    
    PWM_Start();
    Clock_Start();
    
    LCD_Start();
    
    CapSense_Start(); 
    CapSense_InitializeAllBaselines();	
	
    while(1u)
    {	
		
        if(CapSense_IsBusy() == 0)
		{
	        CapSense_UpdateEnabledBaselines();
	    	CapSense_ScanEnabledWidgets();
		}
		CapSense_DisplayState();
		
        
    }
}

CapSense_DisplayState()
{
    uint16 count = 0; 
   
    LCD_ClearDisplay();
    
    /* BUTTON0 */
	if (CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN)) 
	{
        if (CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN))
        {
            LED1_Write(0u);
            LED2_Write(0u);
            PWM_WriteCompare1(0);
            PWM_WriteCompare2(0);
        }
        else
        {
            LED1_Write(1u);
            LED2_Write(0u);
            //////////////////////////////
            //         up              //
            /////////////////////////////
            PWM_WriteCompare1(255);
            PWM_WriteCompare2(0);
            count++;
            /*
            if(  )//at max up postion
            {
                PWM_WriteCompare1(0);
                PWM_WriteCompare2(0);
            }
            */
        }
	}
	else
	{
		LED1_Write(0u);
        PWM_WriteCompare1(0);
	}
    
	/* BUTTON1 */
	if (CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN))
	{
        if (CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN))
        {
            LED1_Write(0u);
            LED2_Write(0u);
            PWM_WriteCompare1(0);
            PWM_WriteCompare2(0);
        }
        else
        {
            LED1_Write(0u);
            LED2_Write(1u);
            //////////////////////////////
            //         DOWN            //
            /////////////////////////////
            PWM_WriteCompare1(0);
            PWM_WriteCompare2(255);        
            count--;
            /*
            if (  ) //at max down position
            {
                PWM_WriteCompare1(0);
                PWM_WriteCompare2(0);
            }
            */
        }
        
	}
	else
	{
		LED2_Write(0u);
        PWM_WriteCompare2(0);
	}
    LCD_Position(0,0);
    LCD_PrintNumber(count);
    CyDelay(100);
    

   
}


/* [] END OF FILE */
